﻿using SIAML.Middleware.Country;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Abp.Domain.Entities.Auditing;
using Abp.Domain.Entities;
using Abp.Auditing;

namespace SIAML.Middleware.State
{
    [Table("Tbl_States")]
    [Audited]
    public class ManageState : FullAuditedEntity
    {

        [Required]
        [StringLength(ManageStateConsts.MaxStateNameLength, MinimumLength = ManageStateConsts.MinStateNameLength)]
        public virtual string StateName { get; set; }

        public virtual int? CountryId { get; set; }

        [ForeignKey("CountryId")]
        public ManageCountry CountryFk { get; set; }

        [Required]
        [RegularExpression(ManageStateConsts.ISOCodeRegex)]
        [StringLength(ManageStateConsts.MaxISOCodeLength, MinimumLength = ManageStateConsts.MinISOCodeLength)]
        public virtual string ISOCode { get; set; }

    }
}