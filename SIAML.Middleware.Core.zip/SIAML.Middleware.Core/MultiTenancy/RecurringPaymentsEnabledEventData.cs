using Abp.Events.Bus;

namespace SIAML.Middleware.MultiTenancy
{
    public class RecurringPaymentsEnabledEventData : EventData
    {
        public int TenantId { get; set; }
    }
}