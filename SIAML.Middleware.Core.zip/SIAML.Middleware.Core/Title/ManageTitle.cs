﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Abp.Domain.Entities.Auditing;
using Abp.Domain.Entities;
using Abp.Auditing;

namespace SIAML.Middleware.Title
{
    [Table("Tbl_Titles")]
    [Audited]
    public class ManageTitle : FullAuditedEntity
    {

        [Required]
        [StringLength(ManageTitleConsts.MaxTitleLength, MinimumLength = ManageTitleConsts.MinTitleLength)]
        public virtual string Title { get; set; }

    }
}