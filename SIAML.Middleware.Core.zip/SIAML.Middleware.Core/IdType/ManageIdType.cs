﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Abp.Domain.Entities.Auditing;
using Abp.Domain.Entities;
using Abp.Auditing;

namespace SIAML.Middleware.IdType
{
    [Table("Tbl_IdTypes")]
    [Audited]
    public class ManageIdType : FullAuditedEntity
    {

        [Required]
        [StringLength(ManageIdTypeConsts.MaxIdTypeNameLength, MinimumLength = ManageIdTypeConsts.MinIdTypeNameLength)]
        public virtual string IdTypeName { get; set; }

        public virtual bool HasExpiryDate { get; set; }

    }
}