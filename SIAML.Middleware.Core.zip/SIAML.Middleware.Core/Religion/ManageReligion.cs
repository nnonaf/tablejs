﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Abp.Domain.Entities.Auditing;
using Abp.Domain.Entities;
using Abp.Auditing;

namespace SIAML.Middleware.Religion
{
    [Table("Tbl_Religion")]
    [Audited]
    public class ManageReligion : FullAuditedEntity
    {

        [Required]
        [StringLength(ManageReligionConsts.MaxReligionLength, MinimumLength = ManageReligionConsts.MinReligionLength)]
        public virtual string Religion { get; set; }

    }
}