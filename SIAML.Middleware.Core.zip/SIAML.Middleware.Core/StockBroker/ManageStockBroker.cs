﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Abp.Domain.Entities.Auditing;
using Abp.Domain.Entities;
using Abp.Auditing;

namespace SIAML.Middleware.StockBroker
{
    [Table("Tbl_StockBrokers")]
    [Audited]
    public class ManageStockBroker : FullAuditedEntity
    {

        [Required]
        [StringLength(ManageStockBrokerConsts.MaxStockBrokerNameLength, MinimumLength = ManageStockBrokerConsts.MinStockBrokerNameLength)]
        public virtual string StockBrokerName { get; set; }

    }
}