﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Abp.Domain.Entities.Auditing;
using Abp.Domain.Entities;
using Abp.Auditing;

namespace SIAML.Middleware.Currency
{
    [Table("ManageCurrencies")]
    [Audited]
    public class ManageCurrency : FullAuditedEntity
    {

        [Required]
        [StringLength(ManageCurrencyConsts.MaxCurrrencyNameLength, MinimumLength = ManageCurrencyConsts.MinCurrrencyNameLength)]
        public virtual string CurrrencyName { get; set; }

        [Required]
        [StringLength(ManageCurrencyConsts.MaxCurrencyMnemonicLength, MinimumLength = ManageCurrencyConsts.MinCurrencyMnemonicLength)]
        public virtual string CurrencyMnemonic { get; set; }

    }
}