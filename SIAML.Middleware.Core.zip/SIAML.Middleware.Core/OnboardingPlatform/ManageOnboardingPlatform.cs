﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Abp.Domain.Entities.Auditing;
using Abp.Domain.Entities;
using Abp.Auditing;

namespace SIAML.Middleware.OnboardingPlatform
{
    [Table("Tbl_OnboardingPlatforms")]
    [Audited]
    public class ManageOnboardingPlatform : FullAuditedEntity
    {

        [Required]
        [StringLength(ManageOnboardingPlatformConsts.MaxOnboardingPlatformLength, MinimumLength = ManageOnboardingPlatformConsts.MinOnboardingPlatformLength)]
        public virtual string OnboardingPlatform { get; set; }

    }
}