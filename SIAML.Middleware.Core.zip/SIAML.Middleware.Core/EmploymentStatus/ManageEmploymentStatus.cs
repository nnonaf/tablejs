﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Abp.Domain.Entities.Auditing;
using Abp.Domain.Entities;
using Abp.Auditing;

namespace SIAML.Middleware.EmploymentStatus
{
    [Table("Tbl_EmploymentStatus")]
    [Audited]
    public class ManageEmploymentStatus : FullAuditedEntity
    {

        [Required]
        [StringLength(ManageEmploymentStatusConsts.MaxEmploymentStatusLength, MinimumLength = ManageEmploymentStatusConsts.MinEmploymentStatusLength)]
        public virtual string EmploymentStatus { get; set; }

    }
}