﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Abp.Domain.Entities.Auditing;
using Abp.Domain.Entities;

namespace SIAML.Middleware.WealthBox
{
    [Table("Tbl_WorkflowManagements")]
    public class WorkflowManagement : FullAuditedEntity
    {

        public virtual string StaffId { get; set; }

    }
}