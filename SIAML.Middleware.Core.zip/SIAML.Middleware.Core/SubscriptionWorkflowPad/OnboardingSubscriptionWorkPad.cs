﻿using SIAML.Middleware.KYCStatusEnums;
using SIAML.Middleware.YesNoEnums;
using SIAML.Middleware.RiskCategoryEnums;
using SIAML.Middleware.CallOverStatusEnums;
using SIAML.Middleware.Subscription;
using SIAML.Middleware.Title;
using SIAML.Middleware.MaritalStatus;
using SIAML.Middleware.Country;
using SIAML.Middleware.State;
using SIAML.Middleware.Title;
using SIAML.Middleware.Gender;
using SIAML.Middleware.Country;
using SIAML.Middleware.State;
using SIAML.Middleware.Relationship;
using SIAML.Middleware.State;
using SIAML.Middleware.MarketingChannel;
using SIAML.Middleware.Gender;
using SIAML.Middleware.Religion;
using SIAML.Middleware.Bank;
using SIAML.Middleware.Country;
using SIAML.Middleware.IdType;
using SIAML.Middleware.Country;
using SIAML.Middleware.PaymentMode;
using SIAML.Middleware.EmploymentStatus;
using SIAML.Middleware.MaritalStatus;
using SIAML.Middleware.JobType;
using SIAML.Middleware.StockBroker;
using SIAML.Middleware.Relationship;
using SIAML.Middleware.FundDetails;
using SIAML.Middleware.Sector;
using SIAML.Middleware.Country;
using SIAML.Middleware.State;
using SIAML.Middleware.Title;
using SIAML.Middleware.Gender;
using SIAML.Middleware.Country;
using SIAML.Middleware.Country;
using SIAML.Middleware.OnboardingPlatform;
using SIAML.Middleware.Authorization.Users;
using SIAML.Middleware.Town;
using SIAML.Middleware.LegalEntity;
using SIAML.Middleware.LegalEntity;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Abp.Domain.Entities.Auditing;
using Abp.Domain.Entities;
using Abp.Auditing;

namespace SIAML.Middleware.SubscriptionWorkflowPad
{
    [Table("ClientWorkPad")]
    [Audited]
    public class OnboardingSubscriptionWorkPad : FullAuditedEntity, IMayHaveTenant
    {
        public int? TenantId { get; set; }

        public virtual bool MarketingConsent { get; set; }

        public virtual bool DataPrivacy { get; set; }

        public virtual DateTime? IdIssueDate { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxLastNameLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinLastNameLength)]
        public virtual string LastName { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxFirstNameLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinFirstNameLength)]
        public virtual string FirstName { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxOtherNamesLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinOtherNamesLength)]
        public virtual string OtherNames { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxFullNameLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinFullNameLength)]
        public virtual string FullName { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxMaiden_NameLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinMaiden_NameLength)]
        public virtual string Maiden_Name { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxMothers_Maiden_NameLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinMothers_Maiden_NameLength)]
        public virtual string Mothers_Maiden_Name { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxEmployer_IdLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinEmployer_IdLength)]
        public virtual string Employer_Id { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxDesignationLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinDesignationLength)]
        public virtual string Designation { get; set; }

        public virtual DateTime? Date_Of_Birth { get; set; }

        [RegularExpression(OnboardingSubscriptionWorkPadConsts.EmailRegex)]
        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxEmailLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinEmailLength)]
        public virtual string Email { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxMobile_PhoneLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinMobile_PhoneLength)]
        public virtual string Mobile_Phone { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxOfficial_PhoneLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinOfficial_PhoneLength)]
        public virtual string Official_Phone { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxNok_LastNameLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinNok_LastNameLength)]
        public virtual string Nok_LastName { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxNok_FirstNameLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinNok_FirstNameLength)]
        public virtual string Nok_FirstName { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxNok_OtherNamesLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinNok_OtherNamesLength)]
        public virtual string Nok_OtherNames { get; set; }

        [RegularExpression(OnboardingSubscriptionWorkPadConsts.Nok_EmailRegex)]
        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxNok_EmailLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinNok_EmailLength)]
        public virtual string Nok_Email { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxNok_Mobile_PhoneLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinNok_Mobile_PhoneLength)]
        public virtual string Nok_Mobile_Phone { get; set; }

        public virtual DateTime? Nok_Date_Of_Birth { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxNokAddressLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinNokAddressLength)]
        public virtual string NokAddress { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxNokAddress2Length, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinNokAddress2Length)]
        public virtual string NokAddress2 { get; set; }

        public virtual bool NotifySms { get; set; }

        public virtual bool NotifyEmail { get; set; }

        public virtual bool NotifyPostal { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxBankAccountNameLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinBankAccountNameLength)]
        public virtual string BankAccountName { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxBankAccountNumberLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinBankAccountNumberLength)]
        public virtual string BankAccountNumber { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxBankAccountStatusLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinBankAccountStatusLength)]
        public virtual string BankAccountStatus { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxBvnLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinBvnLength)]
        public virtual string Bvn { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxBvnLastNameLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinBvnLastNameLength)]
        public virtual string BvnLastName { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxBvnFirstNameLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinBvnFirstNameLength)]
        public virtual string BvnFirstName { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxBvnOtherNamesLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinBvnOtherNamesLength)]
        public virtual string BvnOtherNames { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxBvnMobilePhoneLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinBvnMobilePhoneLength)]
        public virtual string BvnMobilePhone { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxBvnDobLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinBvnDobLength)]
        public virtual string BvnDob { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxBvnStatusLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinBvnStatusLength)]
        public virtual string BvnStatus { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxCSCSAccountNumberLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinCSCSAccountNumberLength)]
        public virtual string CSCSAccountNumber { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxCHNLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinCHNLength)]
        public virtual string CHN { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxPFALength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinPFALength)]
        public virtual string PFA { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxRsaPinLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinRsaPinLength)]
        public virtual string RsaPin { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxStatusLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinStatusLength)]
        public virtual string Status { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxKYCStatusPassportLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinKYCStatusPassportLength)]
        public virtual string KYCStatusPassport { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxKYCStatusDatesLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinKYCStatusDatesLength)]
        public virtual string KYCStatusDates { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxKYCStatusIdMeansLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinKYCStatusIdMeansLength)]
        public virtual string KYCStatusIdMeans { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxKYCStatusAddressProofLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinKYCStatusAddressProofLength)]
        public virtual string KYCStatusAddressProof { get; set; }

        public virtual KYCStatus KYCStatus { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxRecordSourceIdLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinRecordSourceIdLength)]
        public virtual string RecordSourceId { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxRecordLocationIdLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinRecordLocationIdLength)]
        public virtual string RecordLocationId { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxAgentIdLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinAgentIdLength)]
        public virtual string AgentId { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxPromoIdLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinPromoIdLength)]
        public virtual string PromoId { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxResidentialAddressLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinResidentialAddressLength)]
        public virtual string ResidentialAddress { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxResidentialAddress2Length, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinResidentialAddress2Length)]
        public virtual string ResidentialAddress2 { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxMailingAddressLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinMailingAddressLength)]
        public virtual string MailingAddress { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxMailingAddress2Length, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinMailingAddress2Length)]
        public virtual string MailingAddress2 { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxMailingCityLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinMailingCityLength)]
        public virtual string MailingCity { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxMailingStateLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinMailingStateLength)]
        public virtual string MailingState { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxPassportLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinPassportLength)]
        public virtual string Passport { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxSignatureLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinSignatureLength)]
        public virtual string Signature { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxIdNumberLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinIdNumberLength)]
        public virtual string IdNumber { get; set; }

        public virtual DateTime? IdExpiryDate { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxProofOfAddressLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinProofOfAddressLength)]
        public virtual string ProofOfAddress { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxProofOfAddressTypeLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinProofOfAddressTypeLength)]
        public virtual string ProofOfAddressType { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxWebStatusLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinWebStatusLength)]
        public virtual string WebStatus { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxWebPassCodeLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinWebPassCodeLength)]
        public virtual string WebPassCode { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxSubProfileLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinSubProfileLength)]
        public virtual string SubProfile { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxLinkIdLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinLinkIdLength)]
        public virtual string LinkId { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxAdditionalInformationLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinAdditionalInformationLength)]
        public virtual string AdditionalInformation { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxSchoolIdLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinSchoolIdLength)]
        public virtual string SchoolId { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxSchoolClassLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinSchoolClassLength)]
        public virtual string SchoolClass { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxSchoolSessionLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinSchoolSessionLength)]
        public virtual string SchoolSession { get; set; }

        public virtual DateTime? SchoolSessionStart { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxStagingIdLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinStagingIdLength)]
        public virtual string StagingId { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxInvestorIdLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinInvestorIdLength)]
        public virtual string InvestorId { get; set; }

        public virtual DateTime? RegistrationDate { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxCreated_ByLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinCreated_ByLength)]
        public virtual string Created_By { get; set; }

        public virtual DateTime? DateCreated { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxConfirmedByLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinConfirmedByLength)]
        public virtual string ConfirmedBy { get; set; }

        public virtual DateTime? DateConfirmed { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxApprovedByLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinApprovedByLength)]
        public virtual string ApprovedBy { get; set; }

        public virtual DateTime? DateApproved { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxLastUpdatedByLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinLastUpdatedByLength)]
        public virtual string LastUpdatedBy { get; set; }

        public virtual DateTime? DateLastUpdated { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxWorkFlowTypeLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinWorkFlowTypeLength)]
        public virtual string WorkFlowType { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxTransRefLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinTransRefLength)]
        public virtual string TransRef { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxOrderIdLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinOrderIdLength)]
        public virtual string OrderId { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxRecordIdLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinRecordIdLength)]
        public virtual string RecordId { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxClientIdLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinClientIdLength)]
        public virtual string ClientId { get; set; }

        public virtual decimal? Amount { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxTagLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinTagLength)]
        public virtual string Tag { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxSourceLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinSourceLength)]
        public virtual string Source { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxBeneficiaryNameLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinBeneficiaryNameLength)]
        public virtual string BeneficiaryName { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxBeneficiaryAccountLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinBeneficiaryAccountLength)]
        public virtual string BeneficiaryAccount { get; set; }

        public virtual DateTime? ValueDate { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxApprovalStatusLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinApprovalStatusLength)]
        public virtual string ApprovalStatus { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxApproverLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinApproverLength)]
        public virtual string Approver { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxAgentCodeLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinAgentCodeLength)]
        public virtual string AgentCode { get; set; }

        public virtual decimal? OfferPrice { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxSubscriberTypeLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinSubscriberTypeLength)]
        public virtual string SubscriberType { get; set; }

        public virtual YesNoEnum OnlineRedemption { get; set; }

        public virtual decimal? Units { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxTransIdLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinTransIdLength)]
        public virtual string TransId { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxReceivedByLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinReceivedByLength)]
        public virtual string ReceivedBy { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxMarketingSourceLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinMarketingSourceLength)]
        public virtual string MarketingSource { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxDividendPaymentLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinDividendPaymentLength)]
        public virtual string DividendPayment { get; set; }

        public virtual YesNoEnum EmailIdemnity { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxAdditionalFlagLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinAdditionalFlagLength)]
        public virtual string AdditionalFlag { get; set; }

        public virtual YesNoEnum PEP { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxCorporateNameOfInstitutionLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinCorporateNameOfInstitutionLength)]
        public virtual string CorporateNameOfInstitution { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxCorporateRCRegistrationNumberLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinCorporateRCRegistrationNumberLength)]
        public virtual string CorporateRCRegistrationNumber { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxCorporatePlaceOfIncorporationLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinCorporatePlaceOfIncorporationLength)]
        public virtual string CorporatePlaceOfIncorporation { get; set; }

        public virtual DateTime? CorporateDateOfIncorporation { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxCorporateBusinessTypeLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinCorporateBusinessTypeLength)]
        public virtual string CorporateBusinessType { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxPhoneNumberLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinPhoneNumberLength)]
        public virtual string PhoneNumber { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxCorporateWebsiteLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinCorporateWebsiteLength)]
        public virtual string CorporateWebsite { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxCorporateFaxNumberLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinCorporateFaxNumberLength)]
        public virtual string CorporateFaxNumber { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxCorporateEmailAddressLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinCorporateEmailAddressLength)]
        public virtual string CorporateEmailAddress { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxCorporateCityLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinCorporateCityLength)]
        public virtual string CorporateCity { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxCorporateBusinessAddressLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinCorporateBusinessAddressLength)]
        public virtual string CorporateBusinessAddress { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxCorporateStreetNameLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinCorporateStreetNameLength)]
        public virtual string CorporateStreetName { get; set; }

        public virtual decimal? CorporateAnnualTurnover { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxCorporateLocalityLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinCorporateLocalityLength)]
        public virtual string CorporateLocality { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxCorporateNameOfContactPersonLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinCorporateNameOfContactPersonLength)]
        public virtual string CorporateNameOfContactPerson { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxCorporateContactEmailAddressLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinCorporateContactEmailAddressLength)]
        public virtual string CorporateContactEmailAddress { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxCorporateDesignationLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinCorporateDesignationLength)]
        public virtual string CorporateDesignation { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxNarrationLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinNarrationLength)]
        public virtual string Narration { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxReturnCodeLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinReturnCodeLength)]
        public virtual string ReturnCode { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxUpdatedByLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinUpdatedByLength)]
        public virtual string UpdatedBy { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxCommentLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinCommentLength)]
        public virtual string Comment { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxChildSurnameLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinChildSurnameLength)]
        public virtual string ChildSurname { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxChildFirstNameLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinChildFirstNameLength)]
        public virtual string ChildFirstName { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxChildMiddleNameLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinChildMiddleNameLength)]
        public virtual string ChildMiddleName { get; set; }

        public virtual DateTime? ChildDateOfBirth { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxIncomeRangePerAnnumLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinIncomeRangePerAnnumLength)]
        public virtual string IncomeRangePerAnnum { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxTinLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinTinLength)]
        public virtual string Tin { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxPlaceOfIssueLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinPlaceOfIssueLength)]
        public virtual string PlaceOfIssue { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxLevelOfEducationLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinLevelOfEducationLength)]
        public virtual string LevelOfEducation { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxEmployerAddressLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinEmployerAddressLength)]
        public virtual string EmployerAddress { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxEmployerTelephoneLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinEmployerTelephoneLength)]
        public virtual string EmployerTelephone { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxEmployerFaxLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinEmployerFaxLength)]
        public virtual string EmployerFax { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxEmployerSegmentLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinEmployerSegmentLength)]
        public virtual string EmployerSegment { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxEmployerWebsiteLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinEmployerWebsiteLength)]
        public virtual string EmployerWebsite { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxEmployerNameLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinEmployerNameLength)]
        public virtual string EmployerName { get; set; }

        public virtual RiskCategoryEnum RiskCategory { get; set; }

        public virtual RiskSubCategoryEnum RiskSubCategory { get; set; }

        public virtual CallOverStatusEnum CallOverStatus { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxNokCityLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinNokCityLength)]
        public virtual string NokCity { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxCountry_CodeLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinCountry_CodeLength)]
        public virtual string Country_Code { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxCountry_Code_OfficialLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinCountry_Code_OfficialLength)]
        public virtual string Country_Code_Official { get; set; }

        [StringLength(OnboardingSubscriptionWorkPadConsts.MaxNok_Country_CodeLength, MinimumLength = OnboardingSubscriptionWorkPadConsts.MinNok_Country_CodeLength)]
        public virtual string Nok_Country_Code { get; set; }

        public virtual bool ResearchConsent { get; set; }

        public virtual bool MarketOtherConsent { get; set; }
        //File

        public virtual Guid? CertificateOfIncorporationUpload { get; set; } //File, (BinaryObjectId)
                                                                            //File

        public virtual Guid? FormCAC2Upload { get; set; } //File, (BinaryObjectId)
                                                          //File

        public virtual Guid? FormCAC7Upload { get; set; } //File, (BinaryObjectId)
                                                          //File

        public virtual Guid? LegalSearchReportUpload { get; set; } //File, (BinaryObjectId)
                                                                   //File

        public virtual Guid? ArticleOfAssociationUpload { get; set; } //File, (BinaryObjectId)

        public virtual int ManageSubscriptionTypeId { get; set; }

        [ForeignKey("ManageSubscriptionTypeId")]
        public ManageSubscriptionType ManageSubscriptionTypeFk { get; set; }

        public virtual int? Title { get; set; }

        [ForeignKey("Title")]
        public ManageTitle TitleFk { get; set; }

        public virtual int? Marital_Status { get; set; }

        [ForeignKey("Marital_Status")]
        public ManageMaritalStatus Marital_StatusFk { get; set; }

        public virtual int? Nationality { get; set; }

        [ForeignKey("Nationality")]
        public ManageCountry NationalityFk { get; set; }

        public virtual int? State_Of_Origin { get; set; }

        [ForeignKey("State_Of_Origin")]
        public ManageState State_Of_OriginFk { get; set; }

        public virtual int? Nok_Title { get; set; }

        [ForeignKey("Nok_Title")]
        public ManageTitle Nok_TitleFk { get; set; }

        public virtual int? Nok_Gender { get; set; }

        [ForeignKey("Nok_Gender")]
        public ManageGender Nok_GenderFk { get; set; }

        public virtual int? NokCountry { get; set; }

        [ForeignKey("NokCountry")]
        public ManageCountry NokCountryFk { get; set; }

        public virtual int? NokState { get; set; }

        [ForeignKey("NokState")]
        public ManageState NokStateFk { get; set; }

        public virtual int? NokRelationship { get; set; }

        [ForeignKey("NokRelationship")]
        public ManageRelationship NokRelationshipFk { get; set; }

        public virtual int? ResidentialState { get; set; }

        [ForeignKey("ResidentialState")]
        public ManageState ResidentialStateFk { get; set; }

        public virtual int? MarketingChannelId { get; set; }

        [ForeignKey("MarketingChannelId")]
        public ManageMarketingChannel MarketingChannelFk { get; set; }

        public virtual int? Gender { get; set; }

        [ForeignKey("Gender")]
        public ManageGender GenderFk { get; set; }

        public virtual int? Religion { get; set; }

        [ForeignKey("Religion")]
        public ManageReligion ReligionFk { get; set; }

        public virtual int? Bank { get; set; }

        [ForeignKey("Bank")]
        public ManageBank BankFk { get; set; }

        public virtual int? ResidentialCountry { get; set; }

        [ForeignKey("ResidentialCountry")]
        public ManageCountry ResidentialCountryFk { get; set; }

        public virtual int? IdType { get; set; }

        [ForeignKey("IdType")]
        public ManageIdType IdTypeFk { get; set; }

        public virtual int? MailingCountry { get; set; }

        [ForeignKey("MailingCountry")]
        public ManageCountry MailingCountryFk { get; set; }

        public virtual int? PaymentMode { get; set; }

        [ForeignKey("PaymentMode")]
        public ManagePaymentMode PaymentModeFk { get; set; }

        public virtual int? EmploymentStatus { get; set; }

        [ForeignKey("EmploymentStatus")]
        public ManageEmploymentStatus EmploymentStatusFk { get; set; }

        public virtual int? NokMaritalStatus { get; set; }

        [ForeignKey("NokMaritalStatus")]
        public ManageMaritalStatus NokMaritalStatusFk { get; set; }

        public virtual int? JobType { get; set; }

        [ForeignKey("JobType")]
        public ManageJobType JobTypeFk { get; set; }

        public virtual int? StockBroker { get; set; }

        [ForeignKey("StockBroker")]
        public ManageStockBroker StockBrokerFk { get; set; }

        public virtual int? RelationshipId { get; set; }

        [ForeignKey("RelationshipId")]
        public ManageRelationship RelationshipFk { get; set; }

        public virtual int? FundId { get; set; }

        [ForeignKey("FundId")]
        public ManageFundDetail FundFk { get; set; }

        public virtual int? CorporateBusinessSector { get; set; }

        [ForeignKey("CorporateBusinessSector")]
        public ManageSector CorporateBusinessSectorFk { get; set; }

        public virtual int? CorporateCountry { get; set; }

        [ForeignKey("CorporateCountry")]
        public ManageCountry CorporateCountryFk { get; set; }

        public virtual int? CorporateState { get; set; }

        [ForeignKey("CorporateState")]
        public ManageState CorporateStateFk { get; set; }

        public virtual int? ChildTitle { get; set; }

        [ForeignKey("ChildTitle")]
        public ManageTitle ChildTitleFk { get; set; }

        public virtual int? ChildGender { get; set; }

        [ForeignKey("ChildGender")]
        public ManageGender ChildGenderFk { get; set; }

        public virtual int? ChildCountryOfBirth { get; set; }

        [ForeignKey("ChildCountryOfBirth")]
        public ManageCountry ChildCountryOfBirthFk { get; set; }

        public virtual int? OtherNationality { get; set; }

        [ForeignKey("OtherNationality")]
        public ManageCountry OtherNationalityFk { get; set; }

        public virtual int? OnboardingPlatform { get; set; }

        [ForeignKey("OnboardingPlatform")]
        public ManageOnboardingPlatform OnboardingPlatformFk { get; set; }

        public virtual long? SalesOfficer { get; set; }

        [ForeignKey("SalesOfficer")]
        public User SalesOfficerFk { get; set; }

        public virtual int? ResidentialCity { get; set; }

        [ForeignKey("ResidentialCity")]
        public ManageTown ResidentialCityFk { get; set; }

        public virtual int? CorporateLegalEntityType { get; set; }

        [ForeignKey("CorporateLegalEntityType")]
        public ManageLegalEntity CorporateLegalEntityTypeFk { get; set; }

        public virtual int? CorporateSubLegalEntityType { get; set; }

        [ForeignKey("CorporateSubLegalEntityType")]
        public ManageSubLegalEntity CorporateSubLegalEntityTypeFk { get; set; }

    }
}