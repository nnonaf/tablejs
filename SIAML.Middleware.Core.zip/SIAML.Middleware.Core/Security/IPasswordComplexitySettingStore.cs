using System.Threading.Tasks;

namespace SIAML.Middleware.Security
{
    public interface IPasswordComplexitySettingStore
    {
        Task<PasswordComplexitySetting> GetSettingsAsync();
    }
}
