﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Abp.Domain.Entities.Auditing;
using Abp.Domain.Entities;
using Abp.Auditing;

namespace SIAML.Middleware.BusinessConfiguration
{
    [Table("Tbl_BusinessConfigurations")]
    [Audited]
    public class ManageBusinessConfiguration : FullAuditedEntity
    {

        public virtual int MaxNoOfFundTypes { get; set; }

        public virtual int MaxNoOfSignatories { get; set; }

        public virtual int MaxNoOfDirectors { get; set; }

        public virtual int MaxNoOfJointSubscribers { get; set; }

        public virtual bool AllowMultiFundSubscription { get; set; }

        public virtual bool AllowNonFundType { get; set; }

    }
}