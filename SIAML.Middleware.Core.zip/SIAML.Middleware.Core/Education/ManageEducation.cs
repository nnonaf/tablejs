﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Abp.Domain.Entities.Auditing;
using Abp.Domain.Entities;
using Abp.Auditing;

namespace SIAML.Middleware.Education
{
    [Table("Tbl_Education")]
    [Audited]
    public class ManageEducation : FullAuditedEntity
    {

        [Required]
        [StringLength(ManageEducationConsts.MaxEducationNameLength, MinimumLength = ManageEducationConsts.MinEducationNameLength)]
        public virtual string EducationName { get; set; }

    }
}