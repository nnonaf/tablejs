﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Abp.Domain.Entities.Auditing;
using Abp.Domain.Entities;
using Abp.Auditing;

namespace SIAML.Middleware.Subscription
{
    [Table("Tbl_SubscriptionTypes")]
    [Audited]
    public class ManageSubscriptionType : FullAuditedEntity
    {

        [Required]
        [StringLength(ManageSubscriptionTypeConsts.MaxSubscriptionTypeLength, MinimumLength = ManageSubscriptionTypeConsts.MinSubscriptionTypeLength)]
        public virtual string SubscriptionType { get; set; }

    }
}