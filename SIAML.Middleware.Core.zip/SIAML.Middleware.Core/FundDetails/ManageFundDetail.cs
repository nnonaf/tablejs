﻿using SIAML.Middleware.DistributionFrequencyEnums;
using SIAML.Middleware.Currency;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Abp.Domain.Entities.Auditing;
using Abp.Domain.Entities;
using Abp.Auditing;

namespace SIAML.Middleware.FundDetails
{
    [Table("Tbl_FundDetails")]
    [Audited]
    public class ManageFundDetail : FullAuditedEntity
    {

        [Required]
        [StringLength(ManageFundDetailConsts.MaxFundIdLength, MinimumLength = ManageFundDetailConsts.MinFundIdLength)]
        public virtual string FundId { get; set; }

        [Required]
        [StringLength(ManageFundDetailConsts.MaxFundNameLength, MinimumLength = ManageFundDetailConsts.MinFundNameLength)]
        public virtual string FundName { get; set; }

        [Required]
        [StringLength(ManageFundDetailConsts.MaxAssetAllocationLength, MinimumLength = ManageFundDetailConsts.MinAssetAllocationLength)]
        public virtual string AssetAllocation { get; set; }

        public virtual bool AnyInvestmentRestricted { get; set; }

        [StringLength(ManageFundDetailConsts.MaxRestrictedInvestmentLength, MinimumLength = ManageFundDetailConsts.MinRestrictedInvestmentLength)]
        public virtual string RestrictedInvestment { get; set; }

        public virtual bool AnyGuarantee { get; set; }

        [StringLength(ManageFundDetailConsts.MaxGuaranteeLength, MinimumLength = ManageFundDetailConsts.MinGuaranteeLength)]
        public virtual string Guarantee { get; set; }

        [Required]
        [StringLength(ManageFundDetailConsts.MaxInvestmentHorizonLength, MinimumLength = ManageFundDetailConsts.MinInvestmentHorizonLength)]
        public virtual string InvestmentHorizon { get; set; }

        [Required]
        [StringLength(ManageFundDetailConsts.MaxInvestmentObjectiveLength, MinimumLength = ManageFundDetailConsts.MinInvestmentObjectiveLength)]
        public virtual string InvestmentObjective { get; set; }

        [Required]
        [StringLength(ManageFundDetailConsts.MaxRiskLength, MinimumLength = ManageFundDetailConsts.MinRiskLength)]
        public virtual string Risk { get; set; }

        [Required]
        [StringLength(ManageFundDetailConsts.MaxRedemptionLength, MinimumLength = ManageFundDetailConsts.MinRedemptionLength)]
        public virtual string Redemption { get; set; }

        public virtual decimal? NominalValue { get; set; }

        public virtual decimal MinimumInvestment { get; set; }

        public virtual decimal SubsequentInvestment { get; set; }

        [Required]
        [StringLength(ManageFundDetailConsts.MaxHandlingChargesLength, MinimumLength = ManageFundDetailConsts.MinHandlingChargesLength)]
        public virtual string HandlingCharges { get; set; }

        public virtual DateTime InceptionDate { get; set; }

        public virtual DistributionFrequencyEnum DistributionFrequency { get; set; }

        public virtual int? Currency { get; set; }

        [ForeignKey("Currency")]
        public ManageCurrency CurrencyFk { get; set; }

    }
}