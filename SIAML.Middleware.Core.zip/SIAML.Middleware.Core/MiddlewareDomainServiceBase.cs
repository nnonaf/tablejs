using Abp.Domain.Services;

namespace SIAML.Middleware
{
    public abstract class MiddlewareDomainServiceBase : DomainService
    {
        /* Add your common members for all your domain services. */

        protected MiddlewareDomainServiceBase()
        {
            LocalizationSourceName = MiddlewareConsts.LocalizationSourceName;
        }
    }
}
