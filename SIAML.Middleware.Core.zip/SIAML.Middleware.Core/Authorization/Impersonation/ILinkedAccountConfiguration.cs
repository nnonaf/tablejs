﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SIAML.Middleware.Authorization.Impersonation
{
    public interface ILinkedAccountConfiguration
    {
        bool IsEnabled { get; set; }
    }
}
