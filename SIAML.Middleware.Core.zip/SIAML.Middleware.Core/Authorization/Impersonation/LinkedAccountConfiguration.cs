﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SIAML.Middleware.Authorization.Impersonation
{
    public class LinkedAccountConfiguration : ILinkedAccountConfiguration
    {
        public bool IsEnabled { get; set; }

        public LinkedAccountConfiguration()
        {
            IsEnabled = false;
        }
    }
}
