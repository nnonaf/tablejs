using Abp.Authorization;
using SIAML.Middleware.Authorization.Roles;
using SIAML.Middleware.Authorization.Users;

namespace SIAML.Middleware.Authorization
{
    public class PermissionChecker : PermissionChecker<Role, User>
    {
        public PermissionChecker(UserManager userManager)
            : base(userManager)
        {

        }
    }
}
