﻿namespace SIAML.Middleware.Authorization
{
    /// <summary>
    /// Defines string constants for application's permission names.
    /// <see cref="AppAuthorizationProvider"/> for permission definitions.
    /// </summary>
    public static class AppPermissions
    {
        public const string Pages_ClientAdditionalAccounts = "Pages.ClientAdditionalAccounts";
        public const string Pages_ClientAdditionalAccounts_Create = "Pages.ClientAdditionalAccounts.Create";
        public const string Pages_ClientAdditionalAccounts_Edit = "Pages.ClientAdditionalAccounts.Edit";
        public const string Pages_ClientAdditionalAccounts_Delete = "Pages.ClientAdditionalAccounts.Delete";

        public const string Pages_NonDiscretionalPortfolios = "Pages.NonDiscretionalPortfolios";
        public const string Pages_NonDiscretionalPortfolios_Create = "Pages.NonDiscretionalPortfolios.Create";
        public const string Pages_NonDiscretionalPortfolios_Edit = "Pages.NonDiscretionalPortfolios.Edit";
        public const string Pages_NonDiscretionalPortfolios_Delete = "Pages.NonDiscretionalPortfolios.Delete";

        public const string Pages_OnboardingSubscriptionDirectors = "Pages.OnboardingSubscriptionDirectors";
        public const string Pages_OnboardingSubscriptionDirectors_Create = "Pages.OnboardingSubscriptionDirectors.Create";
        public const string Pages_OnboardingSubscriptionDirectors_Edit = "Pages.OnboardingSubscriptionDirectors.Edit";
        public const string Pages_OnboardingSubscriptionDirectors_Delete = "Pages.OnboardingSubscriptionDirectors.Delete";

        public const string Pages_OnboardingSubscriptionSignatories = "Pages.OnboardingSubscriptionSignatories";
        public const string Pages_OnboardingSubscriptionSignatories_Create = "Pages.OnboardingSubscriptionSignatories.Create";
        public const string Pages_OnboardingSubscriptionSignatories_Edit = "Pages.OnboardingSubscriptionSignatories.Edit";
        public const string Pages_OnboardingSubscriptionSignatories_Delete = "Pages.OnboardingSubscriptionSignatories.Delete";

        public const string Pages_ManageBusinessConfigurations = "Pages.ManageBusinessConfigurations";
        public const string Pages_ManageBusinessConfigurations_Create = "Pages.ManageBusinessConfigurations.Create";
        public const string Pages_ManageBusinessConfigurations_Edit = "Pages.ManageBusinessConfigurations.Edit";
        public const string Pages_ManageBusinessConfigurations_Delete = "Pages.ManageBusinessConfigurations.Delete";

        public const string Pages_ManageSubLegalEntities = "Pages.ManageSubLegalEntities";
        public const string Pages_ManageSubLegalEntities_Create = "Pages.ManageSubLegalEntities.Create";
        public const string Pages_ManageSubLegalEntities_Edit = "Pages.ManageSubLegalEntities.Edit";
        public const string Pages_ManageSubLegalEntities_Delete = "Pages.ManageSubLegalEntities.Delete";

        public const string Pages_ManageLegalEntities = "Pages.ManageLegalEntities";
        public const string Pages_ManageLegalEntities_Create = "Pages.ManageLegalEntities.Create";
        public const string Pages_ManageLegalEntities_Edit = "Pages.ManageLegalEntities.Edit";
        public const string Pages_ManageLegalEntities_Delete = "Pages.ManageLegalEntities.Delete";

        public const string Pages_ManageDividendPaymentTypes = "Pages.ManageDividendPaymentTypes";
        public const string Pages_ManageDividendPaymentTypes_Create = "Pages.ManageDividendPaymentTypes.Create";
        public const string Pages_ManageDividendPaymentTypes_Edit = "Pages.ManageDividendPaymentTypes.Edit";
        public const string Pages_ManageDividendPaymentTypes_Delete = "Pages.ManageDividendPaymentTypes.Delete";

        //public const string Pages_OnboardingSubscriptionCustomerFunds = "Pages.OnboardingSubscriptionCustomerFunds";
        //public const string Pages_OnboardingSubscriptionCustomerFunds_Create = "Pages.OnboardingSubscriptionCustomerFunds.Create";
        //public const string Pages_OnboardingSubscriptionCustomerFunds_Edit = "Pages.OnboardingSubscriptionCustomerFunds.Edit";
        //public const string Pages_OnboardingSubscriptionCustomerFunds_Delete = "Pages.OnboardingSubscriptionCustomerFunds.Delete";

        //public const string Pages_Administration_ApprovalJournals = "Pages.Administration.ApprovalJournals";
        //public const string Pages_Administration_ApprovalJournals_Create = "Pages.Administration.ApprovalJournals.Create";
        //public const string Pages_Administration_ApprovalJournals_Edit = "Pages.Administration.ApprovalJournals.Edit";
        //public const string Pages_Administration_ApprovalJournals_Delete = "Pages.Administration.ApprovalJournals.Delete";

        //public const string Pages_ApprovalJournals = "Pages.ApprovalJournals";
        //public const string Pages_ApprovalJournals_Create = "Pages.ApprovalJournals.Create";
        //public const string Pages_ApprovalJournals_Edit = "Pages.ApprovalJournals.Edit";
        //public const string Pages_ApprovalJournals_Delete = "Pages.ApprovalJournals.Delete";

        public const string Pages_NAVService = "Pages.NAVService";
        public const string Pages_NAVService_GetUnitPrice = "Pages.NAVService.GetUnitPrice";
        public const string Pages_NAVService_FetchSalesAgents = "Pages.NAVService.FetchSalesAgents";
        public const string Pages_NAVService_NIPValidateAccount = "Pages.NAVService.NIPValidateAccount";
        public const string Pages_NAVService_BVNValidation = "Pages.NAVService.BVNValidation";
        public const string Pages_NAVService_LinkAccount = "Pages.NAVService.LinkAccount";
        public const string Pages_NAVService_GetAccountLinkId = "Pages.NAVService.GetAccountLinkId";

        //public const string Pages_OnboardingSubscriptionWorkPads = "Pages.OnboardingSubscriptionWorkPads";
        //public const string Pages_OnboardingSubscriptionWorkPads_Create = "Pages.OnboardingSubscriptionWorkPads.Create";
        //public const string Pages_OnboardingSubscriptionWorkPads_Edit = "Pages.OnboardingSubscriptionWorkPads.Edit";
        //public const string Pages_OnboardingSubscriptionWorkPads_Delete = "Pages.OnboardingSubscriptionWorkPads.Delete";

        public const string Pages_ManageTowns = "Pages.ManageTowns";
        public const string Pages_ManageTowns_Create = "Pages.ManageTowns.Create";
        public const string Pages_ManageTowns_Edit = "Pages.ManageTowns.Edit";
        public const string Pages_ManageTowns_Delete = "Pages.ManageTowns.Delete";

        public const string Pages_OnboardingSubscriptions = "Pages.OnboardingSubscriptions";
        public const string Pages_OnboardingSubscriptions_Create = "Pages.OnboardingSubscriptions.Create";
        public const string Pages_OnboardingSubscriptions_IndexingPage = "Pages.OnboardingSubscriptions.IndexingPage";
        public const string Pages_OnboardingSubscriptions_IndexApproval = "Pages.OnboardingSubscriptions.IndexApproval";
        public const string Pages_OnboardingSubscriptions_SecondApproval = "Pages.OnboardingSubscriptions.SecondApproval";
        public const string Pages_OnboardingSubscriptions_ApprovalReport = "Pages.OnboardingSubscriptions.ApprovalReport";
        public const string Pages_OnboardingSubscriptions_ApprovalJournal = "Pages.OnboardingSubscriptions.ApprovalJournal";
        public const string Pages_OnboardingSubscriptions_EntityHistory = "Pages.OnboardingSubscriptions.EntityHistory";
        public const string Pages_OnboardingSubscriptions_UserApprovalRecord = "Pages.OnboardingSubscriptions.UserApprovalRecord";
        public const string Pages_OnboardingSubscriptions_Edit = "Pages.OnboardingSubscriptions.Edit";
       // public const string Pages_OnboardingSubscriptions_Delete = "Pages.OnboardingSubscriptions.Delete";

        public const string Pages_ManageSectors = "Pages.ManageSectors";
        public const string Pages_ManageSectors_Create = "Pages.ManageSectors.Create";
        public const string Pages_ManageSectors_Edit = "Pages.ManageSectors.Edit";
        public const string Pages_ManageSectors_Delete = "Pages.ManageSectors.Delete";

        public const string Pages_ManageEducations = "Pages.ManageEducations";
        public const string Pages_ManageEducations_Create = "Pages.ManageEducations.Create";
        public const string Pages_ManageEducations_Edit = "Pages.ManageEducations.Edit";
        public const string Pages_ManageEducations_Delete = "Pages.ManageEducations.Delete";

        public const string Pages_ManageEmploymentStatuses = "Pages.ManageEmploymentStatuses";
        public const string Pages_ManageEmploymentStatuses_Create = "Pages.ManageEmploymentStatuses.Create";
        public const string Pages_ManageEmploymentStatuses_Edit = "Pages.ManageEmploymentStatuses.Edit";
        public const string Pages_ManageEmploymentStatuses_Delete = "Pages.ManageEmploymentStatuses.Delete";

        public const string Pages_ManageOnboardingPlatforms = "Pages.ManageOnboardingPlatforms";
        public const string Pages_ManageOnboardingPlatforms_Create = "Pages.ManageOnboardingPlatforms.Create";
        public const string Pages_ManageOnboardingPlatforms_Edit = "Pages.ManageOnboardingPlatforms.Edit";
        public const string Pages_ManageOnboardingPlatforms_Delete = "Pages.ManageOnboardingPlatforms.Delete";

        public const string Pages_ManagePaymentModes = "Pages.ManagePaymentModes";
        public const string Pages_ManagePaymentModes_Create = "Pages.ManagePaymentModes.Create";
        public const string Pages_ManagePaymentModes_Edit = "Pages.ManagePaymentModes.Edit";
        public const string Pages_ManagePaymentModes_Delete = "Pages.ManagePaymentModes.Delete";

        public const string Pages_ManageFundDetails = "Pages.ManageFundDetails";
        public const string Pages_ManageFundDetails_Create = "Pages.ManageFundDetails.Create";
        public const string Pages_ManageFundDetails_Edit = "Pages.ManageFundDetails.Edit";
        public const string Pages_ManageFundDetails_Delete = "Pages.ManageFundDetails.Delete";

        public const string Pages_ManageCurrencies = "Pages.ManageCurrencies";
        public const string Pages_ManageCurrencies_Create = "Pages.ManageCurrencies.Create";
        public const string Pages_ManageCurrencies_Edit = "Pages.ManageCurrencies.Edit";
        public const string Pages_ManageCurrencies_Delete = "Pages.ManageCurrencies.Delete";

        public const string Pages_ManageJobTypes = "Pages.ManageJobTypes";
        public const string Pages_ManageJobTypes_Create = "Pages.ManageJobTypes.Create";
        public const string Pages_ManageJobTypes_Edit = "Pages.ManageJobTypes.Edit";
        public const string Pages_ManageJobTypes_Delete = "Pages.ManageJobTypes.Delete";

        public const string Pages_ManageIdTypes = "Pages.ManageIdTypes";
        public const string Pages_ManageIdTypes_Create = "Pages.ManageIdTypes.Create";
        public const string Pages_ManageIdTypes_Edit = "Pages.ManageIdTypes.Edit";
        public const string Pages_ManageIdTypes_Delete = "Pages.ManageIdTypes.Delete";

        public const string Pages_ManageMarketingChannels = "Pages.ManageMarketingChannels";
        public const string Pages_ManageMarketingChannels_Create = "Pages.ManageMarketingChannels.Create";
        public const string Pages_ManageMarketingChannels_Edit = "Pages.ManageMarketingChannels.Edit";
        public const string Pages_ManageMarketingChannels_Delete = "Pages.ManageMarketingChannels.Delete";

        public const string Pages_ManageStockBrokers = "Pages.ManageStockBrokers";
        public const string Pages_ManageStockBrokers_Create = "Pages.ManageStockBrokers.Create";
        public const string Pages_ManageStockBrokers_Edit = "Pages.ManageStockBrokers.Edit";
        public const string Pages_ManageStockBrokers_Delete = "Pages.ManageStockBrokers.Delete";

        public const string Pages_ManageRelationships = "Pages.ManageRelationships";
        public const string Pages_ManageRelationships_Create = "Pages.ManageRelationships.Create";
        public const string Pages_ManageRelationships_Edit = "Pages.ManageRelationships.Edit";
        public const string Pages_ManageRelationships_Delete = "Pages.ManageRelationships.Delete";

        public const string Pages_ManageBanks = "Pages.ManageBanks";
        public const string Pages_ManageBanks_Create = "Pages.ManageBanks.Create";
        public const string Pages_ManageBanks_Edit = "Pages.ManageBanks.Edit";
        public const string Pages_ManageBanks_Delete = "Pages.ManageBanks.Delete";

        public const string Pages_ManageStates = "Pages.ManageStates";
        public const string Pages_ManageStates_Create = "Pages.ManageStates.Create";
        public const string Pages_ManageStates_Edit = "Pages.ManageStates.Edit";
        public const string Pages_ManageStates_Delete = "Pages.ManageStates.Delete";

        public const string Pages_ManageCountries = "Pages.ManageCountries";
        public const string Pages_ManageCountries_Create = "Pages.ManageCountries.Create";
        public const string Pages_ManageCountries_Edit = "Pages.ManageCountries.Edit";
        public const string Pages_ManageCountries_Delete = "Pages.ManageCountries.Delete";

        public const string Pages_ManageReligions = "Pages.ManageReligions";
        public const string Pages_ManageReligions_Create = "Pages.ManageReligions.Create";
        public const string Pages_ManageReligions_Edit = "Pages.ManageReligions.Edit";
        public const string Pages_ManageReligions_Delete = "Pages.ManageReligions.Delete";

        public const string Pages_ManageGenders = "Pages.ManageGenders";
        public const string Pages_ManageGenders_Create = "Pages.ManageGenders.Create";
        public const string Pages_ManageGenders_Edit = "Pages.ManageGenders.Edit";
        public const string Pages_ManageGenders_Delete = "Pages.ManageGenders.Delete";

        public const string Pages_ManageMaritalStatuses = "Pages.ManageMaritalStatuses";
        public const string Pages_ManageMaritalStatuses_Create = "Pages.ManageMaritalStatuses.Create";
        public const string Pages_ManageMaritalStatuses_Edit = "Pages.ManageMaritalStatuses.Edit";
        public const string Pages_ManageMaritalStatuses_Delete = "Pages.ManageMaritalStatuses.Delete";

        public const string Pages_ManageTitles = "Pages.ManageTitles";
        public const string Pages_ManageTitles_Create = "Pages.ManageTitles.Create";
        public const string Pages_ManageTitles_Edit = "Pages.ManageTitles.Edit";
        public const string Pages_ManageTitles_Delete = "Pages.ManageTitles.Delete";

        public const string Pages_ManageSubscriptionTypes = "Pages.ManageSubscriptionTypes";
        public const string Pages_ManageSubscriptionTypes_Create = "Pages.ManageSubscriptionTypes.Create";
        public const string Pages_ManageSubscriptionTypes_Edit = "Pages.ManageSubscriptionTypes.Edit";
        public const string Pages_ManageSubscriptionTypes_Delete = "Pages.ManageSubscriptionTypes.Delete";

        public const string Pages_SubscriptionWorkflows = "Pages.SubscriptionWorkflows";
        public const string Pages_SubscriptionWorkflows_Create = "Pages.SubscriptionWorkflows.Create";
        public const string Pages_SubscriptionWorkflows_Edit = "Pages.SubscriptionWorkflows.Edit";
        public const string Pages_SubscriptionWorkflows_Delete = "Pages.SubscriptionWorkflows.Delete";

        //public const string Pages_WorkflowManagements = "Pages.WorkflowManagements";
        //public const string Pages_WorkflowManagements_Create = "Pages.WorkflowManagements.Create";
        //public const string Pages_WorkflowManagements_Edit = "Pages.WorkflowManagements.Edit";
        //public const string Pages_WorkflowManagements_Delete = "Pages.WorkflowManagements.Delete";

        //COMMON PERMISSIONS (FOR BOTH OF TENANTS AND HOST)

        public const string Pages = "Pages";

        //public const string Pages_DemoUiComponents = "Pages.DemoUiComponents";
        public const string Pages_Administration = "Pages.Administration";

        public const string Pages_Administration_Roles = "Pages.Administration.Roles";
        public const string Pages_Administration_Roles_Create = "Pages.Administration.Roles.Create";
        public const string Pages_Administration_Roles_Edit = "Pages.Administration.Roles.Edit";
        public const string Pages_Administration_Roles_Delete = "Pages.Administration.Roles.Delete";

        public const string Pages_Administration_Users = "Pages.Administration.Users";
        public const string Pages_Administration_Users_Create = "Pages.Administration.Users.Create";
        public const string Pages_Administration_Users_Edit = "Pages.Administration.Users.Edit";
        public const string Pages_Administration_Users_Delete = "Pages.Administration.Users.Delete";
        public const string Pages_Administration_Users_ChangePermissions = "Pages.Administration.Users.ChangePermissions";
      //  public const string Pages_Administration_Users_Impersonation = "Pages.Administration.Users.Impersonation";
        public const string Pages_Administration_Users_Unlock = "Pages.Administration.Users.Unlock";
        public const string Pages_Administration_Users_ChangeProfilePicture = "Pages.Administration.Users.ChangeProfilePicture";

        public const string Pages_Administration_Languages = "Pages.Administration.Languages";
        public const string Pages_Administration_Languages_Create = "Pages.Administration.Languages.Create";
        public const string Pages_Administration_Languages_Edit = "Pages.Administration.Languages.Edit";
        public const string Pages_Administration_Languages_Delete = "Pages.Administration.Languages.Delete";
        public const string Pages_Administration_Languages_ChangeTexts = "Pages.Administration.Languages.ChangeTexts";
        public const string Pages_Administration_Languages_ChangeDefaultLanguage = "Pages.Administration.Languages.ChangeDefaultLanguage";

        public const string Pages_Administration_AuditLogs = "Pages.Administration.AuditLogs";

        public const string Pages_Administration_OrganizationUnits = "Pages.Administration.OrganizationUnits";
        public const string Pages_Administration_OrganizationUnits_ManageOrganizationTree = "Pages.Administration.OrganizationUnits.ManageOrganizationTree";
        public const string Pages_Administration_OrganizationUnits_ManageMembers = "Pages.Administration.OrganizationUnits.ManageMembers";
        public const string Pages_Administration_OrganizationUnits_ManageRoles = "Pages.Administration.OrganizationUnits.ManageRoles";

        public const string Pages_Administration_HangfireDashboard = "Pages.Administration.HangfireDashboard";

      //  public const string Pages_Administration_UiCustomization = "Pages.Administration.UiCustomization";

        public const string Pages_Administration_WebhookSubscription = "Pages.Administration.WebhookSubscription";
        public const string Pages_Administration_WebhookSubscription_Create = "Pages.Administration.WebhookSubscription.Create";
        public const string Pages_Administration_WebhookSubscription_Edit = "Pages.Administration.WebhookSubscription.Edit";
        public const string Pages_Administration_WebhookSubscription_ChangeActivity = "Pages.Administration.WebhookSubscription.ChangeActivity";
        public const string Pages_Administration_WebhookSubscription_Detail = "Pages.Administration.WebhookSubscription.Detail";
        public const string Pages_Administration_Webhook_ListSendAttempts = "Pages.Administration.Webhook.ListSendAttempts";
        public const string Pages_Administration_Webhook_ResendWebhook = "Pages.Administration.Webhook.ResendWebhook";

        public const string Pages_Administration_DynamicProperties = "Pages.Administration.DynamicProperties";
        public const string Pages_Administration_DynamicProperties_Create = "Pages.Administration.DynamicProperties.Create";
        public const string Pages_Administration_DynamicProperties_Edit = "Pages.Administration.DynamicProperties.Edit";
        public const string Pages_Administration_DynamicProperties_Delete = "Pages.Administration.DynamicProperties.Delete";

        public const string Pages_Administration_DynamicPropertyValue = "Pages.Administration.DynamicPropertyValue";
        public const string Pages_Administration_DynamicPropertyValue_Create = "Pages.Administration.DynamicPropertyValue.Create";
        public const string Pages_Administration_DynamicPropertyValue_Edit = "Pages.Administration.DynamicPropertyValue.Edit";
        public const string Pages_Administration_DynamicPropertyValue_Delete = "Pages.Administration.DynamicPropertyValue.Delete";

        public const string Pages_Administration_DynamicEntityProperties = "Pages.Administration.DynamicEntityProperties";
        public const string Pages_Administration_DynamicEntityProperties_Create = "Pages.Administration.DynamicEntityProperties.Create";
        public const string Pages_Administration_DynamicEntityProperties_Edit = "Pages.Administration.DynamicEntityProperties.Edit";
        public const string Pages_Administration_DynamicEntityProperties_Delete = "Pages.Administration.DynamicEntityProperties.Delete";

        public const string Pages_Administration_DynamicEntityPropertyValue = "Pages.Administration.DynamicEntityPropertyValue";
        public const string Pages_Administration_DynamicEntityPropertyValue_Create = "Pages.Administration.DynamicEntityPropertyValue.Create";
        public const string Pages_Administration_DynamicEntityPropertyValue_Edit = "Pages.Administration.DynamicEntityPropertyValue.Edit";
        public const string Pages_Administration_DynamicEntityPropertyValue_Delete = "Pages.Administration.DynamicEntityPropertyValue.Delete";

        public const string Pages_Workflows = "Pages.Workflows";

        public const string Pages_Administration_MassNotification = "Pages.Administration.MassNotification";
        public const string Pages_Administration_MassNotification_Create = "Pages.Administration.MassNotification.Create";

      //  public const string Pages_Administration_NewVersion_Create = "Pages_Administration_NewVersion_Create";

        //TENANT-SPECIFIC PERMISSIONS

        public const string Pages_Tenant_Dashboard = "Pages.Tenant.Dashboard";

        public const string Pages_Administration_Tenant_Settings = "Pages.Administration.Tenant.Settings";

       // public const string Pages_Administration_Tenant_SubscriptionManagement = "Pages.Administration.Tenant.SubscriptionManagement";

        //HOST-SPECIFIC PERMISSIONS

        public const string Pages_Editions = "Pages.Editions";
        public const string Pages_Editions_Create = "Pages.Editions.Create";
        public const string Pages_Editions_Edit = "Pages.Editions.Edit";
        public const string Pages_Editions_Delete = "Pages.Editions.Delete";
        public const string Pages_Editions_MoveTenantsToAnotherEdition = "Pages.Editions.MoveTenantsToAnotherEdition";

        public const string Pages_Tenants = "Pages.Tenants";
        public const string Pages_Tenants_Create = "Pages.Tenants.Create";
        public const string Pages_Tenants_Edit = "Pages.Tenants.Edit";
        public const string Pages_Tenants_ChangeFeatures = "Pages.Tenants.ChangeFeatures";
        public const string Pages_Tenants_Delete = "Pages.Tenants.Delete";
        public const string Pages_Tenants_Impersonation = "Pages.Tenants.Impersonation";

        public const string Pages_Administration_Host_Maintenance = "Pages.Administration.Host.Maintenance";
        public const string Pages_Administration_Host_Settings = "Pages.Administration.Host.Settings";
        public const string Pages_Administration_Host_Dashboard = "Pages.Administration.Host.Dashboard";
    }
}