﻿using Abp.Authorization;
using Abp.Configuration.Startup;
using Abp.Localization;
using Abp.MultiTenancy;

namespace SIAML.Middleware.Authorization
{
    /// <summary>
    /// Application's authorization provider.
    /// Defines permissions for the application.
    /// See <see cref="AppPermissions"/> for all permission names.
    /// </summary>
    public class AppAuthorizationProvider : AuthorizationProvider
    {
        private readonly bool _isMultiTenancyEnabled;

        public AppAuthorizationProvider(bool isMultiTenancyEnabled)
        {
            _isMultiTenancyEnabled = isMultiTenancyEnabled;
        }

        public AppAuthorizationProvider(IMultiTenancyConfig multiTenancyConfig)
        {
            _isMultiTenancyEnabled = multiTenancyConfig.IsEnabled;
        }

        public override void SetPermissions(IPermissionDefinitionContext context)
        {
            //COMMON PERMISSIONS (FOR BOTH OF TENANTS AND HOST)

            var pages = context.GetPermissionOrNull(AppPermissions.Pages) ?? context.CreatePermission(AppPermissions.Pages, L("Pages"));

            var clientAdditionalAccounts = pages.CreateChildPermission(AppPermissions.Pages_ClientAdditionalAccounts, L("ClientAdditionalAccounts"));
            clientAdditionalAccounts.CreateChildPermission(AppPermissions.Pages_ClientAdditionalAccounts_Create, L("CreateNewClientAdditionalAccount"));
            clientAdditionalAccounts.CreateChildPermission(AppPermissions.Pages_ClientAdditionalAccounts_Edit, L("EditClientAdditionalAccount"));
            clientAdditionalAccounts.CreateChildPermission(AppPermissions.Pages_ClientAdditionalAccounts_Delete, L("DeleteClientAdditionalAccount"));

            var nonDiscretionalPortfolios = pages.CreateChildPermission(AppPermissions.Pages_NonDiscretionalPortfolios, L("NonDiscretionalPortfolios"));
            nonDiscretionalPortfolios.CreateChildPermission(AppPermissions.Pages_NonDiscretionalPortfolios_Create, L("CreateNewNonDiscretionalPortfolio"));
            nonDiscretionalPortfolios.CreateChildPermission(AppPermissions.Pages_NonDiscretionalPortfolios_Edit, L("EditNonDiscretionalPortfolio"));
            nonDiscretionalPortfolios.CreateChildPermission(AppPermissions.Pages_NonDiscretionalPortfolios_Delete, L("DeleteNonDiscretionalPortfolio"));

            //var onboardingSubscriptionWorkPads = pages.CreateChildPermission(AppPermissions.Pages_OnboardingSubscriptionWorkPads, L("OnboardingSubscriptionWorkPads"));
            //onboardingSubscriptionWorkPads.CreateChildPermission(AppPermissions.Pages_OnboardingSubscriptionWorkPads_Create, L("CreateNewOnboardingSubscriptionWorkPad"));
            //onboardingSubscriptionWorkPads.CreateChildPermission(AppPermissions.Pages_OnboardingSubscriptionWorkPads_Edit, L("EditOnboardingSubscriptionWorkPad"));
            //onboardingSubscriptionWorkPads.CreateChildPermission(AppPermissions.Pages_OnboardingSubscriptionWorkPads_Delete, L("DeleteOnboardingSubscriptionWorkPad"));

            //var onboardingSubscriptionDirectors = pages.CreateChildPermission(AppPermissions.Pages_OnboardingSubscriptionDirectors, L("OnboardingSubscriptionDirectors"));
            //onboardingSubscriptionDirectors.CreateChildPermission(AppPermissions.Pages_OnboardingSubscriptionDirectors_Create, L("CreateNewOnboardingSubscriptionDirector"));
            //onboardingSubscriptionDirectors.CreateChildPermission(AppPermissions.Pages_OnboardingSubscriptionDirectors_Edit, L("EditOnboardingSubscriptionDirector"));
            //onboardingSubscriptionDirectors.CreateChildPermission(AppPermissions.Pages_OnboardingSubscriptionDirectors_Delete, L("DeleteOnboardingSubscriptionDirector"));

            //var onboardingSubscriptionSignatories = pages.CreateChildPermission(AppPermissions.Pages_OnboardingSubscriptionSignatories, L("OnboardingSubscriptionSignatories"));
            //onboardingSubscriptionSignatories.CreateChildPermission(AppPermissions.Pages_OnboardingSubscriptionSignatories_Create, L("CreateNewOnboardingSubscriptionSignatory"));
            //onboardingSubscriptionSignatories.CreateChildPermission(AppPermissions.Pages_OnboardingSubscriptionSignatories_Edit, L("EditOnboardingSubscriptionSignatory"));
            //onboardingSubscriptionSignatories.CreateChildPermission(AppPermissions.Pages_OnboardingSubscriptionSignatories_Delete, L("DeleteOnboardingSubscriptionSignatory"));

            var manageBusinessConfigurations = pages.CreateChildPermission(AppPermissions.Pages_ManageBusinessConfigurations, L("ManageBusinessConfigurations"));
            manageBusinessConfigurations.CreateChildPermission(AppPermissions.Pages_ManageBusinessConfigurations_Create, L("CreateNewManageBusinessConfiguration"));
            manageBusinessConfigurations.CreateChildPermission(AppPermissions.Pages_ManageBusinessConfigurations_Edit, L("EditManageBusinessConfiguration"));
            manageBusinessConfigurations.CreateChildPermission(AppPermissions.Pages_ManageBusinessConfigurations_Delete, L("DeleteManageBusinessConfiguration"));

            var manageSubLegalEntities = pages.CreateChildPermission(AppPermissions.Pages_ManageSubLegalEntities, L("ManageSubLegalEntities"));
            manageSubLegalEntities.CreateChildPermission(AppPermissions.Pages_ManageSubLegalEntities_Create, L("CreateNewManageSubLegalEntity"));
            manageSubLegalEntities.CreateChildPermission(AppPermissions.Pages_ManageSubLegalEntities_Edit, L("EditManageSubLegalEntity"));
            manageSubLegalEntities.CreateChildPermission(AppPermissions.Pages_ManageSubLegalEntities_Delete, L("DeleteManageSubLegalEntity"));

            var manageLegalEntities = pages.CreateChildPermission(AppPermissions.Pages_ManageLegalEntities, L("ManageLegalEntities"));
            manageLegalEntities.CreateChildPermission(AppPermissions.Pages_ManageLegalEntities_Create, L("CreateNewManageLegalEntity"));
            manageLegalEntities.CreateChildPermission(AppPermissions.Pages_ManageLegalEntities_Edit, L("EditManageLegalEntity"));
            manageLegalEntities.CreateChildPermission(AppPermissions.Pages_ManageLegalEntities_Delete, L("DeleteManageLegalEntity"));

            var manageDividendPaymentTypes = pages.CreateChildPermission(AppPermissions.Pages_ManageDividendPaymentTypes, L("ManageDividendPaymentTypes"));
            manageDividendPaymentTypes.CreateChildPermission(AppPermissions.Pages_ManageDividendPaymentTypes_Create, L("CreateNewManageDividendPaymentType"));
            manageDividendPaymentTypes.CreateChildPermission(AppPermissions.Pages_ManageDividendPaymentTypes_Edit, L("EditManageDividendPaymentType"));
            manageDividendPaymentTypes.CreateChildPermission(AppPermissions.Pages_ManageDividendPaymentTypes_Delete, L("DeleteManageDividendPaymentType"));

            //var onboardingSubscriptionCustomerFunds = pages.CreateChildPermission(AppPermissions.Pages_OnboardingSubscriptionCustomerFunds, L("OnboardingSubscriptionCustomerFunds"));
            //onboardingSubscriptionCustomerFunds.CreateChildPermission(AppPermissions.Pages_OnboardingSubscriptionCustomerFunds_Create, L("CreateNewOnboardingSubscriptionCustomerFund"));
            //onboardingSubscriptionCustomerFunds.CreateChildPermission(AppPermissions.Pages_OnboardingSubscriptionCustomerFunds_Edit, L("EditOnboardingSubscriptionCustomerFund"));
            //onboardingSubscriptionCustomerFunds.CreateChildPermission(AppPermissions.Pages_OnboardingSubscriptionCustomerFunds_Delete, L("DeleteOnboardingSubscriptionCustomerFund"));

            //var onboardingSubscriptionWorkPads = pages.CreateChildPermission(AppPermissions.Pages_OnboardingSubscriptionWorkPads, L("OnboardingSubscriptionWorkPads"));
            //onboardingSubscriptionWorkPads.CreateChildPermission(AppPermissions.Pages_OnboardingSubscriptionWorkPads_Create, L("CreateNewOnboardingSubscriptionWorkPad"));
            //onboardingSubscriptionWorkPads.CreateChildPermission(AppPermissions.Pages_OnboardingSubscriptionWorkPads_Edit, L("EditOnboardingSubscriptionWorkPad"));
            //onboardingSubscriptionWorkPads.CreateChildPermission(AppPermissions.Pages_OnboardingSubscriptionWorkPads_Delete, L("DeleteOnboardingSubscriptionWorkPad"));

            var navServices = pages.CreateChildPermission(AppPermissions.Pages_NAVService, L("NAVService"));
            navServices.CreateChildPermission(AppPermissions.Pages_NAVService_GetUnitPrice, L("GetUnitPrice"));
            navServices.CreateChildPermission(AppPermissions.Pages_NAVService_FetchSalesAgents, L("FetchSalesAgents"));
            navServices.CreateChildPermission(AppPermissions.Pages_NAVService_NIPValidateAccount, L("NIPValidateAccount"));
            navServices.CreateChildPermission(AppPermissions.Pages_NAVService_BVNValidation, L("BVNValidation"));
            navServices.CreateChildPermission(AppPermissions.Pages_NAVService_LinkAccount, L("LinkAccount"));
            navServices.CreateChildPermission(AppPermissions.Pages_NAVService_GetAccountLinkId, L("GetAccountLinkId"));

            var manageTowns = pages.CreateChildPermission(AppPermissions.Pages_ManageTowns, L("ManageTowns"));
            manageTowns.CreateChildPermission(AppPermissions.Pages_ManageTowns_Create, L("CreateNewManageTown"));
            manageTowns.CreateChildPermission(AppPermissions.Pages_ManageTowns_Edit, L("EditManageTown"));
            manageTowns.CreateChildPermission(AppPermissions.Pages_ManageTowns_Delete, L("DeleteManageTown"));

            var onboardingSubscriptions = pages.CreateChildPermission(AppPermissions.Pages_OnboardingSubscriptions, L("SubscriptionManagement"));
            onboardingSubscriptions.CreateChildPermission(AppPermissions.Pages_OnboardingSubscriptions_Create, L("CreateNewOnboardingSubscription"));
            onboardingSubscriptions.CreateChildPermission(AppPermissions.Pages_OnboardingSubscriptions_IndexingPage, L("IndexingPage"));
            onboardingSubscriptions.CreateChildPermission(AppPermissions.Pages_OnboardingSubscriptions_IndexApproval, L("IndexSubscription"));
            onboardingSubscriptions.CreateChildPermission(AppPermissions.Pages_OnboardingSubscriptions_SecondApproval, L("PendingSecondApproval"));
            onboardingSubscriptions.CreateChildPermission(AppPermissions.Pages_OnboardingSubscriptions_ApprovalReport, L("ApprovalHistoryReport"));
            onboardingSubscriptions.CreateChildPermission(AppPermissions.Pages_OnboardingSubscriptions_UserApprovalRecord, L("MysubscriptionRecords"));
            onboardingSubscriptions.CreateChildPermission(AppPermissions.Pages_OnboardingSubscriptions_ApprovalJournal, L("ApprovalJournal"));
            onboardingSubscriptions.CreateChildPermission(AppPermissions.Pages_OnboardingSubscriptions_EntityHistory, L("EntityHistory"));
            onboardingSubscriptions.CreateChildPermission(AppPermissions.Pages_OnboardingSubscriptions_Edit, L("EditOnboardingSubscription"));
            //  onboardingSubscriptions.CreateChildPermission(AppPermissions.Pages_OnboardingSubscriptions_Delete, L("DeleteOnboardingSubscription"));

            var manageSectors = pages.CreateChildPermission(AppPermissions.Pages_ManageSectors, L("ManageSectors"));
            manageSectors.CreateChildPermission(AppPermissions.Pages_ManageSectors_Create, L("CreateNewManageSector"));
            manageSectors.CreateChildPermission(AppPermissions.Pages_ManageSectors_Edit, L("EditManageSector"));
            manageSectors.CreateChildPermission(AppPermissions.Pages_ManageSectors_Delete, L("DeleteManageSector"));

            var manageEducations = pages.CreateChildPermission(AppPermissions.Pages_ManageEducations, L("ManageEducations"));
            manageEducations.CreateChildPermission(AppPermissions.Pages_ManageEducations_Create, L("CreateNewManageEducation"));
            manageEducations.CreateChildPermission(AppPermissions.Pages_ManageEducations_Edit, L("EditManageEducation"));
            manageEducations.CreateChildPermission(AppPermissions.Pages_ManageEducations_Delete, L("DeleteManageEducation"));

            var manageEmploymentStatuses = pages.CreateChildPermission(AppPermissions.Pages_ManageEmploymentStatuses, L("ManageEmploymentStatuses"));
            manageEmploymentStatuses.CreateChildPermission(AppPermissions.Pages_ManageEmploymentStatuses_Create, L("CreateNewManageEmploymentStatus"));
            manageEmploymentStatuses.CreateChildPermission(AppPermissions.Pages_ManageEmploymentStatuses_Edit, L("EditManageEmploymentStatus"));
            manageEmploymentStatuses.CreateChildPermission(AppPermissions.Pages_ManageEmploymentStatuses_Delete, L("DeleteManageEmploymentStatus"));

            var manageOnboardingPlatforms = pages.CreateChildPermission(AppPermissions.Pages_ManageOnboardingPlatforms, L("ManageOnboardingPlatforms"));
            manageOnboardingPlatforms.CreateChildPermission(AppPermissions.Pages_ManageOnboardingPlatforms_Create, L("CreateNewManageOnboardingPlatform"));
            manageOnboardingPlatforms.CreateChildPermission(AppPermissions.Pages_ManageOnboardingPlatforms_Edit, L("EditManageOnboardingPlatform"));
            manageOnboardingPlatforms.CreateChildPermission(AppPermissions.Pages_ManageOnboardingPlatforms_Delete, L("DeleteManageOnboardingPlatform"));

            var managePaymentModes = pages.CreateChildPermission(AppPermissions.Pages_ManagePaymentModes, L("ManagePaymentModes"));
            managePaymentModes.CreateChildPermission(AppPermissions.Pages_ManagePaymentModes_Create, L("CreateNewManagePaymentMode"));
            managePaymentModes.CreateChildPermission(AppPermissions.Pages_ManagePaymentModes_Edit, L("EditManagePaymentMode"));
            managePaymentModes.CreateChildPermission(AppPermissions.Pages_ManagePaymentModes_Delete, L("DeleteManagePaymentMode"));

            var manageFundDetails = pages.CreateChildPermission(AppPermissions.Pages_ManageFundDetails, L("ManageFundDetails"));
            manageFundDetails.CreateChildPermission(AppPermissions.Pages_ManageFundDetails_Create, L("CreateNewManageFundDetail"));
            manageFundDetails.CreateChildPermission(AppPermissions.Pages_ManageFundDetails_Edit, L("EditManageFundDetail"));
            manageFundDetails.CreateChildPermission(AppPermissions.Pages_ManageFundDetails_Delete, L("DeleteManageFundDetail"));

            var manageCurrencies = pages.CreateChildPermission(AppPermissions.Pages_ManageCurrencies, L("ManageCurrencies"));
            manageCurrencies.CreateChildPermission(AppPermissions.Pages_ManageCurrencies_Create, L("CreateNewManageCurrency"));
            manageCurrencies.CreateChildPermission(AppPermissions.Pages_ManageCurrencies_Edit, L("EditManageCurrency"));
            manageCurrencies.CreateChildPermission(AppPermissions.Pages_ManageCurrencies_Delete, L("DeleteManageCurrency"));

            var manageJobTypes = pages.CreateChildPermission(AppPermissions.Pages_ManageJobTypes, L("ManageJobTypes"));
            manageJobTypes.CreateChildPermission(AppPermissions.Pages_ManageJobTypes_Create, L("CreateNewManageJobType"));
            manageJobTypes.CreateChildPermission(AppPermissions.Pages_ManageJobTypes_Edit, L("EditManageJobType"));
            manageJobTypes.CreateChildPermission(AppPermissions.Pages_ManageJobTypes_Delete, L("DeleteManageJobType"));

            var manageIdTypes = pages.CreateChildPermission(AppPermissions.Pages_ManageIdTypes, L("ManageIdTypes"));
            manageIdTypes.CreateChildPermission(AppPermissions.Pages_ManageIdTypes_Create, L("CreateNewManageIdType"));
            manageIdTypes.CreateChildPermission(AppPermissions.Pages_ManageIdTypes_Edit, L("EditManageIdType"));
            manageIdTypes.CreateChildPermission(AppPermissions.Pages_ManageIdTypes_Delete, L("DeleteManageIdType"));

            var manageMarketingChannels = pages.CreateChildPermission(AppPermissions.Pages_ManageMarketingChannels, L("ManageMarketingChannels"));
            manageMarketingChannels.CreateChildPermission(AppPermissions.Pages_ManageMarketingChannels_Create, L("CreateNewManageMarketingChannel"));
            manageMarketingChannels.CreateChildPermission(AppPermissions.Pages_ManageMarketingChannels_Edit, L("EditManageMarketingChannel"));
            manageMarketingChannels.CreateChildPermission(AppPermissions.Pages_ManageMarketingChannels_Delete, L("DeleteManageMarketingChannel"));

            var manageStockBrokers = pages.CreateChildPermission(AppPermissions.Pages_ManageStockBrokers, L("ManageStockBrokers"));
            manageStockBrokers.CreateChildPermission(AppPermissions.Pages_ManageStockBrokers_Create, L("CreateNewManageStockBroker"));
            manageStockBrokers.CreateChildPermission(AppPermissions.Pages_ManageStockBrokers_Edit, L("EditManageStockBroker"));
            manageStockBrokers.CreateChildPermission(AppPermissions.Pages_ManageStockBrokers_Delete, L("DeleteManageStockBroker"));

            var manageRelationships = pages.CreateChildPermission(AppPermissions.Pages_ManageRelationships, L("ManageRelationships"));
            manageRelationships.CreateChildPermission(AppPermissions.Pages_ManageRelationships_Create, L("CreateNewManageRelationship"));
            manageRelationships.CreateChildPermission(AppPermissions.Pages_ManageRelationships_Edit, L("EditManageRelationship"));
            manageRelationships.CreateChildPermission(AppPermissions.Pages_ManageRelationships_Delete, L("DeleteManageRelationship"));

            var manageBanks = pages.CreateChildPermission(AppPermissions.Pages_ManageBanks, L("ManageBanks"));
            manageBanks.CreateChildPermission(AppPermissions.Pages_ManageBanks_Create, L("CreateNewManageBank"));
            manageBanks.CreateChildPermission(AppPermissions.Pages_ManageBanks_Edit, L("EditManageBank"));
            manageBanks.CreateChildPermission(AppPermissions.Pages_ManageBanks_Delete, L("DeleteManageBank"));

            var manageStates = pages.CreateChildPermission(AppPermissions.Pages_ManageStates, L("ManageStates"));
            manageStates.CreateChildPermission(AppPermissions.Pages_ManageStates_Create, L("CreateNewManageState"));
            manageStates.CreateChildPermission(AppPermissions.Pages_ManageStates_Edit, L("EditManageState"));
            manageStates.CreateChildPermission(AppPermissions.Pages_ManageStates_Delete, L("DeleteManageState"));

            var manageCountries = pages.CreateChildPermission(AppPermissions.Pages_ManageCountries, L("ManageCountries"));
            manageCountries.CreateChildPermission(AppPermissions.Pages_ManageCountries_Create, L("CreateNewManageCountry"));
            manageCountries.CreateChildPermission(AppPermissions.Pages_ManageCountries_Edit, L("EditManageCountry"));
            manageCountries.CreateChildPermission(AppPermissions.Pages_ManageCountries_Delete, L("DeleteManageCountry"));

            var manageReligions = pages.CreateChildPermission(AppPermissions.Pages_ManageReligions, L("ManageReligions"));
            manageReligions.CreateChildPermission(AppPermissions.Pages_ManageReligions_Create, L("CreateNewManageReligion"));
            manageReligions.CreateChildPermission(AppPermissions.Pages_ManageReligions_Edit, L("EditManageReligion"));
            manageReligions.CreateChildPermission(AppPermissions.Pages_ManageReligions_Delete, L("DeleteManageReligion"));

            var manageGenders = pages.CreateChildPermission(AppPermissions.Pages_ManageGenders, L("ManageGenders"));
            manageGenders.CreateChildPermission(AppPermissions.Pages_ManageGenders_Create, L("CreateNewManageGender"));
            manageGenders.CreateChildPermission(AppPermissions.Pages_ManageGenders_Edit, L("EditManageGender"));
            manageGenders.CreateChildPermission(AppPermissions.Pages_ManageGenders_Delete, L("DeleteManageGender"));

            var manageMaritalStatuses = pages.CreateChildPermission(AppPermissions.Pages_ManageMaritalStatuses, L("ManageMaritalStatuses"));
            manageMaritalStatuses.CreateChildPermission(AppPermissions.Pages_ManageMaritalStatuses_Create, L("CreateNewManageMaritalStatus"));
            manageMaritalStatuses.CreateChildPermission(AppPermissions.Pages_ManageMaritalStatuses_Edit, L("EditManageMaritalStatus"));
            manageMaritalStatuses.CreateChildPermission(AppPermissions.Pages_ManageMaritalStatuses_Delete, L("DeleteManageMaritalStatus"));

            var manageTitles = pages.CreateChildPermission(AppPermissions.Pages_ManageTitles, L("ManageTitles"));
            manageTitles.CreateChildPermission(AppPermissions.Pages_ManageTitles_Create, L("CreateNewManageTitle"));
            manageTitles.CreateChildPermission(AppPermissions.Pages_ManageTitles_Edit, L("EditManageTitle"));
            manageTitles.CreateChildPermission(AppPermissions.Pages_ManageTitles_Delete, L("DeleteManageTitle"));

            var manageSubscriptionTypes = pages.CreateChildPermission(AppPermissions.Pages_ManageSubscriptionTypes, L("ManageSubscriptionTypes"));
            manageSubscriptionTypes.CreateChildPermission(AppPermissions.Pages_ManageSubscriptionTypes_Create, L("CreateNewManageSubscriptionType"));
            manageSubscriptionTypes.CreateChildPermission(AppPermissions.Pages_ManageSubscriptionTypes_Edit, L("EditManageSubscriptionType"));
            manageSubscriptionTypes.CreateChildPermission(AppPermissions.Pages_ManageSubscriptionTypes_Delete, L("DeleteManageSubscriptionType"));

            //var subscriptionWorkflows = pages.CreateChildPermission(AppPermissions.Pages_SubscriptionWorkflows, L("SubscriptionWorkflows"));
            //subscriptionWorkflows.CreateChildPermission(AppPermissions.Pages_SubscriptionWorkflows_Create, L("CreateNewSubscriptionWorkflow"));
            //subscriptionWorkflows.CreateChildPermission(AppPermissions.Pages_SubscriptionWorkflows_Edit, L("EditSubscriptionWorkflow"));
            //subscriptionWorkflows.CreateChildPermission(AppPermissions.Pages_SubscriptionWorkflows_Delete, L("DeleteSubscriptionWorkflow"));

            //var workflowManagements = pages.CreateChildPermission(AppPermissions.Pages_WorkflowManagements, L("WorkflowManagements"));
            //workflowManagements.CreateChildPermission(AppPermissions.Pages_WorkflowManagements_Create, L("CreateNewWorkflowManagement"));
            //workflowManagements.CreateChildPermission(AppPermissions.Pages_WorkflowManagements_Edit, L("EditWorkflowManagement"));
            //workflowManagements.CreateChildPermission(AppPermissions.Pages_WorkflowManagements_Delete, L("DeleteWorkflowManagement"));

            // pages.CreateChildPermission(AppPermissions.Pages_DemoUiComponents, L("DemoUiComponents"));

            pages.CreateChildPermission(AppPermissions.Pages_Workflows, L("Workflows"));

            var administration = pages.CreateChildPermission(AppPermissions.Pages_Administration, L("Administration"));

            var roles = administration.CreateChildPermission(AppPermissions.Pages_Administration_Roles, L("Roles"));
            roles.CreateChildPermission(AppPermissions.Pages_Administration_Roles_Create, L("CreatingNewRole"));
            roles.CreateChildPermission(AppPermissions.Pages_Administration_Roles_Edit, L("EditingRole"));
            roles.CreateChildPermission(AppPermissions.Pages_Administration_Roles_Delete, L("DeletingRole"));

            var users = administration.CreateChildPermission(AppPermissions.Pages_Administration_Users, L("Users"));
            users.CreateChildPermission(AppPermissions.Pages_Administration_Users_Create, L("CreatingNewUser"));
            users.CreateChildPermission(AppPermissions.Pages_Administration_Users_Edit, L("EditingUser"));
            users.CreateChildPermission(AppPermissions.Pages_Administration_Users_Delete, L("DeletingUser"));
            users.CreateChildPermission(AppPermissions.Pages_Administration_Users_ChangePermissions, L("ChangingPermissions"));
            //  users.CreateChildPermission(AppPermissions.Pages_Administration_Users_Impersonation, L("LoginForUsers"));
            users.CreateChildPermission(AppPermissions.Pages_Administration_Users_Unlock, L("Unlock"));
            users.CreateChildPermission(AppPermissions.Pages_Administration_Users_ChangeProfilePicture, L("UpdateUsersProfilePicture"));

            var languages = administration.CreateChildPermission(AppPermissions.Pages_Administration_Languages, L("Languages"));
            languages.CreateChildPermission(AppPermissions.Pages_Administration_Languages_Create, L("CreatingNewLanguage"), multiTenancySides: _isMultiTenancyEnabled ? MultiTenancySides.Host : MultiTenancySides.Tenant);
            languages.CreateChildPermission(AppPermissions.Pages_Administration_Languages_Edit, L("EditingLanguage"), multiTenancySides: _isMultiTenancyEnabled ? MultiTenancySides.Host : MultiTenancySides.Tenant);
            languages.CreateChildPermission(AppPermissions.Pages_Administration_Languages_Delete, L("DeletingLanguages"), multiTenancySides: _isMultiTenancyEnabled ? MultiTenancySides.Host : MultiTenancySides.Tenant);
            languages.CreateChildPermission(AppPermissions.Pages_Administration_Languages_ChangeTexts, L("ChangingTexts"));
            languages.CreateChildPermission(AppPermissions.Pages_Administration_Languages_ChangeDefaultLanguage, L("ChangeDefaultLanguage"));

            administration.CreateChildPermission(AppPermissions.Pages_Administration_AuditLogs, L("AuditLogs"));

            var organizationUnits = administration.CreateChildPermission(AppPermissions.Pages_Administration_OrganizationUnits, L("OrganizationUnits"));
            organizationUnits.CreateChildPermission(AppPermissions.Pages_Administration_OrganizationUnits_ManageOrganizationTree, L("ManagingOrganizationTree"));
            organizationUnits.CreateChildPermission(AppPermissions.Pages_Administration_OrganizationUnits_ManageMembers, L("ManagingMembers"));
            organizationUnits.CreateChildPermission(AppPermissions.Pages_Administration_OrganizationUnits_ManageRoles, L("ManagingRoles"));

            //administration.CreateChildPermission(AppPermissions.Pages_Administration_UiCustomization, L("VisualSettings"));

            var webhooks = administration.CreateChildPermission(AppPermissions.Pages_Administration_WebhookSubscription, L("Webhooks"));
            webhooks.CreateChildPermission(AppPermissions.Pages_Administration_WebhookSubscription_Create, L("CreatingWebhooks"));
            webhooks.CreateChildPermission(AppPermissions.Pages_Administration_WebhookSubscription_Edit, L("EditingWebhooks"));
            webhooks.CreateChildPermission(AppPermissions.Pages_Administration_WebhookSubscription_ChangeActivity, L("ChangingWebhookActivity"));
            webhooks.CreateChildPermission(AppPermissions.Pages_Administration_WebhookSubscription_Detail, L("DetailingSubscription"));
            webhooks.CreateChildPermission(AppPermissions.Pages_Administration_Webhook_ListSendAttempts, L("ListingSendAttempts"));
            webhooks.CreateChildPermission(AppPermissions.Pages_Administration_Webhook_ResendWebhook, L("ResendingWebhook"));

            var dynamicProperties = administration.CreateChildPermission(AppPermissions.Pages_Administration_DynamicProperties, L("DynamicProperties"));
            dynamicProperties.CreateChildPermission(AppPermissions.Pages_Administration_DynamicProperties_Create, L("CreatingDynamicProperties"));
            dynamicProperties.CreateChildPermission(AppPermissions.Pages_Administration_DynamicProperties_Edit, L("EditingDynamicProperties"));
            dynamicProperties.CreateChildPermission(AppPermissions.Pages_Administration_DynamicProperties_Delete, L("DeletingDynamicProperties"));

            var dynamicPropertyValues = dynamicProperties.CreateChildPermission(AppPermissions.Pages_Administration_DynamicPropertyValue, L("DynamicPropertyValue"));
            dynamicPropertyValues.CreateChildPermission(AppPermissions.Pages_Administration_DynamicPropertyValue_Create, L("CreatingDynamicPropertyValue"));
            dynamicPropertyValues.CreateChildPermission(AppPermissions.Pages_Administration_DynamicPropertyValue_Edit, L("EditingDynamicPropertyValue"));
            dynamicPropertyValues.CreateChildPermission(AppPermissions.Pages_Administration_DynamicPropertyValue_Delete, L("DeletingDynamicPropertyValue"));

            var dynamicEntityProperties = dynamicProperties.CreateChildPermission(AppPermissions.Pages_Administration_DynamicEntityProperties, L("DynamicEntityProperties"));
            dynamicEntityProperties.CreateChildPermission(AppPermissions.Pages_Administration_DynamicEntityProperties_Create, L("CreatingDynamicEntityProperties"));
            dynamicEntityProperties.CreateChildPermission(AppPermissions.Pages_Administration_DynamicEntityProperties_Edit, L("EditingDynamicEntityProperties"));
            dynamicEntityProperties.CreateChildPermission(AppPermissions.Pages_Administration_DynamicEntityProperties_Delete, L("DeletingDynamicEntityProperties"));

            var dynamicEntityPropertyValues = dynamicProperties.CreateChildPermission(AppPermissions.Pages_Administration_DynamicEntityPropertyValue, L("EntityDynamicPropertyValue"));
            dynamicEntityPropertyValues.CreateChildPermission(AppPermissions.Pages_Administration_DynamicEntityPropertyValue_Create, L("CreatingDynamicEntityPropertyValue"));
            dynamicEntityPropertyValues.CreateChildPermission(AppPermissions.Pages_Administration_DynamicEntityPropertyValue_Edit, L("EditingDynamicEntityPropertyValue"));
            dynamicEntityPropertyValues.CreateChildPermission(AppPermissions.Pages_Administration_DynamicEntityPropertyValue_Delete, L("DeletingDynamicEntityPropertyValue"));

            var massNotification = administration.CreateChildPermission(AppPermissions.Pages_Administration_MassNotification, L("MassNotifications"));
            massNotification.CreateChildPermission(AppPermissions.Pages_Administration_MassNotification_Create, L("MassNotificationCreate"));

            //TENANT-SPECIFIC PERMISSIONS

            pages.CreateChildPermission(AppPermissions.Pages_Tenant_Dashboard, L("Dashboard"), multiTenancySides: MultiTenancySides.Tenant);

            administration.CreateChildPermission(AppPermissions.Pages_Administration_Tenant_Settings, L("Settings"), multiTenancySides: MultiTenancySides.Tenant);
            //  administration.CreateChildPermission(AppPermissions.Pages_Administration_Tenant_SubscriptionManagement, L("Subscription"), multiTenancySides: MultiTenancySides.Tenant);

            //HOST-SPECIFIC PERMISSIONS

            var editions = pages.CreateChildPermission(AppPermissions.Pages_Editions, L("Editions"), multiTenancySides: MultiTenancySides.Host);
            editions.CreateChildPermission(AppPermissions.Pages_Editions_Create, L("CreatingNewEdition"), multiTenancySides: MultiTenancySides.Host);
            editions.CreateChildPermission(AppPermissions.Pages_Editions_Edit, L("EditingEdition"), multiTenancySides: MultiTenancySides.Host);
            editions.CreateChildPermission(AppPermissions.Pages_Editions_Delete, L("DeletingEdition"), multiTenancySides: MultiTenancySides.Host);
            editions.CreateChildPermission(AppPermissions.Pages_Editions_MoveTenantsToAnotherEdition, L("MoveTenantsToAnotherEdition"), multiTenancySides: MultiTenancySides.Host);

            var tenants = pages.CreateChildPermission(AppPermissions.Pages_Tenants, L("Tenants"), multiTenancySides: MultiTenancySides.Host);
            tenants.CreateChildPermission(AppPermissions.Pages_Tenants_Create, L("CreatingNewTenant"), multiTenancySides: MultiTenancySides.Host);
            tenants.CreateChildPermission(AppPermissions.Pages_Tenants_Edit, L("EditingTenant"), multiTenancySides: MultiTenancySides.Host);
            tenants.CreateChildPermission(AppPermissions.Pages_Tenants_ChangeFeatures, L("ChangingFeatures"), multiTenancySides: MultiTenancySides.Host);
            tenants.CreateChildPermission(AppPermissions.Pages_Tenants_Delete, L("DeletingTenant"), multiTenancySides: MultiTenancySides.Host);
            tenants.CreateChildPermission(AppPermissions.Pages_Tenants_Impersonation, L("LoginForTenants"), multiTenancySides: MultiTenancySides.Host);

            administration.CreateChildPermission(AppPermissions.Pages_Administration_Host_Settings, L("Settings"), multiTenancySides: MultiTenancySides.Host);

            var maintenance = administration.CreateChildPermission(AppPermissions.Pages_Administration_Host_Maintenance, L("Maintenance"), multiTenancySides: _isMultiTenancyEnabled ? MultiTenancySides.Host : MultiTenancySides.Tenant);
            // maintenance.CreateChildPermission(AppPermissions.Pages_Administration_NewVersion_Create, L("SendNewVersionNotification"));

            administration.CreateChildPermission(AppPermissions.Pages_Administration_HangfireDashboard, L("HangfireDashboard"), multiTenancySides: _isMultiTenancyEnabled ? MultiTenancySides.Host : MultiTenancySides.Tenant);
            administration.CreateChildPermission(AppPermissions.Pages_Administration_Host_Dashboard, L("Dashboard"), multiTenancySides: MultiTenancySides.Host);
        }

        private static ILocalizableString L(string name)
        {
            return new LocalizableString(name, MiddlewareConsts.LocalizationSourceName);
        }
    }
}