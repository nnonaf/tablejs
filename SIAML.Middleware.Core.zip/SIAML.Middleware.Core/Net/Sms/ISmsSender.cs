using System.Threading.Tasks;

namespace SIAML.Middleware.Net.Sms
{
    public interface ISmsSender
    {
        Task SendAsync(string number, string message);
    }
}