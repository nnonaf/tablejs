﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Abp.Domain.Entities.Auditing;
using Abp.Domain.Entities;
using Abp.Auditing;

namespace SIAML.Middleware.Country
{
    [Table("Tbl_Countries")]
    [Audited]
    public class ManageCountry : FullAuditedEntity
    {

        [Required]
        [StringLength(ManageCountryConsts.MaxCountryNameLength, MinimumLength = ManageCountryConsts.MinCountryNameLength)]
        public virtual string CountryName { get; set; }

        [Required]
        [RegularExpression(ManageCountryConsts.CountryCodeRegex)]
        [StringLength(ManageCountryConsts.MaxCountryCodeLength, MinimumLength = ManageCountryConsts.MinCountryCodeLength)]
        public virtual string CountryCode { get; set; }

        [Required]
        [RegularExpression(ManageCountryConsts.ISOAlpha2CodeRegex)]
        [StringLength(ManageCountryConsts.MaxISOAlpha2CodeLength, MinimumLength = ManageCountryConsts.MinISOAlpha2CodeLength)]
        public virtual string ISOAlpha2Code { get; set; }

        //public virtual string ISOAlpha3Code { get; set; }

    }
}