﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Abp.Domain.Entities.Auditing;
using Abp.Domain.Entities;
using Abp.Auditing;

namespace SIAML.Middleware.PaymentMode
{
    [Table("Tbl_PaymentModes")]
    [Audited]
    public class ManagePaymentMode : FullAuditedEntity
    {

        [Required]
        [StringLength(ManagePaymentModeConsts.MaxPaymentModeLength, MinimumLength = ManagePaymentModeConsts.MinPaymentModeLength)]
        public virtual string PaymentMode { get; set; }

    }
}