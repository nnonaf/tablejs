﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Abp.Domain.Entities.Auditing;
using Abp.Domain.Entities;
using Abp.Auditing;

namespace SIAML.Middleware.Gender
{
    [Table("Tbl_Genders")]
    [Audited]
    public class ManageGender : FullAuditedEntity
    {

        [Required]
        [StringLength(ManageGenderConsts.MaxGenderLength, MinimumLength = ManageGenderConsts.MinGenderLength)]
        public virtual string Gender { get; set; }

    }
}