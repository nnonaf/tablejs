﻿using SIAML.Middleware.RiskCategoryEnums;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Abp.Domain.Entities.Auditing;
using Abp.Domain.Entities;
using Abp.Auditing;

namespace SIAML.Middleware.LegalEntity
{
    [Table("Tbl_LegalEntities")]
    [Audited]
    public class ManageLegalEntity : FullAuditedEntity
    {

        [Required]
        [StringLength(ManageLegalEntityConsts.MaxLegalEntityTypeLength, MinimumLength = ManageLegalEntityConsts.MinLegalEntityTypeLength)]
        public virtual string LegalEntityType { get; set; }

        public virtual RiskCategoryEnum RiskCategory { get; set; }

    }
}