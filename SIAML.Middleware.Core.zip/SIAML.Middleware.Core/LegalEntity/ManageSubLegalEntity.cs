﻿using SIAML.Middleware.LegalEntity;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Abp.Domain.Entities.Auditing;
using Abp.Domain.Entities;
using Abp.Auditing;

namespace SIAML.Middleware.LegalEntity
{
    [Table("Tbl_SubLegalEntities")]
    [Audited]
    public class ManageSubLegalEntity : FullAuditedEntity
    {

        [Required]
        [StringLength(ManageSubLegalEntityConsts.MaxSubLegalEntityTypeLength, MinimumLength = ManageSubLegalEntityConsts.MinSubLegalEntityTypeLength)]
        public virtual string SubLegalEntityType { get; set; }

        public virtual int? LegalEntityId { get; set; }

        [ForeignKey("LegalEntityId")]
        public ManageLegalEntity LegalEntityFk { get; set; }

    }
}