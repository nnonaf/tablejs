﻿using SIAML.Middleware.NonDiscretionalFundSchemeTypeEnums;
using SIAML.Middleware.NonDiscretionalPortfolioClassEnums;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Abp.Domain.Entities.Auditing;
using Abp.Domain.Entities;

namespace SIAML.Middleware.OnboardingNonDiscretional
{
    [Table("Tbl_NonDiscretionalPortfolios")]
    public class NonDiscretionalPortfolio : FullAuditedEntity
    {

        [Required]
        [StringLength(NonDiscretionalPortfolioConsts.MaxPortfolioNameLength, MinimumLength = NonDiscretionalPortfolioConsts.MinPortfolioNameLength)]
        public virtual string PortfolioName { get; set; }

        public virtual NonDiscretionalFundSchemeTypeEnum FundSchemeType { get; set; }

        public virtual NonDiscretionalPortfolioClassEnum PortfolioClass { get; set; }

        [Required]
        public virtual string OnboardingSubscriptionWorkflowId { get; set; }

        public virtual string Eaccount { get; set; }

      
        [StringLength(NonDiscretionalPortfolioConsts.MaxFundCodeLength, MinimumLength = NonDiscretionalPortfolioConsts.MinFundCodeLength)]
        public virtual string FundCode { get; set; }

    }
}