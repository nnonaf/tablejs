﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Abp.Domain.Entities.Auditing;
using Abp.Domain.Entities;
using Abp.Auditing;

namespace SIAML.Middleware.DividendPayment
{
    [Table("Tbl_DividendPaymentTypes")]
    [Audited]
    public class ManageDividendPaymentType : FullAuditedEntity
    {

        [Required]
        [StringLength(ManageDividendPaymentTypeConsts.MaxDividendPaymentTypeLength, MinimumLength = ManageDividendPaymentTypeConsts.MinDividendPaymentTypeLength)]
        public virtual string DividendPaymentType { get; set; }

    }
}