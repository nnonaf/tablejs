using System.Threading.Tasks;
using SIAML.Middleware.Authorization.Users;

namespace SIAML.Middleware.WebHooks
{
    public interface IAppWebhookPublisher
    {
        Task PublishTestWebhook();
    }
}
