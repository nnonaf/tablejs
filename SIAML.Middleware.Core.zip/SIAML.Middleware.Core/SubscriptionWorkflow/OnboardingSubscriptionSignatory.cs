﻿using SIAML.Middleware.Country;
using SIAML.Middleware.IdType;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Abp.Domain.Entities.Auditing;
using Abp.Domain.Entities;
using Abp.Auditing;

namespace SIAML.Middleware.SubscriptionWorkflow
{
    [Table("Tbl_OnboardingSubscriptionSignatories")]
    [Audited]
    public class OnboardingSubscriptionSignatory : FullAuditedEntity<Guid>
    {

        [Required]
        [StringLength(OnboardingSubscriptionSignatoryConsts.MaxSurnameLength, MinimumLength = OnboardingSubscriptionSignatoryConsts.MinSurnameLength)]
        public virtual string Surname { get; set; }

        [Required]
        [StringLength(OnboardingSubscriptionSignatoryConsts.MaxFirstNameLength, MinimumLength = OnboardingSubscriptionSignatoryConsts.MinFirstNameLength)]
        public virtual string FirstName { get; set; }

        [StringLength(OnboardingSubscriptionSignatoryConsts.MaxOtherNameLength, MinimumLength = OnboardingSubscriptionSignatoryConsts.MinOtherNameLength)]
        public virtual string OtherName { get; set; }

        public virtual DateTime DateOfBirth { get; set; }

        [StringLength(OnboardingSubscriptionSignatoryConsts.MaxAddressLength, MinimumLength = OnboardingSubscriptionSignatoryConsts.MinAddressLength)]
        public virtual string Address { get; set; }

        [StringLength(OnboardingSubscriptionSignatoryConsts.MaxEmailLength, MinimumLength = OnboardingSubscriptionSignatoryConsts.MinEmailLength)]
        public virtual string Email { get; set; }

        [Required]
        [StringLength(OnboardingSubscriptionSignatoryConsts.MaxPhoneNumberLength, MinimumLength = OnboardingSubscriptionSignatoryConsts.MinPhoneNumberLength)]
        public virtual string PhoneNumber { get; set; }

        public virtual string Mobile_Phone_Category { get; set; }

        public virtual DateTime IdIssueDate { get; set; }

        public virtual DateTime IdExpiryDate { get; set; }

        [Required]
        public virtual string OnboardingSubscriptionWorkflowId { get; set; }

        [Required]
        [StringLength(OnboardingSubscriptionSignatoryConsts.MaxIdNumberLength, MinimumLength = OnboardingSubscriptionSignatoryConsts.MinIdNumberLength)]
        public virtual string IdNumber { get; set; }
       

        public virtual string Bvn { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxBvnLastNameLength, MinimumLength = OnboardingSubscriptionConsts.MinBvnLastNameLength)]
        public virtual string BvnLastName { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxBvnFirstNameLength, MinimumLength = OnboardingSubscriptionConsts.MinBvnFirstNameLength)]
        public virtual string BvnFirstName { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxBvnOtherNamesLength, MinimumLength = OnboardingSubscriptionConsts.MinBvnOtherNamesLength)]
        public virtual string BvnOtherNames { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxBvnMobilePhoneLength, MinimumLength = OnboardingSubscriptionConsts.MinBvnMobilePhoneLength)]
        public virtual string BvnMobilePhone { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxBvnDobLength, MinimumLength = OnboardingSubscriptionConsts.MinBvnDobLength)]
        public virtual string BvnDob { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxBvnStatusLength, MinimumLength = OnboardingSubscriptionConsts.MinBvnStatusLength)]
        public virtual string BvnStatus { get; set; }

        public virtual string BankAccountNameMismatchComment { get; set; }
        public virtual string BvnNameMismatchComment { get; set; }

        public virtual Guid? PassportPhotographUpload { get; set; } //File, (BinaryObjectId)
                                                                    //File

        public virtual Guid? ProofOfAddressUpload { get; set; } //File, (BinaryObjectId)
                                                                //File

        public virtual Guid? ProofOfIdentityUpload { get; set; } //File, (BinaryObjectId)

        public virtual Guid? SafeWatchUpload { get; set; } //File, (BinaryObjectId)

        public virtual Guid? GoogleSearchUpload { get; set; } //File, (BinaryObjectId)

        public virtual int? NationalityId { get; set; }

        [ForeignKey("NationalityId")]
        public ManageCountry NationalityFk { get; set; }

        public virtual int? IdTypeId { get; set; }

        [ForeignKey("IdTypeId")]
        public ManageIdType IdTypeFk { get; set; }

    }
}