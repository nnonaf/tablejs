﻿using SIAML.Middleware.KYCStatusEnums;
using SIAML.Middleware.YesNoEnums;
using SIAML.Middleware.RiskCategoryEnums;
using SIAML.Middleware.CallOverStatusEnums;
using SIAML.Middleware.Subscription;
using SIAML.Middleware.Title;
using SIAML.Middleware.MaritalStatus;
using SIAML.Middleware.Country;
using SIAML.Middleware.State;
using SIAML.Middleware.Gender;
using SIAML.Middleware.Relationship;
using SIAML.Middleware.MarketingChannel;
using SIAML.Middleware.Religion;
using SIAML.Middleware.Bank;
using SIAML.Middleware.IdType;
using SIAML.Middleware.PaymentMode;
using SIAML.Middleware.EmploymentStatus;
using SIAML.Middleware.JobType;
using SIAML.Middleware.StockBroker;
using SIAML.Middleware.FundDetails;
using SIAML.Middleware.Sector;
using SIAML.Middleware.OnboardingPlatform;
using SIAML.Middleware.Authorization.Users;
using SIAML.Middleware.Town;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Abp.Domain.Entities.Auditing;
using Abp.Domain.Entities;
using Abp.Auditing;
using SIAML.Middleware.ApprovalStatusEnums;
using SIAML.Middleware.EmployerSegmentEnums;
using SIAML.Middleware.PublicSectorEnums;
using SIAML.Middleware.DividendPayment;
using SIAML.Middleware.LegalEntity;

namespace SIAML.Middleware.SubscriptionWorkflow
{
    [Table("Client")]
    [Audited]
    public class OnboardingSubscription : FullAuditedEntity, IMayHaveTenant
    {
        public int? TenantId { get; set; }


        public virtual bool MarketingConsent { get; set; }

        public virtual bool DataPrivacy { get; set; }

        public virtual bool ResearchConsent { get; set; }

        public virtual bool MarketOtherConsent { get; set; }

        public virtual bool MarketGroupConsent { get; set; }

        public virtual DateTime? IdIssueDate { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxLastNameLength, MinimumLength = OnboardingSubscriptionConsts.MinLastNameLength)]
        public virtual string LastName { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxFirstNameLength, MinimumLength = OnboardingSubscriptionConsts.MinFirstNameLength)]
        public virtual string FirstName { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxOtherNamesLength, MinimumLength = OnboardingSubscriptionConsts.MinOtherNamesLength)]
        public virtual string OtherNames { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxFullNameLength, MinimumLength = OnboardingSubscriptionConsts.MinFullNameLength)]
        public virtual string FullName { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxMaiden_NameLength, MinimumLength = OnboardingSubscriptionConsts.MinMaiden_NameLength)]
        public virtual string Maiden_Name { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxMothers_Maiden_NameLength, MinimumLength = OnboardingSubscriptionConsts.MinMothers_Maiden_NameLength)]
        public virtual string Mothers_Maiden_Name { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxEmployer_IdLength, MinimumLength = OnboardingSubscriptionConsts.MinEmployer_IdLength)]
        public virtual string Employer_Id { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxDesignationLength, MinimumLength = OnboardingSubscriptionConsts.MinDesignationLength)]
        public virtual string Designation { get; set; }

        public virtual DateTime? Date_Of_Birth { get; set; }

        [EmailAddress]
        [StringLength(OnboardingSubscriptionConsts.MaxEmailLength, MinimumLength = OnboardingSubscriptionConsts.MinEmailLength)]
        public virtual string Email { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxMobile_PhoneLength, MinimumLength = OnboardingSubscriptionConsts.MinMobile_PhoneLength)]
        public virtual string Mobile_Phone { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxOfficial_PhoneLength, MinimumLength = OnboardingSubscriptionConsts.MinOfficial_PhoneLength)]
        public virtual string Official_Phone { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxNok_LastNameLength, MinimumLength = OnboardingSubscriptionConsts.MinNok_LastNameLength)]
        public virtual string Nok_LastName { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxNok_FirstNameLength, MinimumLength = OnboardingSubscriptionConsts.MinNok_FirstNameLength)]
        public virtual string Nok_FirstName { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxNok_OtherNamesLength, MinimumLength = OnboardingSubscriptionConsts.MinNok_OtherNamesLength)]
        public virtual string Nok_OtherNames { get; set; }

        [EmailAddress]
        [StringLength(OnboardingSubscriptionConsts.MaxNok_EmailLength, MinimumLength = OnboardingSubscriptionConsts.MinNok_EmailLength)]
        public virtual string Nok_Email { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxNok_Mobile_PhoneLength, MinimumLength = OnboardingSubscriptionConsts.MinNok_Mobile_PhoneLength)]
        public virtual string Nok_Mobile_Phone { get; set; }
        public virtual string Nok_Mobile_Phone_Category { get; set; }

        public virtual DateTime? Nok_Date_Of_Birth { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxNokAddressLength, MinimumLength = OnboardingSubscriptionConsts.MinNokAddressLength)]
        public virtual string NokAddress { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxNokAddress2Length, MinimumLength = OnboardingSubscriptionConsts.MinNokAddress2Length)]
        public virtual string NokAddress2 { get; set; }

        public virtual bool NotifySms { get; set; }

        public virtual bool NotifyEmail { get; set; }

        public virtual bool NotifyPostal { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxBankAccountNameLength, MinimumLength = OnboardingSubscriptionConsts.MinBankAccountNameLength)]
        public virtual string BankAccountName { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxBankAccountNumberLength, MinimumLength = OnboardingSubscriptionConsts.MinBankAccountNumberLength)]
        public virtual string BankAccountNumber { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxBankAccountStatusLength, MinimumLength = OnboardingSubscriptionConsts.MinBankAccountStatusLength)]
        public virtual string BankAccountStatus { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxBvnLength, MinimumLength = OnboardingSubscriptionConsts.MinBvnLength)]
        public virtual string Bvn { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxBvnLastNameLength, MinimumLength = OnboardingSubscriptionConsts.MinBvnLastNameLength)]
        public virtual string BvnLastName { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxBvnFirstNameLength, MinimumLength = OnboardingSubscriptionConsts.MinBvnFirstNameLength)]
        public virtual string BvnFirstName { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxBvnOtherNamesLength, MinimumLength = OnboardingSubscriptionConsts.MinBvnOtherNamesLength)]
        public virtual string BvnOtherNames { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxBvnMobilePhoneLength, MinimumLength = OnboardingSubscriptionConsts.MinBvnMobilePhoneLength)]
        public virtual string BvnMobilePhone { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxBvnDobLength, MinimumLength = OnboardingSubscriptionConsts.MinBvnDobLength)]
        public virtual string BvnDob { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxBvnStatusLength, MinimumLength = OnboardingSubscriptionConsts.MinBvnStatusLength)]
        public virtual string BvnStatus { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxCSCSAccountNumberLength, MinimumLength = OnboardingSubscriptionConsts.MinCSCSAccountNumberLength)]
        public virtual string CSCSAccountNumber { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxCHNLength, MinimumLength = OnboardingSubscriptionConsts.MinCHNLength)]
        public virtual string CHN { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxPFALength, MinimumLength = OnboardingSubscriptionConsts.MinPFALength)]
        public virtual string PFA { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxRsaPinLength, MinimumLength = OnboardingSubscriptionConsts.MinRsaPinLength)]
        public virtual string RsaPin { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxStatusLength, MinimumLength = OnboardingSubscriptionConsts.MinStatusLength)]
        public virtual string Status { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxKYCStatusPassportLength, MinimumLength = OnboardingSubscriptionConsts.MinKYCStatusPassportLength)]
        public virtual string KYCStatusPassport { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxKYCStatusDatesLength, MinimumLength = OnboardingSubscriptionConsts.MinKYCStatusDatesLength)]
        public virtual string KYCStatusDates { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxKYCStatusIdMeansLength, MinimumLength = OnboardingSubscriptionConsts.MinKYCStatusIdMeansLength)]
        public virtual string KYCStatusIdMeans { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxKYCStatusAddressProofLength, MinimumLength = OnboardingSubscriptionConsts.MinKYCStatusAddressProofLength)]
        public virtual string KYCStatusAddressProof { get; set; }

        public virtual KYCStatus KYCStatus { get; set; }

        public virtual EmployerSegmentEnum EmployerSegment { get; set; }
        public virtual PublicSectorGradeEnum EmployeeGrade { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxRecordSourceIdLength, MinimumLength = OnboardingSubscriptionConsts.MinRecordSourceIdLength)]
        public virtual string RecordSourceId { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxRecordLocationIdLength, MinimumLength = OnboardingSubscriptionConsts.MinRecordLocationIdLength)]
        public virtual string RecordLocationId { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxAgentIdLength, MinimumLength = OnboardingSubscriptionConsts.MinAgentIdLength)]
        public virtual string AgentId { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxPromoIdLength, MinimumLength = OnboardingSubscriptionConsts.MinPromoIdLength)]
        public virtual string PromoId { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxResidentialAddressLength, MinimumLength = OnboardingSubscriptionConsts.MinResidentialAddressLength)]
        public virtual string ResidentialAddress { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxResidentialAddress2Length, MinimumLength = OnboardingSubscriptionConsts.MinResidentialAddress2Length)]
        public virtual string ResidentialAddress2 { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxMailingAddressLength, MinimumLength = OnboardingSubscriptionConsts.MinMailingAddressLength)]
        public virtual string MailingAddress { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxMailingAddress2Length, MinimumLength = OnboardingSubscriptionConsts.MinMailingAddress2Length)]
        public virtual string MailingAddress2 { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxMailingCityLength, MinimumLength = OnboardingSubscriptionConsts.MinMailingCityLength)]
        public virtual string MailingCity { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxMailingStateLength, MinimumLength = OnboardingSubscriptionConsts.MinMailingStateLength)]
        public virtual string MailingState { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxPassportLength, MinimumLength = OnboardingSubscriptionConsts.MinPassportLength)]
        public virtual string Passport { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxSignatureLength, MinimumLength = OnboardingSubscriptionConsts.MinSignatureLength)]
        public virtual string Signature { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxIdNumberLength, MinimumLength = OnboardingSubscriptionConsts.MinIdNumberLength)]
        public virtual string IdNumber { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxOccupationLength, MinimumLength = OnboardingSubscriptionConsts.MinOccupationLength)]
        public virtual string Occupation { get; set; }

        public virtual DateTime? IdExpiryDate { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxProofOfAddressLength, MinimumLength = OnboardingSubscriptionConsts.MinProofOfAddressLength)]
        public virtual string ProofOfAddress { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxProofOfAddressTypeLength, MinimumLength = OnboardingSubscriptionConsts.MinProofOfAddressTypeLength)]
        public virtual string ProofOfAddressType { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxWebStatusLength, MinimumLength = OnboardingSubscriptionConsts.MinWebStatusLength)]
        public virtual string WebStatus { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxWebPassCodeLength, MinimumLength = OnboardingSubscriptionConsts.MinWebPassCodeLength)]
        public virtual string WebPassCode { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxSubProfileLength, MinimumLength = OnboardingSubscriptionConsts.MinSubProfileLength)]
        public virtual string SubProfile { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxLinkIdLength, MinimumLength = OnboardingSubscriptionConsts.MinLinkIdLength)]
        public virtual string LinkId { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxAdditionalInformationLength, MinimumLength = OnboardingSubscriptionConsts.MinAdditionalInformationLength)]
        public virtual string AdditionalInformation { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxSchoolIdLength, MinimumLength = OnboardingSubscriptionConsts.MinSchoolIdLength)]
        public virtual string SchoolId { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxSchoolClassLength, MinimumLength = OnboardingSubscriptionConsts.MinSchoolClassLength)]
        public virtual string SchoolClass { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxSchoolSessionLength, MinimumLength = OnboardingSubscriptionConsts.MinSchoolSessionLength)]
        public virtual string SchoolSession { get; set; }

        public virtual DateTime? SchoolSessionStart { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxStagingIdLength, MinimumLength = OnboardingSubscriptionConsts.MinStagingIdLength)]
        public virtual string StagingId { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxInvestorIdLength, MinimumLength = OnboardingSubscriptionConsts.MinInvestorIdLength)]
        public virtual string InvestorId { get; set; }

        public virtual DateTime? RegistrationDate { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxCreated_ByLength, MinimumLength = OnboardingSubscriptionConsts.MinCreated_ByLength)]
        public virtual string Created_By { get; set; }

        public virtual DateTime? DateCreated { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxConfirmedByLength, MinimumLength = OnboardingSubscriptionConsts.MinConfirmedByLength)]
        public virtual string ConfirmedBy { get; set; }

        public virtual DateTime? DateConfirmed { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxApprovedByLength, MinimumLength = OnboardingSubscriptionConsts.MinApprovedByLength)]
        public virtual string ApprovedBy { get; set; }

        public virtual DateTime? DateApproved { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxLastUpdatedByLength, MinimumLength = OnboardingSubscriptionConsts.MinLastUpdatedByLength)]
        public virtual string LastUpdatedBy { get; set; }

        public virtual DateTime? DateLastUpdated { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxWorkFlowTypeLength, MinimumLength = OnboardingSubscriptionConsts.MinWorkFlowTypeLength)]
        public virtual string WorkFlowType { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxTransRefLength, MinimumLength = OnboardingSubscriptionConsts.MinTransRefLength)]
        public virtual string TransRef { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxOrderIdLength, MinimumLength = OnboardingSubscriptionConsts.MinOrderIdLength)]
        public virtual string OrderId { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxRecordIdLength, MinimumLength = OnboardingSubscriptionConsts.MinRecordIdLength)]
        public virtual string RecordId { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxClientIdLength, MinimumLength = OnboardingSubscriptionConsts.MinClientIdLength)]
        public virtual string ClientId { get; set; }

        public virtual decimal? Amount { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxTagLength, MinimumLength = OnboardingSubscriptionConsts.MinTagLength)]
        public virtual string Tag { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxSourceLength, MinimumLength = OnboardingSubscriptionConsts.MinSourceLength)]
        public virtual string Source { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxBeneficiaryNameLength, MinimumLength = OnboardingSubscriptionConsts.MinBeneficiaryNameLength)]
        public virtual string BeneficiaryName { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxBeneficiaryAccountLength, MinimumLength = OnboardingSubscriptionConsts.MinBeneficiaryAccountLength)]
        public virtual string BeneficiaryAccount { get; set; }

        public virtual DateTime? ValueDate { get; set; }

        public virtual ApprovalStatusEnum ApprovalStatus { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxApproverLength, MinimumLength = OnboardingSubscriptionConsts.MinApproverLength)]
        public virtual string Approver { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxAgentCodeLength, MinimumLength = OnboardingSubscriptionConsts.MinAgentCodeLength)]
        public virtual string AgentCode { get; set; }

        public virtual decimal? OfferPrice { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxSubscriberTypeLength, MinimumLength = OnboardingSubscriptionConsts.MinSubscriberTypeLength)]
        public virtual string SubscriberType { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxSubscriberTypeLength, MinimumLength = OnboardingSubscriptionConsts.MinSubscriberTypeLength)]
        public virtual string Sub_SubscriberType { get; set; }

        public virtual YesNoEnum OnlineRedemption { get; set; }

        public virtual decimal? Units { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxTransIdLength, MinimumLength = OnboardingSubscriptionConsts.MinTransIdLength)]
        public virtual string TransId { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxReceivedByLength, MinimumLength = OnboardingSubscriptionConsts.MinReceivedByLength)]
        public virtual string ReceivedBy { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxMarketingSourceLength, MinimumLength = OnboardingSubscriptionConsts.MinMarketingSourceLength)]
        public virtual string MarketingSource { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxDividendPaymentLength, MinimumLength = OnboardingSubscriptionConsts.MinDividendPaymentLength)]
        public virtual string DividendPayment { get; set; }

        public virtual YesNoEnum EmailIdemnity { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxAdditionalFlagLength, MinimumLength = OnboardingSubscriptionConsts.MinAdditionalFlagLength)]
        public virtual string AdditionalFlag { get; set; }

        public virtual YesNoEnum PEP { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxCorporateNameOfInstitutionLength, MinimumLength = OnboardingSubscriptionConsts.MinCorporateNameOfInstitutionLength)]
        public virtual string CorporateNameOfInstitution { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxCorporateRCRegistrationNumberLength, MinimumLength = OnboardingSubscriptionConsts.MinCorporateRCRegistrationNumberLength)]
        public virtual string CorporateRCRegistrationNumber { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxCorporatePlaceOfIncorporationLength, MinimumLength = OnboardingSubscriptionConsts.MinCorporatePlaceOfIncorporationLength)]
        public virtual string CorporatePlaceOfIncorporation { get; set; }

        public virtual DateTime? CorporateDateOfIncorporation { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxCorporateBusinessTypeLength, MinimumLength = OnboardingSubscriptionConsts.MinCorporateBusinessTypeLength)]
        public virtual string CorporateBusinessType { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxPhoneNumberLength, MinimumLength = OnboardingSubscriptionConsts.MinPhoneNumberLength)]
        public virtual string PhoneNumber { get; set; }

        //[StringLength(OnboardingSubscriptionConsts.MaxCorporateLegalEntityTypeLength, MinimumLength = OnboardingSubscriptionConsts.MinCorporateLegalEntityTypeLength)]
        //public virtual string CorporateLegalEntityType { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxCorporateWebsiteLength, MinimumLength = OnboardingSubscriptionConsts.MinCorporateWebsiteLength)]
        public virtual string CorporateWebsite { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxCorporateFaxNumberLength, MinimumLength = OnboardingSubscriptionConsts.MinCorporateFaxNumberLength)]
        public virtual string CorporateFaxNumber { get; set; }

        [EmailAddress]
        [StringLength(OnboardingSubscriptionConsts.MaxCorporateEmailAddressLength, MinimumLength = OnboardingSubscriptionConsts.MinCorporateEmailAddressLength)]
        public virtual string CorporateEmailAddress { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxCorporateCityLength, MinimumLength = OnboardingSubscriptionConsts.MinCorporateCityLength)]
        public virtual string CorporateCity { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxCorporateBusinessAddressLength, MinimumLength = OnboardingSubscriptionConsts.MinCorporateBusinessAddressLength)]
        public virtual string CorporateBusinessAddress { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxCorporateStreetNameLength, MinimumLength = OnboardingSubscriptionConsts.MinCorporateStreetNameLength)]
        public virtual string CorporateStreetName { get; set; }

        public virtual decimal? CorporateAnnualTurnover { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxCorporateLocalityLength, MinimumLength = OnboardingSubscriptionConsts.MinCorporateLocalityLength)]
        public virtual string CorporateLocality { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxCorporateNameOfContactPersonLength, MinimumLength = OnboardingSubscriptionConsts.MinCorporateNameOfContactPersonLength)]
        public virtual string CorporateNameOfContactPerson { get; set; }

        [EmailAddress]
        [StringLength(OnboardingSubscriptionConsts.MaxCorporateContactEmailAddressLength, MinimumLength = OnboardingSubscriptionConsts.MinCorporateContactEmailAddressLength)]
        public virtual string CorporateContactEmailAddress { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxCorporateDesignationLength, MinimumLength = OnboardingSubscriptionConsts.MinCorporateDesignationLength)]
        public virtual string CorporateDesignation { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxNarrationLength, MinimumLength = OnboardingSubscriptionConsts.MinNarrationLength)]
        public virtual string Narration { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxReturnCodeLength, MinimumLength = OnboardingSubscriptionConsts.MinReturnCodeLength)]
        public virtual string ReturnCode { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxUpdatedByLength, MinimumLength = OnboardingSubscriptionConsts.MinUpdatedByLength)]
        public virtual string UpdatedBy { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxCommentLength, MinimumLength = OnboardingSubscriptionConsts.MinCommentLength)]
        public virtual string Comment { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxChildSurnameLength, MinimumLength = OnboardingSubscriptionConsts.MinChildSurnameLength)]
        public virtual string ChildSurname { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxChildFirstNameLength, MinimumLength = OnboardingSubscriptionConsts.MinChildFirstNameLength)]
        public virtual string ChildFirstName { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxChildMiddleNameLength, MinimumLength = OnboardingSubscriptionConsts.MinChildMiddleNameLength)]
        public virtual string ChildMiddleName { get; set; }

        public virtual DateTime? ChildDateOfBirth { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxIncomeRangePerAnnumLength, MinimumLength = OnboardingSubscriptionConsts.MinIncomeRangePerAnnumLength)]
        public virtual string IncomeRangePerAnnum { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxTinLength, MinimumLength = OnboardingSubscriptionConsts.MinTinLength)]
        public virtual string Tin { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxPlaceOfIssueLength, MinimumLength = OnboardingSubscriptionConsts.MinPlaceOfIssueLength)]
        public virtual string PlaceOfIssue { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxLevelOfEducationLength, MinimumLength = OnboardingSubscriptionConsts.MinLevelOfEducationLength)]
        public virtual string LevelOfEducation { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxEmployerAddressLength, MinimumLength = OnboardingSubscriptionConsts.MinEmployerAddressLength)]
        public virtual string EmployerAddress { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxEmployerTelephoneLength, MinimumLength = OnboardingSubscriptionConsts.MinEmployerTelephoneLength)]
        public virtual string EmployerTelephone { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxEmployerFaxLength, MinimumLength = OnboardingSubscriptionConsts.MinEmployerFaxLength)]
        public virtual string EmployerFax { get; set; }

        //[StringLength(OnboardingSubscriptionConsts.MaxEmployerSegmentLength, MinimumLength = OnboardingSubscriptionConsts.MinEmployerSegmentLength)]
        //public virtual string EmployerSegment { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxEmployerWebsiteLength, MinimumLength = OnboardingSubscriptionConsts.MinEmployerWebsiteLength)]
        public virtual string EmployerWebsite { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxEmployerNameLength, MinimumLength = OnboardingSubscriptionConsts.MinEmployerNameLength)]
        public virtual string EmployerName { get; set; }

        public virtual RiskCategoryEnum RiskCategory { get; set; }

        public virtual RiskSubCategoryEnum RiskSubCategory { get; set; }

        public virtual CallOverStatusEnum CallOverStatus { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxNokCityLength, MinimumLength = OnboardingSubscriptionConsts.MinNokCityLength)]
        public virtual string NokCity { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxCountry_CodeLength, MinimumLength = OnboardingSubscriptionConsts.MinCountry_CodeLength)]
        public virtual string Country_Code { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxCountry_Code_OfficialLength, MinimumLength = OnboardingSubscriptionConsts.MinCountry_Code_OfficialLength)]
        public virtual string Country_Code_Official { get; set; }

        [StringLength(OnboardingSubscriptionConsts.MaxNok_Country_CodeLength, MinimumLength = OnboardingSubscriptionConsts.MinNok_Country_CodeLength)]
        public virtual string Nok_Country_Code { get; set; }

        public virtual string Mobile_Phone_Category { get; set; }

        public virtual bool SubscribeToFund { get; set; }

        public virtual Guid? AllDocumentsUpload { get; set; } //File, (BinaryObjectId)
                                                              //File

        public virtual Guid? PurchaseOrderUpload { get; set; } //File, (BinaryObjectId)
                                                               //File

        public virtual Guid? PassportPhotographUpload { get; set; } //File, (BinaryObjectId)
                                                                    //File

        public virtual Guid? ProofOfAddressUpload { get; set; } //File, (BinaryObjectId)
                                                                //File

        public virtual Guid? ProofOfIdentityUpload { get; set; } //File, (BinaryObjectId)
                                                                 //File

        public virtual Guid? AdditionalUpload { get; set; } //File, (BinaryObjectId)

        public virtual Guid? PepApprovalFormUpload { get; set; } //File, (BinaryObjectId)

        public virtual Guid? SignatureUpload { get; set; } //File, (BinaryObjectId)


        public virtual Guid? CertificateOfIncorporationUpload { get; set; } //File, (BinaryObjectId)
                                                                            //File

        public virtual Guid? FormCAC2Upload { get; set; } //File, (BinaryObjectId)
                                                          //File

        public virtual Guid? FormCAC7Upload { get; set; } //File, (BinaryObjectId)
                                                          //File

        public virtual Guid? LegalSearchReportUpload { get; set; } //File, (BinaryObjectId)
                                                                   //File

        public virtual Guid? ArticleOfAssociationUpload { get; set; } //File, (BinaryObjectId)


		public virtual Guid? SafeWatchUpload { get; set; } //File, (BinaryObjectId)

		public virtual Guid? GoogleSearchUpload { get; set; } //File, (BinaryObjectId)

		public virtual int SubscriptionTypeId { get; set; }

        public virtual string OnboardingSubscriptionWorkflowId { get; set; }

        public virtual string DestinationUrl { get; set; }

        //public virtual string ScriptUrl { get; set; }

        //public virtual string ModalClass { get; set; }


        [ForeignKey("ManageSubscriptionTypeId")]
        public ManageSubscriptionType ManageSubscriptionTypeFk { get; set; }

        public virtual int? Title { get; set; }

        [ForeignKey("Title")]
        public ManageTitle TitleFk { get; set; }

        public virtual int? Marital_Status { get; set; }

        [ForeignKey("Marital_Status")]
        public ManageMaritalStatus Marital_StatusFk { get; set; }

        public virtual int? Nationality { get; set; }

        [ForeignKey("Nationality")]
        public ManageCountry NationalityFk { get; set; }

        public virtual int? CountryOfBirth { get; set; }

        [ForeignKey("CountryOfBirth")]
        public ManageCountry CountryOfBirthFk { get; set; }


        public virtual int? State_Of_Origin { get; set; }

      //  [ForeignKey("State_Of_Origin")]
        public ManageState State_Of_OriginFk { get; set; }

        public virtual int? Nok_Title { get; set; }

        [ForeignKey("Nok_Title")]
        public ManageTitle Nok_TitleFk { get; set; }

        public virtual int? Nok_Gender { get; set; }

        [ForeignKey("Nok_Gender")]
        public ManageGender Nok_GenderFk { get; set; }

        public virtual int? NokCountry { get; set; }

        [ForeignKey("NokCountry")]
        public ManageCountry NokCountryFk { get; set; }

        public virtual int? NokState { get; set; }

      //  [ForeignKey("NokState")]
        public ManageState NokStateFk { get; set; }

        public virtual int? NokRelationship { get; set; }

        [ForeignKey("NokRelationship")]
        public ManageRelationship NokRelationshipFk { get; set; }

        public virtual int? ResidentialState { get; set; }

       // [ForeignKey("ResidentialState")]
        public ManageState ResidentialStateFk { get; set; }

        public virtual int? MarketingChannelId { get; set; }

        [ForeignKey("MarketingChannelId")]
        public ManageMarketingChannel MarketingChannelFk { get; set; }

        public virtual int? Gender { get; set; }

        [ForeignKey("Gender")]
        public ManageGender GenderFk { get; set; }

        public virtual int? Religion { get; set; }

        [ForeignKey("Religion")]
        public ManageReligion ReligionFk { get; set; }

        public virtual int? Bank { get; set; }

        [ForeignKey("Bank")]
        public ManageBank BankFk { get; set; }

        public virtual int? ResidentialCountry { get; set; }

        [ForeignKey("ResidentialCountry")]
        public ManageCountry ResidentialCountryFk { get; set; }

        public virtual int? IdType { get; set; }

        [ForeignKey("IdType")]
        public ManageIdType IdTypeFk { get; set; }

        public virtual int? MailingCountry { get; set; }

        [ForeignKey("MailingCountry")]
        public ManageCountry MailingCountryFk { get; set; }

        public virtual int? PaymentMode { get; set; }

        [ForeignKey("PaymentMode")]
        public ManagePaymentMode PaymentModeFk { get; set; }

        public virtual int? EmploymentStatus { get; set; }

        [ForeignKey("EmploymentStatus")]
        public ManageEmploymentStatus EmploymentStatusFk { get; set; }

        public virtual int? NokMaritalStatus { get; set; }

        [ForeignKey("NokMaritalStatus")]
        public ManageMaritalStatus NokMaritalStatusFk { get; set; }

        public virtual int? JobType { get; set; }

        [ForeignKey("JobType")]
        public ManageJobType JobTypeFk { get; set; }

        public virtual int? StockBroker { get; set; }

        [ForeignKey("StockBroker")]
        public ManageStockBroker StockBrokerFk { get; set; }

        public virtual int? RelationshipId { get; set; }

        [ForeignKey("RelationshipId")]
        public ManageRelationship RelationshipFk { get; set; }

        public virtual int? FundId { get; set; }

        [ForeignKey("FundId")]
        public ManageFundDetail FundFk { get; set; }

        public virtual int? CorporateBusinessSector { get; set; }

        [ForeignKey("CorporateBusinessSector")]
        public ManageSector CorporateBusinessSectorFk { get; set; }

        public virtual int? CorporateCountry { get; set; }

        [ForeignKey("CorporateCountry")]
        public ManageCountry CorporateCountryFk { get; set; }

        public virtual int? CorporateState { get; set; }

        [ForeignKey("CorporateState")]
        public ManageState CorporateStateFk { get; set; }

        public virtual int? ChildTitle { get; set; }

        [ForeignKey("ChildTitle")]
        public ManageTitle ChildTitleFk { get; set; }

        public virtual int? ChildGender { get; set; }

        [ForeignKey("ChildGender")]
        public ManageGender ChildGenderFk { get; set; }

        public virtual int? ChildCountryOfBirth { get; set; }

        [ForeignKey("ChildCountryOfBirth")]
        public ManageCountry ChildCountryOfBirthFk { get; set; }

        public virtual int? OtherNationality { get; set; }

        [ForeignKey("OtherNationality")]
        public ManageCountry OtherNationalityFk { get; set; }

        public virtual int? OnboardingPlatform { get; set; }

        [ForeignKey("OnboardingPlatform")]
        public ManageOnboardingPlatform OnboardingPlatformFk { get; set; }

        //public virtual long? SalesOfficer { get; set; }

        //[ForeignKey("SalesOfficer")]
        //public User SalesOfficerFk { get; set; }


        public virtual string SalesOfficer { get; set; }

        public virtual string SalesOfficerType { get; set; }

        public virtual int? ResidentialCity { get; set; }

      //  [ForeignKey("ResidentialCity")]
        public ManageTown ResidentialCityFk { get; set; }

        public virtual int? DividendPaymentTypeId { get; set; }

        [ForeignKey("DividendPaymentTypeId")]
        public ManageDividendPaymentType DividendPaymentTypeFk { get; set; }

        public virtual int? CorporateLegalEntityType { get; set; }

        [ForeignKey("CorporateLegalEntityType")]
        public ManageLegalEntity CorporateLegalEntityTypeFk { get; set; }

        public virtual int? CorporateSubLegalEntityType { get; set; }

        [ForeignKey("CorporateSubLegalEntityType")]
        public ManageSubLegalEntity CorporateSubLegalEntityTypeFk { get; set; }

        public virtual string BankAccountNameMismatchComment { get; set; }
        public virtual string BvnNameMismatchComment { get; set; }
    }
}