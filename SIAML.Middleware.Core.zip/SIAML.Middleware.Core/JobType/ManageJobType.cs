﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Abp.Domain.Entities.Auditing;
using Abp.Domain.Entities;
using Abp.Auditing;

namespace SIAML.Middleware.JobType
{
    [Table("Tbl_JobTypes")]
    [Audited]
    public class ManageJobType : FullAuditedEntity
    {

        [Required]
        [StringLength(ManageJobTypeConsts.MaxJobTypeNameLength, MinimumLength = ManageJobTypeConsts.MinJobTypeNameLength)]
        public virtual string JobTypeName { get; set; }

    }
}