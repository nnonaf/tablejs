namespace SIAML.Middleware.Chat
{
    /// <summary>
    /// This class is defined to use a generic version of IOnlineClientManager for ChatHub
    /// </summary>
    public class ChatChannel
    {

    }
}