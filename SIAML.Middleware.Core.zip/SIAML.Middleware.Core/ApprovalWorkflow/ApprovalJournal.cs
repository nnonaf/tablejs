﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Abp.Domain.Entities.Auditing;
using Abp.Domain.Entities;

namespace SIAML.Middleware.ApprovalWorkflow
{
    [Table("Tbl_ApprovalJournals")]
    public class ApprovalJournal : FullAuditedEntity<Guid>
    {

        [Required]
        [StringLength(ApprovalJournalConsts.MaxApprovalTypeLength, MinimumLength = ApprovalJournalConsts.MinApprovalTypeLength)]
        public virtual string ApprovalType { get; set; }

        [Required]
        [StringLength(ApprovalJournalConsts.MaxWorkflowIdLength, MinimumLength = ApprovalJournalConsts.MinWorkflowIdLength)]
        public virtual string WorkflowId { get; set; }

        public virtual int ApprovalChainId { get; set; }

        [Required]
        [StringLength(ApprovalJournalConsts.MaxApprovalStatusLength, MinimumLength = ApprovalJournalConsts.MinApprovalStatusLength)]
        public virtual string ApprovalStatus { get; set; }

        [StringLength(ApprovalJournalConsts.MaxApprovalCommentLength, MinimumLength = ApprovalJournalConsts.MinApprovalCommentLength)]
        public virtual string ApprovalComment { get; set; }

        [Required]
        [StringLength(ApprovalJournalConsts.MaxCreatedByLength, MinimumLength = ApprovalJournalConsts.MinCreatedByLength)]
        public virtual string CreatedBy { get; set; }

    }
}