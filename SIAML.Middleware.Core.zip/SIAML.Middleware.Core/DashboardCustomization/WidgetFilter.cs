namespace SIAML.Middleware.DashboardCustomization
{
    public class WidgetFilter
    {
        public string WidgetFilterId { get; set; }

        public byte Height { get; set; }

        public byte Width { get; set; }

        public byte PositionX { get; set; }

        public byte PositionY { get; set; }
    }
}