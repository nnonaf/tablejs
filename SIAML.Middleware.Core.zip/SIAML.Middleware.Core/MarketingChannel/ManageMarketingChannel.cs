﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Abp.Domain.Entities.Auditing;
using Abp.Domain.Entities;
using Abp.Auditing;

namespace SIAML.Middleware.MarketingChannel
{
    [Table("Tbl_MarketingChannels")]
    [Audited]
    public class ManageMarketingChannel : FullAuditedEntity
    {

        [Required]
        [StringLength(ManageMarketingChannelConsts.MaxMarketingChannelLength, MinimumLength = ManageMarketingChannelConsts.MinMarketingChannelLength)]
        public virtual string MarketingChannel { get; set; }

    }
}