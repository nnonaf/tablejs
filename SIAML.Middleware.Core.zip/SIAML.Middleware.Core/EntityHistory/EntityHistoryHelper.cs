﻿using SIAML.Middleware.BuyNewFeature;
using SIAML.Middleware.BusinessConfiguration;
using SIAML.Middleware.LegalEntity;
using SIAML.Middleware.DividendPayment;
using SIAML.Middleware.SubscriptionWorkflowPad;
using SIAML.Middleware.SubscriptionWorkflow;
using SIAML.Middleware.Relationship;
using SIAML.Middleware.Sector;
using SIAML.Middleware.Education;
using SIAML.Middleware.EmploymentStatus;
using SIAML.Middleware.OnboardingPlatform;
using SIAML.Middleware.PaymentMode;
using SIAML.Middleware.FundDetails;
using SIAML.Middleware.Currency;
using SIAML.Middleware.JobType;
using SIAML.Middleware.IdType;
using SIAML.Middleware.MarketingChannel;
using SIAML.Middleware.StockBroker;
using SIAML.Middleware.Bank;
using SIAML.Middleware.State;
using SIAML.Middleware.Country;
using SIAML.Middleware.Religion;
using SIAML.Middleware.Gender;
using SIAML.Middleware.MaritalStatus;
using SIAML.Middleware.Title;
using SIAML.Middleware.Subscription;
using System;
using System.Linq;
using Abp.Organizations;
using SIAML.Middleware.Authorization.Roles;
using SIAML.Middleware.MultiTenancy;
using SIAML.Middleware.Town;

namespace SIAML.Middleware.EntityHistory
{
    public static class EntityHistoryHelper
    {
        public const string EntityHistoryConfigurationName = "EntityHistory";

        public static readonly Type[] HostSideTrackedTypes =
        {
            typeof(OnboardingSubscriptionWorkPad),
            typeof(OnboardingSubscription),
            typeof(OrganizationUnit), typeof(Role), typeof(Tenant)
        };

        public static readonly Type[] TenantSideTrackedTypes =
        {
            //typeof(OnboardingSubscriptionWorkPad),
            typeof(OnboardingSubscription),
            typeof(ManageBank), typeof(ManageBusinessConfiguration), typeof(ManageCountry),
            typeof(ManageCurrency), typeof(ManageDividendPaymentType), typeof(ManageEducation),
            typeof(ManageEmploymentStatus), typeof(ManageFundDetail), typeof(ManageGender),
            typeof(ManageIdType), typeof(ManageJobType), typeof(ManageLegalEntity), typeof(ManageMaritalStatus),
            typeof(ManageMarketingChannel), typeof(ManagePaymentMode), typeof(ManageReligion), typeof(ManageSector),
            typeof(ManageState), typeof(ManageStockBroker), typeof(ManageCountry),
            typeof(ManageTitle), typeof(ManageRelationship), typeof(ManageReligion),typeof(ManageTown),
            typeof(ManageSubscriptionType), typeof(OnboardingSubscriptionCustomerFund), typeof(OnboardingSubscriptionSignatory),
            typeof(OnboardingSubscriptionDirector),
            typeof(OrganizationUnit), typeof(Role)
        };

        public static readonly Type[] TrackedTypes =
            HostSideTrackedTypes
                .Concat(TenantSideTrackedTypes)
                .GroupBy(type => type.FullName)
                .Select(types => types.First())
                .ToArray();
    }
}