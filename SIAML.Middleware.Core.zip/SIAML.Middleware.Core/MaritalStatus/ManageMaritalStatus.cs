﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Abp.Domain.Entities.Auditing;
using Abp.Domain.Entities;
using Abp.Auditing;

namespace SIAML.Middleware.MaritalStatus
{
    [Table("Tbl_MaritalStatus")]
    [Audited]
    public class ManageMaritalStatus : FullAuditedEntity
    {

        [Required]
        [StringLength(ManageMaritalStatusConsts.MaxMaritalStatusLength, MinimumLength = ManageMaritalStatusConsts.MinMaritalStatusLength)]
        public virtual string MaritalStatus { get; set; }

    }
}