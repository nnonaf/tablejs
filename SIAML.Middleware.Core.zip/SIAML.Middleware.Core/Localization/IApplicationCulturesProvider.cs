using System.Globalization;

namespace SIAML.Middleware.Localization
{
    public interface IApplicationCulturesProvider
    {
        CultureInfo[] GetAllCultures();
    }
}