﻿using SIAML.Middleware.State;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Abp.Domain.Entities.Auditing;
using Abp.Domain.Entities;

namespace SIAML.Middleware.Town
{
    [Table("Tbl_Town")]
    public class ManageTown : FullAuditedEntity
    {

        [Required]
        [StringLength(ManageTownConsts.MaxTownNameLength, MinimumLength = ManageTownConsts.MinTownNameLength)]
        public virtual string TownName { get; set; }

        public virtual int? StateId { get; set; }

        [ForeignKey("StateId")]
        public ManageState StateFk { get; set; }

    }
}