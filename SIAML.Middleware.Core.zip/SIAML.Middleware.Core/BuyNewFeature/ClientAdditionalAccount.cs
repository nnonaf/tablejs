﻿using SIAML.Middleware.ApprovalStatusEnums;
using SIAML.Middleware.FundDetails;
using SIAML.Middleware.Bank;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Abp.Domain.Entities.Auditing;
using Abp.Domain.Entities;
using Abp.Auditing;

namespace SIAML.Middleware.BuyNewFeature
{
    [Table("Tbl_ClientAdditionalAccounts")]
    [Audited]
    public class ClientAdditionalAccount : FullAuditedEntity
    {

        [Required]
        [StringLength(ClientAdditionalAccountConsts.MaxFirstNameLength, MinimumLength = ClientAdditionalAccountConsts.MinFirstNameLength)]
        public virtual string FirstName { get; set; }

        [StringLength(ClientAdditionalAccountConsts.MaxMiddleNameLength, MinimumLength = ClientAdditionalAccountConsts.MinMiddleNameLength)]
        public virtual string MiddleName { get; set; }

        [Required]
        [StringLength(ClientAdditionalAccountConsts.MaxLastNameLength, MinimumLength = ClientAdditionalAccountConsts.MinLastNameLength)]
        public virtual string LastName { get; set; }

        [StringLength(ClientAdditionalAccountConsts.MaxFundCodeLength, MinimumLength = ClientAdditionalAccountConsts.MinFundCodeLength)]
        public virtual string FundCode { get; set; }

        [Required]
        [StringLength(ClientAdditionalAccountConsts.MaxEmailLength, MinimumLength = ClientAdditionalAccountConsts.MinEmailLength)]
        public virtual string Email { get; set; }

        [Required]
        [StringLength(ClientAdditionalAccountConsts.MaxPhoneLength, MinimumLength = ClientAdditionalAccountConsts.MinPhoneLength)]
        public virtual string Phone { get; set; }

        [Required]
        [StringLength(ClientAdditionalAccountConsts.MaxGenderLength, MinimumLength = ClientAdditionalAccountConsts.MinGenderLength)]
        public virtual string Gender { get; set; }

        [Required]
        [StringLength(ClientAdditionalAccountConsts.MaxAddressLength, MinimumLength = ClientAdditionalAccountConsts.MinAddressLength)]
        public virtual string Address { get; set; }

        [StringLength(ClientAdditionalAccountConsts.MaxBankNameLength, MinimumLength = ClientAdditionalAccountConsts.MinBankNameLength)]
        public virtual string BankName { get; set; }

        [StringLength(ClientAdditionalAccountConsts.MaxBankSortCodeLength, MinimumLength = ClientAdditionalAccountConsts.MinBankSortCodeLength)]
        public virtual string BankSortCode { get; set; }

        [Required]
        [StringLength(ClientAdditionalAccountConsts.MaxBankAccountNameLength, MinimumLength = ClientAdditionalAccountConsts.MinBankAccountNameLength)]
        public virtual string BankAccountName { get; set; }

        [Required]
        [StringLength(ClientAdditionalAccountConsts.MaxBankAccountNumberLength, MinimumLength = ClientAdditionalAccountConsts.MinBankAccountNumberLength)]
        public virtual string BankAccountNumber { get; set; }

        public virtual DateTime DateOfBirth { get; set; }

        [Required]
        [StringLength(ClientAdditionalAccountConsts.MaxBvnLength, MinimumLength = ClientAdditionalAccountConsts.MinBvnLength)]
        public virtual string Bvn { get; set; }

        [Required]
        [StringLength(ClientAdditionalAccountConsts.MaxSourceChannelLength, MinimumLength = ClientAdditionalAccountConsts.MinSourceChannelLength)]
        public virtual string SourceChannel { get; set; }

        [Required]
        [StringLength(ClientAdditionalAccountConsts.MaxBvnPhoneLength, MinimumLength = ClientAdditionalAccountConsts.MinBvnPhoneLength)]
        public virtual string BvnPhone { get; set; }

        [StringLength(ClientAdditionalAccountConsts.MaxRefByLength, MinimumLength = ClientAdditionalAccountConsts.MinRefByLength)]
        public virtual string RefBy { get; set; }

        [StringLength(ClientAdditionalAccountConsts.MaxNationalityLength, MinimumLength = ClientAdditionalAccountConsts.MinNationalityLength)]
        public virtual string Nationality { get; set; }

        [StringLength(ClientAdditionalAccountConsts.MaxNationalityCodeLength, MinimumLength = ClientAdditionalAccountConsts.MinNationalityCodeLength)]
        public virtual string NationalityCode { get; set; }

        [StringLength(ClientAdditionalAccountConsts.MaxPlaceOfBirthLength, MinimumLength = ClientAdditionalAccountConsts.MinPlaceOfBirthLength)]
        public virtual string PlaceOfBirth { get; set; }

        [Required]
        public virtual string WorkflowId { get; set; }

        public virtual ApprovalStatusEnum ApprovalStatus { get; set; }

        [Required]
        [StringLength(ClientAdditionalAccountConsts.MaxRequestTypeLength, MinimumLength = ClientAdditionalAccountConsts.MinRequestTypeLength)]
        public virtual string RequestType { get; set; }

        [Required]
        [StringLength(ClientAdditionalAccountConsts.MaxEaccountLength, MinimumLength = ClientAdditionalAccountConsts.MinEaccountLength)]
        public virtual string Eaccount { get; set; }

        [StringLength(ClientAdditionalAccountConsts.MaxBankAccountStatusLength, MinimumLength = ClientAdditionalAccountConsts.MinBankAccountStatusLength)]
        public virtual string BankAccountStatus { get; set; }

        public virtual int? FundId { get; set; }

        [ForeignKey("FundId")]
        public ManageFundDetail FundFk { get; set; }

        public virtual int? Bank { get; set; }

        [ForeignKey("Bank")]
        public ManageBank BankFk { get; set; }

    }
}