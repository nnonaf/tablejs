using Microsoft.Extensions.Configuration;

namespace SIAML.Middleware.Configuration
{
    public interface IAppConfigurationAccessor
    {
        IConfigurationRoot Configuration { get; }
    }
}
