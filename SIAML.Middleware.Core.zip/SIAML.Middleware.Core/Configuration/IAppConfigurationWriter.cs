namespace SIAML.Middleware.Configuration
{
    public interface IAppConfigurationWriter
    {
        void Write(string key, string value);
    }
}
