﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Abp.Domain.Entities.Auditing;
using Abp.Domain.Entities;
using Abp.Auditing;

namespace SIAML.Middleware.Sector
{
    [Table("Tbl_Sector")]
    [Audited]
    public class ManageSector : FullAuditedEntity
    {

        [Required]
        [StringLength(ManageSectorConsts.MaxSectorNameLength, MinimumLength = ManageSectorConsts.MinSectorNameLength)]
        public virtual string SectorName { get; set; }

    }
}