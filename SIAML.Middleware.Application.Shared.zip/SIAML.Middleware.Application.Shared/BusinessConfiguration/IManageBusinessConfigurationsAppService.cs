﻿using System;
using System.Threading.Tasks;
using Abp.Application.Services;
using Abp.Application.Services.Dto;
using SIAML.Middleware.BusinessConfiguration.Dtos;
using SIAML.Middleware.Dto;

namespace SIAML.Middleware.BusinessConfiguration
{
    public interface IManageBusinessConfigurationsAppService : IApplicationService
    {
        Task<PagedResultDto<GetManageBusinessConfigurationForViewDto>> GetAll(GetAllManageBusinessConfigurationsInput input);

        Task<GetManageBusinessConfigurationForViewDto> GetManageBusinessConfigurationForView(int id);

        Task<GetManageBusinessConfigurationForEditOutput> GetManageBusinessConfigurationForEdit(EntityDto input);

        Task CreateOrEdit(CreateOrEditManageBusinessConfigurationDto input);

        Task Delete(EntityDto input);

        Task<FileDto> GetManageBusinessConfigurationsToExcel(GetAllManageBusinessConfigurationsForExcelInput input);

    }
}