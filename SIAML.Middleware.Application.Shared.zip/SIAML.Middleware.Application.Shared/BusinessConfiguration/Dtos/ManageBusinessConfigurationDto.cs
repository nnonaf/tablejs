﻿using System;
using Abp.Application.Services.Dto;

namespace SIAML.Middleware.BusinessConfiguration.Dtos
{
    public class ManageBusinessConfigurationDto : EntityDto
    {
        public int MaxNoOfFundTypes { get; set; }

        public int MaxNoOfSignatories { get; set; }

        public int MaxNoOfDirectors { get; set; }

        public int MaxNoOfJointSubscribers { get; set; }

        public bool AllowMultiFundSubscription { get; set; }

        public bool AllowNonFundType { get; set; }

    }
}