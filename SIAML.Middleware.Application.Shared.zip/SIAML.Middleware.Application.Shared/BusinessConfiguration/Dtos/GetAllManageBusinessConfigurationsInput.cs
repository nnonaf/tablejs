﻿using Abp.Application.Services.Dto;
using System;

namespace SIAML.Middleware.BusinessConfiguration.Dtos
{
    public class GetAllManageBusinessConfigurationsInput : PagedAndSortedResultRequestDto
    {
        public string Filter { get; set; }

        public int? MaxMaxNoOfFundTypesFilter { get; set; }
        public int? MinMaxNoOfFundTypesFilter { get; set; }

        public int? MaxMaxNoOfSignatoriesFilter { get; set; }
        public int? MinMaxNoOfSignatoriesFilter { get; set; }

        public int? MaxMaxNoOfDirectorsFilter { get; set; }
        public int? MinMaxNoOfDirectorsFilter { get; set; }

        public int? MaxMaxNoOfJointSubscribersFilter { get; set; }
        public int? MinMaxNoOfJointSubscribersFilter { get; set; }

        public int? AllowMultiFundSubscriptionFilter { get; set; }

        public int? AllowNonFundTypeFilter { get; set; }

    }
}