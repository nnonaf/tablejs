﻿namespace SIAML.Middleware.BusinessConfiguration.Dtos
{
    public class GetManageBusinessConfigurationForViewDto
    {
        public ManageBusinessConfigurationDto ManageBusinessConfiguration { get; set; }

    }
}