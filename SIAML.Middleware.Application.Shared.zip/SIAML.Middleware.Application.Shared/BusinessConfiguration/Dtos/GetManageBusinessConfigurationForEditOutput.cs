﻿using System;
using Abp.Application.Services.Dto;
using System.ComponentModel.DataAnnotations;

namespace SIAML.Middleware.BusinessConfiguration.Dtos
{
    public class GetManageBusinessConfigurationForEditOutput
    {
        public CreateOrEditManageBusinessConfigurationDto ManageBusinessConfiguration { get; set; }

    }
}