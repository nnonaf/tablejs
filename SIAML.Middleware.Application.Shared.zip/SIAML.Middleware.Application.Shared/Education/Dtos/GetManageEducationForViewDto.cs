﻿namespace SIAML.Middleware.Education.Dtos
{
    public class GetManageEducationForViewDto
    {
        public ManageEducationDto ManageEducation { get; set; }

    }
}