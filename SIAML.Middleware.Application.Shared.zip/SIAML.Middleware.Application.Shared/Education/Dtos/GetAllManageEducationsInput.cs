﻿using Abp.Application.Services.Dto;
using System;

namespace SIAML.Middleware.Education.Dtos
{
    public class GetAllManageEducationsInput : PagedAndSortedResultRequestDto
    {
        public string Filter { get; set; }

        public string EducationNameFilter { get; set; }

    }
}