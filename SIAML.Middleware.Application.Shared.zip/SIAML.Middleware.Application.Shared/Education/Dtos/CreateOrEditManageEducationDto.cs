﻿using System;
using Abp.Application.Services.Dto;
using System.ComponentModel.DataAnnotations;

namespace SIAML.Middleware.Education.Dtos
{
    public class CreateOrEditManageEducationDto : EntityDto<int?>
    {

        [Required]
        [StringLength(ManageEducationConsts.MaxEducationNameLength, MinimumLength = ManageEducationConsts.MinEducationNameLength)]
        public string EducationName { get; set; }

    }
}