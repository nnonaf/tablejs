﻿using System;
using Abp.Application.Services.Dto;

namespace SIAML.Middleware.Education.Dtos
{
    public class ManageEducationDto : EntityDto
    {
        public string EducationName { get; set; }

    }
}