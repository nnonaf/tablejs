﻿using System;
using Abp.Application.Services.Dto;
using System.ComponentModel.DataAnnotations;

namespace SIAML.Middleware.Education.Dtos
{
    public class GetManageEducationForEditOutput
    {
        public CreateOrEditManageEducationDto ManageEducation { get; set; }

    }
}