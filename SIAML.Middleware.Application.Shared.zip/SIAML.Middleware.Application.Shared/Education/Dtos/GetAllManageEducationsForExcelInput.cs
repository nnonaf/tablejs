﻿using Abp.Application.Services.Dto;
using System;

namespace SIAML.Middleware.Education.Dtos
{
    public class GetAllManageEducationsForExcelInput
    {
        public string Filter { get; set; }

        public string EducationNameFilter { get; set; }

    }
}