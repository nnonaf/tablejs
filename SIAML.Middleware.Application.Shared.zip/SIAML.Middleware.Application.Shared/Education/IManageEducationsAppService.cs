﻿using System;
using System.Threading.Tasks;
using Abp.Application.Services;
using Abp.Application.Services.Dto;
using SIAML.Middleware.Education.Dtos;
using SIAML.Middleware.Dto;

namespace SIAML.Middleware.Education
{
    public interface IManageEducationsAppService : IApplicationService
    {
        Task<PagedResultDto<GetManageEducationForViewDto>> GetAll(GetAllManageEducationsInput input);

        Task<GetManageEducationForViewDto> GetManageEducationForView(int id);

        Task<GetManageEducationForEditOutput> GetManageEducationForEdit(EntityDto input);

        Task CreateOrEdit(CreateOrEditManageEducationDto input);

        Task Delete(EntityDto input);

        Task<FileDto> GetManageEducationsToExcel(GetAllManageEducationsForExcelInput input);

    }
}