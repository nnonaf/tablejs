﻿using System;
using System.Threading.Tasks;
using Abp.Application.Services;
using Abp.Application.Services.Dto;
using SIAML.Middleware.Religion.Dtos;
using SIAML.Middleware.Dto;

namespace SIAML.Middleware.Religion
{
    public interface IManageReligionsAppService : IApplicationService
    {
        Task<PagedResultDto<GetManageReligionForViewDto>> GetAll(GetAllManageReligionsInput input);

        Task<GetManageReligionForViewDto> GetManageReligionForView(int id);

        Task<GetManageReligionForEditOutput> GetManageReligionForEdit(EntityDto input);

        Task CreateOrEdit(CreateOrEditManageReligionDto input);

        Task Delete(EntityDto input);

        Task<FileDto> GetManageReligionsToExcel(GetAllManageReligionsForExcelInput input);

    }
}