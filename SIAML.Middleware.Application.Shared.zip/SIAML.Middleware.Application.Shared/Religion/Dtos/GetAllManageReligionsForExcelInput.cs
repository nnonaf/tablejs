﻿using Abp.Application.Services.Dto;
using System;

namespace SIAML.Middleware.Religion.Dtos
{
    public class GetAllManageReligionsForExcelInput
    {
        public string Filter { get; set; }

        public string ReligionFilter { get; set; }

    }
}