﻿using Abp.Application.Services.Dto;

namespace SIAML.Middleware.Religion.Dtos
{
    public class GetAllForLookupTableInput : PagedAndSortedResultRequestDto
    {
        public string Filter { get; set; }
    }
}