﻿namespace SIAML.Middleware.Religion.Dtos
{
    public class GetManageReligionForViewDto
    {
        public ManageReligionDto ManageReligion { get; set; }

    }
}