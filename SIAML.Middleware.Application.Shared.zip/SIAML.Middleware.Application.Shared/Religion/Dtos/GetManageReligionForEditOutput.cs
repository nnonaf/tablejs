﻿using System;
using Abp.Application.Services.Dto;
using System.ComponentModel.DataAnnotations;

namespace SIAML.Middleware.Religion.Dtos
{
    public class GetManageReligionForEditOutput
    {
        public CreateOrEditManageReligionDto ManageReligion { get; set; }

    }
}