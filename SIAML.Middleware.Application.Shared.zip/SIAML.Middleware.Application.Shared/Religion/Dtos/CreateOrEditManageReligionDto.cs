﻿using System;
using Abp.Application.Services.Dto;
using System.ComponentModel.DataAnnotations;

namespace SIAML.Middleware.Religion.Dtos
{
    public class CreateOrEditManageReligionDto : EntityDto<int?>
    {

        [Required]
        [StringLength(ManageReligionConsts.MaxReligionLength, MinimumLength = ManageReligionConsts.MinReligionLength)]
        public string Religion { get; set; }

    }
}