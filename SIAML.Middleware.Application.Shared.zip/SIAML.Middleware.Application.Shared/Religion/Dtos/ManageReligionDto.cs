﻿using System;
using Abp.Application.Services.Dto;

namespace SIAML.Middleware.Religion.Dtos
{
    public class ManageReligionDto : EntityDto
    {
        public string Religion { get; set; }

    }
}