﻿using Abp.Application.Services.Dto;
using System;

namespace SIAML.Middleware.EmploymentStatus.Dtos
{
    public class GetAllManageEmploymentStatusesForExcelInput
    {
        public string Filter { get; set; }

        public string EmploymentStatusFilter { get; set; }

    }
}