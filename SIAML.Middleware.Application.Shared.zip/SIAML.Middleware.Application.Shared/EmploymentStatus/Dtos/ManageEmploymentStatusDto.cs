﻿using System;
using Abp.Application.Services.Dto;

namespace SIAML.Middleware.EmploymentStatus.Dtos
{
    public class ManageEmploymentStatusDto : EntityDto
    {
        public string EmploymentStatus { get; set; }

    }
}