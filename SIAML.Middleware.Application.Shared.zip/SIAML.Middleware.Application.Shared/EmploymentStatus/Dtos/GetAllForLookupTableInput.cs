﻿using Abp.Application.Services.Dto;

namespace SIAML.Middleware.EmploymentStatus.Dtos
{
    public class GetAllForLookupTableInput : PagedAndSortedResultRequestDto
    {
        public string Filter { get; set; }
    }
}