﻿using System;
using Abp.Application.Services.Dto;
using System.ComponentModel.DataAnnotations;

namespace SIAML.Middleware.EmploymentStatus.Dtos
{
    public class CreateOrEditManageEmploymentStatusDto : EntityDto<int?>
    {

        [Required]
        [StringLength(ManageEmploymentStatusConsts.MaxEmploymentStatusLength, MinimumLength = ManageEmploymentStatusConsts.MinEmploymentStatusLength)]
        public string EmploymentStatus { get; set; }

    }
}