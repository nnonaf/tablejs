﻿namespace SIAML.Middleware.EmploymentStatus.Dtos
{
    public class GetManageEmploymentStatusForViewDto
    {
        public ManageEmploymentStatusDto ManageEmploymentStatus { get; set; }

    }
}