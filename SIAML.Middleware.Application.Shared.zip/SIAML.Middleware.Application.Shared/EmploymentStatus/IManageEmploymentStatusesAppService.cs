﻿using System;
using System.Threading.Tasks;
using Abp.Application.Services;
using Abp.Application.Services.Dto;
using SIAML.Middleware.EmploymentStatus.Dtos;
using SIAML.Middleware.Dto;

namespace SIAML.Middleware.EmploymentStatus
{
    public interface IManageEmploymentStatusesAppService : IApplicationService
    {
        Task<PagedResultDto<GetManageEmploymentStatusForViewDto>> GetAll(GetAllManageEmploymentStatusesInput input);

        Task<GetManageEmploymentStatusForViewDto> GetManageEmploymentStatusForView(int id);

        Task<GetManageEmploymentStatusForEditOutput> GetManageEmploymentStatusForEdit(EntityDto input);

        Task CreateOrEdit(CreateOrEditManageEmploymentStatusDto input);

        Task Delete(EntityDto input);

        Task<FileDto> GetManageEmploymentStatusesToExcel(GetAllManageEmploymentStatusesForExcelInput input);

    }
}