﻿using System;
using Abp.Application.Services.Dto;

namespace SIAML.Middleware.OnboardingPlatform.Dtos
{
    public class ManageOnboardingPlatformDto : EntityDto
    {
        public string OnboardingPlatform { get; set; }

    }
}