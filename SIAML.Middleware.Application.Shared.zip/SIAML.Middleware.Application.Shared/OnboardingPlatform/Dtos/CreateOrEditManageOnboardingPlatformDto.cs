﻿using System;
using Abp.Application.Services.Dto;
using System.ComponentModel.DataAnnotations;

namespace SIAML.Middleware.OnboardingPlatform.Dtos
{
    public class CreateOrEditManageOnboardingPlatformDto : EntityDto<int?>
    {

        [Required]
        [StringLength(ManageOnboardingPlatformConsts.MaxOnboardingPlatformLength, MinimumLength = ManageOnboardingPlatformConsts.MinOnboardingPlatformLength)]
        public string OnboardingPlatform { get; set; }

    }
}