﻿namespace SIAML.Middleware.OnboardingPlatform.Dtos
{
    public class GetManageOnboardingPlatformForViewDto
    {
        public ManageOnboardingPlatformDto ManageOnboardingPlatform { get; set; }

    }
}