﻿using Abp.Application.Services.Dto;
using System;

namespace SIAML.Middleware.OnboardingPlatform.Dtos
{
    public class GetAllManageOnboardingPlatformsInput : PagedAndSortedResultRequestDto
    {
        public string Filter { get; set; }

        public string OnboardingPlatformFilter { get; set; }

    }
}