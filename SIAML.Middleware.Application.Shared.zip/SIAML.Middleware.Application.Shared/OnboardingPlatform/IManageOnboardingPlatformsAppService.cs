﻿using System;
using System.Threading.Tasks;
using Abp.Application.Services;
using Abp.Application.Services.Dto;
using SIAML.Middleware.OnboardingPlatform.Dtos;
using SIAML.Middleware.Dto;

namespace SIAML.Middleware.OnboardingPlatform
{
    public interface IManageOnboardingPlatformsAppService : IApplicationService
    {
        Task<PagedResultDto<GetManageOnboardingPlatformForViewDto>> GetAll(GetAllManageOnboardingPlatformsInput input);

        Task<GetManageOnboardingPlatformForViewDto> GetManageOnboardingPlatformForView(int id);

        Task<GetManageOnboardingPlatformForEditOutput> GetManageOnboardingPlatformForEdit(EntityDto input);

        Task CreateOrEdit(CreateOrEditManageOnboardingPlatformDto input);

        Task Delete(EntityDto input);

        Task<FileDto> GetManageOnboardingPlatformsToExcel(GetAllManageOnboardingPlatformsForExcelInput input);

    }
}