﻿namespace SIAML.Middleware.Country.Dtos
{
    public class GetManageCountryForViewDto
    {
        public ManageCountryDto ManageCountry { get; set; }

    }
}