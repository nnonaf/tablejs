﻿using System;
using Abp.Application.Services.Dto;
using System.ComponentModel.DataAnnotations;

namespace SIAML.Middleware.Country.Dtos
{
    public class CreateOrEditManageCountryDto : EntityDto<int?>
    {
        /// <summary>
        /// The Name of Country
        /// <para>Max Length: <see cref="ManageCountryConsts.MaxCountryNameLength"/></para>
        /// <para>Min Length: <see cref="ManageCountryConsts.MinCountryNameLength"/></para>
        /// <para>Required</para>
        /// <para>Unique</para>
        /// <para>Not Nullable</para>
        /// </summary>
        [Required]
        [StringLength(ManageCountryConsts.MaxCountryNameLength, MinimumLength = ManageCountryConsts.MinCountryNameLength)]
        public string CountryName { get; set; }


        /// <summary>
        /// The Code of Country
        /// <para>Max Length: <see cref="ManageCountryConsts.MaxCountryCodeLength"/></para>
        /// <para>Min Length: <see cref="ManageCountryConsts.MinCountryCodeLength"/></para>
        /// <para>Required</para>
        /// <para>Unique</para>
        /// <para>Not Nullable</para>
        /// <para>Regex: <see cref="ManageCountryConsts.CountryCodeRegex"/></para>
        /// </summary>  
        [Required]
        [RegularExpression(ManageCountryConsts.CountryCodeRegex)]
        [StringLength(ManageCountryConsts.MaxCountryCodeLength, MinimumLength = ManageCountryConsts.MinCountryCodeLength)]
        public string CountryCode { get; set; }

        [Required]
        [RegularExpression(ManageCountryConsts.ISOAlpha2CodeRegex)]
        [StringLength(ManageCountryConsts.MaxISOAlpha2CodeLength, MinimumLength = ManageCountryConsts.MinISOAlpha2CodeLength)]
        public string ISOAlpha2Code { get; set; }

    }
}