﻿using System;
using Abp.Application.Services.Dto;
using System.ComponentModel.DataAnnotations;

namespace SIAML.Middleware.Country.Dtos
{
    public class GetManageCountryForEditOutput
    {
        public CreateOrEditManageCountryDto ManageCountry { get; set; }

    }
}