﻿using System;
using System.ComponentModel.DataAnnotations;
using Abp.Application.Services.Dto;

namespace SIAML.Middleware.Country.Dtos
{
    public class ManageCountryDto : EntityDto
    {
        public string CountryName { get; set; }

        public string CountryCode { get; set; }

        public string ISOAlpha2Code { get; set; }

    }
}