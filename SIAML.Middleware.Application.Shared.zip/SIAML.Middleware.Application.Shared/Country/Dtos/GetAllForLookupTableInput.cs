﻿using Abp.Application.Services.Dto;

namespace SIAML.Middleware.Country.Dtos
{
    public class GetAllForLookupTableInput : PagedAndSortedResultRequestDto
    {
        public string Filter { get; set; }
    }
}