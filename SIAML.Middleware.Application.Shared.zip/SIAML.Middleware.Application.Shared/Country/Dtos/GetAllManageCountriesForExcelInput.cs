﻿using Abp.Application.Services.Dto;
using System;

namespace SIAML.Middleware.Country.Dtos
{
    public class GetAllManageCountriesForExcelInput
    {
        public string Filter { get; set; }

        public string CountryNameFilter { get; set; }

        public string CountryCodeFilter { get; set; }

        public string ISOAlpha2CodeFilter { get; set; }

    }
}