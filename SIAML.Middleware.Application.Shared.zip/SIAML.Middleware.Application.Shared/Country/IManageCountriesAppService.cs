﻿using System;
using System.Threading.Tasks;
using Abp.Application.Services;
using Abp.Application.Services.Dto;
using SIAML.Middleware.Country.Dtos;
using SIAML.Middleware.Dto;

namespace SIAML.Middleware.Country
{
    public interface IManageCountriesAppService : IApplicationService
    {
        Task<PagedResultDto<GetManageCountryForViewDto>> GetAll(GetAllManageCountriesInput input);

        Task<GetManageCountryForViewDto> GetManageCountryForView(int id);

        Task<GetManageCountryForEditOutput> GetManageCountryForEdit(EntityDto input);

        Task CreateOrEdit(CreateOrEditManageCountryDto input);

        Task Delete(EntityDto input);

        Task<FileDto> GetManageCountriesToExcel(GetAllManageCountriesForExcelInput input);

    }
}