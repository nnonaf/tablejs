﻿using System;
using System.Threading.Tasks;
using Abp.Application.Services;
using Abp.Application.Services.Dto;
using SIAML.Middleware.Currency.Dtos;
using SIAML.Middleware.Dto;

namespace SIAML.Middleware.Currency
{
    public interface IManageCurrenciesAppService : IApplicationService
    {
        Task<PagedResultDto<GetManageCurrencyForViewDto>> GetAll(GetAllManageCurrenciesInput input);

        Task<GetManageCurrencyForViewDto> GetManageCurrencyForView(int id);

        Task<GetManageCurrencyForEditOutput> GetManageCurrencyForEdit(EntityDto input);

        Task CreateOrEdit(CreateOrEditManageCurrencyDto input);

        Task Delete(EntityDto input);

        Task<FileDto> GetManageCurrenciesToExcel(GetAllManageCurrenciesForExcelInput input);

    }
}