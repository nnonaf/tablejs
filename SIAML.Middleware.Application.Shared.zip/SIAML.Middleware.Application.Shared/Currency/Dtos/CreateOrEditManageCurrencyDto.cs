﻿using System;
using Abp.Application.Services.Dto;
using System.ComponentModel.DataAnnotations;

namespace SIAML.Middleware.Currency.Dtos
{
    public class CreateOrEditManageCurrencyDto : EntityDto<int?>
    {

        [Required]
        [StringLength(ManageCurrencyConsts.MaxCurrrencyNameLength, MinimumLength = ManageCurrencyConsts.MinCurrrencyNameLength)]
        public string CurrrencyName { get; set; }

        [Required]
        [StringLength(ManageCurrencyConsts.MaxCurrencyMnemonicLength, MinimumLength = ManageCurrencyConsts.MinCurrencyMnemonicLength)]
        public string CurrencyMnemonic { get; set; }

    }
}