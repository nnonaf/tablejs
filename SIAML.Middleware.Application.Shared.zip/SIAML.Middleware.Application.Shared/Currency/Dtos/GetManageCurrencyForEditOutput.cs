﻿using System;
using Abp.Application.Services.Dto;
using System.ComponentModel.DataAnnotations;

namespace SIAML.Middleware.Currency.Dtos
{
    public class GetManageCurrencyForEditOutput
    {
        public CreateOrEditManageCurrencyDto ManageCurrency { get; set; }

    }
}