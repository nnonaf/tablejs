﻿using Abp.Application.Services.Dto;
using System;

namespace SIAML.Middleware.Currency.Dtos
{
    public class GetAllManageCurrenciesInput : PagedAndSortedResultRequestDto
    {
        public string Filter { get; set; }

        public string CurrrencyNameFilter { get; set; }

        public string CurrencyMnemonicFilter { get; set; }

    }
}