﻿using System;
using Abp.Application.Services.Dto;

namespace SIAML.Middleware.Currency.Dtos
{
    public class ManageCurrencyDto : EntityDto
    {
        public string CurrrencyName { get; set; }

        public string CurrencyMnemonic { get; set; }

    }
}