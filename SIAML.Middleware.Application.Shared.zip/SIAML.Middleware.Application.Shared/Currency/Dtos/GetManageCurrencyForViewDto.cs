﻿namespace SIAML.Middleware.Currency.Dtos
{
    public class GetManageCurrencyForViewDto
    {
        public ManageCurrencyDto ManageCurrency { get; set; }

    }
}