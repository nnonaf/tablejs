﻿namespace SIAML.Middleware.Bank.Dtos
{
    public class GetManageBankForViewDto
    {
        public ManageBankDto ManageBank { get; set; }

    }
}