﻿using System;
using Abp.Application.Services.Dto;
using System.ComponentModel.DataAnnotations;

namespace SIAML.Middleware.Bank.Dtos
{
    public class CreateOrEditManageBankDto : EntityDto<int?>
    {

        [Required]
        [StringLength(ManageBankConsts.MaxBankCodeLength, MinimumLength = ManageBankConsts.MinBankCodeLength)]
        public string BankCode { get; set; }

        [Required]
        [StringLength(ManageBankConsts.MaxBankNameLength, MinimumLength = ManageBankConsts.MinBankNameLength)]
        public string BankName { get; set; }

    }
}