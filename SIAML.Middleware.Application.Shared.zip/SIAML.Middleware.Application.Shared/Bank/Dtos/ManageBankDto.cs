﻿using System;
using Abp.Application.Services.Dto;

namespace SIAML.Middleware.Bank.Dtos
{
    public class ManageBankDto : EntityDto
    {
        public string BankCode { get; set; }

        public string BankName { get; set; }

    }
}