﻿using Abp.Application.Services.Dto;
using System;

namespace SIAML.Middleware.Bank.Dtos
{
    public class GetAllManageBanksForExcelInput
    {
        public string Filter { get; set; }

        public string BankCodeFilter { get; set; }

        public string BankNameFilter { get; set; }

    }
}