﻿using Abp.Application.Services.Dto;

namespace SIAML.Middleware.Bank.Dtos
{
    public class GetAllForLookupTableInput : PagedAndSortedResultRequestDto
    {
        public string Filter { get; set; }
    }
}