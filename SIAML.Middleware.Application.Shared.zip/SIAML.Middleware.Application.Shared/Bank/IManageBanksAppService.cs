﻿using System;
using System.Threading.Tasks;
using Abp.Application.Services;
using Abp.Application.Services.Dto;
using SIAML.Middleware.Bank.Dtos;
using SIAML.Middleware.Dto;

namespace SIAML.Middleware.Bank
{
    public interface IManageBanksAppService : IApplicationService
    {
        Task<PagedResultDto<GetManageBankForViewDto>> GetAll(GetAllManageBanksInput input);

        Task<GetManageBankForViewDto> GetManageBankForView(int id);

        Task<GetManageBankForEditOutput> GetManageBankForEdit(EntityDto input);

        Task CreateOrEdit(CreateOrEditManageBankDto input);

        Task Delete(EntityDto input);

        Task<FileDto> GetManageBanksToExcel(GetAllManageBanksForExcelInput input);

    }
}