﻿using Abp.Application.Services.Dto;
using System;

namespace SIAML.Middleware.IdType.Dtos
{
    public class GetAllManageIdTypesForExcelInput
    {
        public string Filter { get; set; }

        public string IdTypeNameFilter { get; set; }

        public int? HasExpiryDateFilter { get; set; }

    }
}