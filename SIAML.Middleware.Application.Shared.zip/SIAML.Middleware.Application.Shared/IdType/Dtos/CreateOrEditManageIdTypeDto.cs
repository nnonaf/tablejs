﻿using System;
using Abp.Application.Services.Dto;
using System.ComponentModel.DataAnnotations;

namespace SIAML.Middleware.IdType.Dtos
{
    public class CreateOrEditManageIdTypeDto : EntityDto<int?>
    {

        [Required]
        [StringLength(ManageIdTypeConsts.MaxIdTypeNameLength, MinimumLength = ManageIdTypeConsts.MinIdTypeNameLength)]
        public string IdTypeName { get; set; }

        public bool HasExpiryDate { get; set; }

    }
}