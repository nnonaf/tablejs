﻿using System;
using Abp.Application.Services.Dto;

namespace SIAML.Middleware.IdType.Dtos
{
    public class ManageIdTypeDto : EntityDto
    {
        public string IdTypeName { get; set; }

        public bool HasExpiryDate { get; set; }

    }
}