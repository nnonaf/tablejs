﻿using System;
using Abp.Application.Services.Dto;
using System.ComponentModel.DataAnnotations;

namespace SIAML.Middleware.IdType.Dtos
{
    public class GetManageIdTypeForEditOutput
    {
        public CreateOrEditManageIdTypeDto ManageIdType { get; set; }

    }
}