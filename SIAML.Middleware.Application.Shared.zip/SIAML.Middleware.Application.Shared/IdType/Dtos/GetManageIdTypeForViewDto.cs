﻿namespace SIAML.Middleware.IdType.Dtos
{
    public class GetManageIdTypeForViewDto
    {
        public ManageIdTypeDto ManageIdType { get; set; }

    }
}