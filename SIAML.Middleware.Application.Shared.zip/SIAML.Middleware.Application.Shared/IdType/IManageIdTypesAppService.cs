﻿using System;
using System.Threading.Tasks;
using Abp.Application.Services;
using Abp.Application.Services.Dto;
using SIAML.Middleware.IdType.Dtos;
using SIAML.Middleware.Dto;

namespace SIAML.Middleware.IdType
{
    public interface IManageIdTypesAppService : IApplicationService
    {
        Task<PagedResultDto<GetManageIdTypeForViewDto>> GetAll(GetAllManageIdTypesInput input);

        Task<GetManageIdTypeForViewDto> GetManageIdTypeForView(int id);

        Task<GetManageIdTypeForEditOutput> GetManageIdTypeForEdit(EntityDto input);

        Task CreateOrEdit(CreateOrEditManageIdTypeDto input);

        Task Delete(EntityDto input);

        Task<FileDto> GetManageIdTypesToExcel(GetAllManageIdTypesForExcelInput input);

    }
}