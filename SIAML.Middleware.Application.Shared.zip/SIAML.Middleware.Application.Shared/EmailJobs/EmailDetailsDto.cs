﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SIAML.Middleware.EmailJobs
{
    public class EmailDetailsDto
    {
        public  string EmailAddress { get; set; }
        public string EmailSubject { get; set; }
        public string EmailBody { get; set; }


    }
}
