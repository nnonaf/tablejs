﻿using System;
using System.Threading.Tasks;
using Abp.Application.Services;
using Abp.Application.Services.Dto;
using SIAML.Middleware.JobType.Dtos;
using SIAML.Middleware.Dto;

namespace SIAML.Middleware.JobType
{
    public interface IManageJobTypesAppService : IApplicationService
    {
        Task<PagedResultDto<GetManageJobTypeForViewDto>> GetAll(GetAllManageJobTypesInput input);

        Task<GetManageJobTypeForViewDto> GetManageJobTypeForView(int id);

        Task<GetManageJobTypeForEditOutput> GetManageJobTypeForEdit(EntityDto input);

        Task CreateOrEdit(CreateOrEditManageJobTypeDto input);

        Task Delete(EntityDto input);

        Task<FileDto> GetManageJobTypesToExcel(GetAllManageJobTypesForExcelInput input);

    }
}