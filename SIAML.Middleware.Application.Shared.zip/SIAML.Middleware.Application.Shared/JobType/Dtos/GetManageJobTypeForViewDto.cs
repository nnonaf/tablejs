﻿namespace SIAML.Middleware.JobType.Dtos
{
    public class GetManageJobTypeForViewDto
    {
        public ManageJobTypeDto ManageJobType { get; set; }

    }
}