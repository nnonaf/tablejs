﻿using Abp.Application.Services.Dto;

namespace SIAML.Middleware.JobType.Dtos
{
    public class GetAllForLookupTableInput : PagedAndSortedResultRequestDto
    {
        public string Filter { get; set; }
    }
}