﻿using Abp.Application.Services.Dto;
using System;

namespace SIAML.Middleware.JobType.Dtos
{
    public class GetAllManageJobTypesForExcelInput
    {
        public string Filter { get; set; }

        public string JobTypeNameFilter { get; set; }

    }
}