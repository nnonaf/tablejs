﻿using System;
using Abp.Application.Services.Dto;
using System.ComponentModel.DataAnnotations;

namespace SIAML.Middleware.JobType.Dtos
{
    public class CreateOrEditManageJobTypeDto : EntityDto<int?>
    {

        [Required]
        [StringLength(ManageJobTypeConsts.MaxJobTypeNameLength, MinimumLength = ManageJobTypeConsts.MinJobTypeNameLength)]
        public string JobTypeName { get; set; }

    }
}