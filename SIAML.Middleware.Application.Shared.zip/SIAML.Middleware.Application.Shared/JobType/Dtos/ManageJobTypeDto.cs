﻿using System;
using Abp.Application.Services.Dto;

namespace SIAML.Middleware.JobType.Dtos
{
    public class ManageJobTypeDto : EntityDto
    {
        public string JobTypeName { get; set; }

    }
}