﻿using System;
using System.Threading.Tasks;
using Abp.Application.Services;
using Abp.Application.Services.Dto;
using SIAML.Middleware.State.Dtos;
using SIAML.Middleware.Dto;

namespace SIAML.Middleware.State
{
    public interface IManageStatesAppService : IApplicationService
    {
        Task<PagedResultDto<GetManageStateForViewDto>> GetAll(GetAllManageStatesInput input);

        Task<GetManageStateForViewDto> GetManageStateForView(int id);

        Task<GetManageStateForEditOutput> GetManageStateForEdit(EntityDto input);

        Task CreateOrEdit(CreateOrEditManageStateDto input);

        Task Delete(EntityDto input);

        Task<FileDto> GetManageStatesToExcel(GetAllManageStatesForExcelInput input);

        Task<PagedResultDto<ManageStateManageCountryLookupTableDto>> GetAllManageCountryForLookupTable(GetAllForLookupTableInput input);

    }
}