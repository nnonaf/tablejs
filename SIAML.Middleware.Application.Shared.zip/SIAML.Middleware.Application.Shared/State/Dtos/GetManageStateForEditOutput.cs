﻿using System;
using Abp.Application.Services.Dto;
using System.ComponentModel.DataAnnotations;

namespace SIAML.Middleware.State.Dtos
{
    public class GetManageStateForEditOutput
    {
        public CreateOrEditManageStateDto ManageState { get; set; }

        public string ManageCountryCountryName { get; set; }

    }
}