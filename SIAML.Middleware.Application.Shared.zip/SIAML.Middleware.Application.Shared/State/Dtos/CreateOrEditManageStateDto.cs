﻿using System;
using Abp.Application.Services.Dto;
using System.ComponentModel.DataAnnotations;

namespace SIAML.Middleware.State.Dtos
{
    public class CreateOrEditManageStateDto : EntityDto<int?>
    {

        [Required]
        [StringLength(ManageStateConsts.MaxStateNameLength, MinimumLength = ManageStateConsts.MinStateNameLength)]
        public string StateName { get; set; }

        public int? CountryId { get; set; }

        [Required]
        [RegularExpression(ManageStateConsts.ISOCodeRegex)]
        [StringLength(ManageStateConsts.MaxISOCodeLength, MinimumLength = ManageStateConsts.MinISOCodeLength)]
        public string ISOCode { get; set; }

    }
}