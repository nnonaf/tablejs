﻿namespace SIAML.Middleware.State.Dtos
{
    public class GetManageStateForViewDto
    {
        public ManageStateDto ManageState { get; set; }

        public string ManageCountryCountryName { get; set; }

    }
}