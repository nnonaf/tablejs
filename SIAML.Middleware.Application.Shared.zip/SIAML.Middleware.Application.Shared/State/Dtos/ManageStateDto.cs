﻿using System;
using System.ComponentModel.DataAnnotations;
using Abp.Application.Services.Dto;

namespace SIAML.Middleware.State.Dtos
{
    public class ManageStateDto : EntityDto
    {
        public string StateName { get; set; }

        public int? CountryId { get; set; }

        public string ISOCode { get; set; }
    }
}