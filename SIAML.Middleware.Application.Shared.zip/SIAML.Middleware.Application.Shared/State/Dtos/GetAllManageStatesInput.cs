﻿using Abp.Application.Services.Dto;
using System;

namespace SIAML.Middleware.State.Dtos
{
    public class GetAllManageStatesInput : PagedAndSortedResultRequestDto
    {
        public string Filter { get; set; }

        public string StateNameFilter { get; set; }

        public int? CountryId { get; set; }

        public string ISOCodeFilter { get; set; }

        public string ManageCountryCountryNameFilter { get; set; }

    }
}