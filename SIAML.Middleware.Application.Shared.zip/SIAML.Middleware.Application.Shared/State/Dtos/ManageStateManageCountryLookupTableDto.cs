﻿using Abp.Application.Services.Dto;

namespace SIAML.Middleware.State.Dtos
{
    public class ManageStateManageCountryLookupTableDto
    {
        public int Id { get; set; }

        public string DisplayName { get; set; }
    }
}