namespace SIAML.Middleware.Notifications.Dto
{
    public class MassNotificationUserLookupTableDto
    {
        public long Id { get; set; }

        public string DisplayName { get; set; }
    }
}