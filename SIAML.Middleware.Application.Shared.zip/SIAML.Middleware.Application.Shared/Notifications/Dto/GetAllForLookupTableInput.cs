using Abp.Application.Services.Dto;

namespace SIAML.Middleware.Notifications.Dto
{
    public class GetAllForLookupTableInput : PagedAndSortedResultRequestDto
    {
        public string Filter { get; set; }
    }
}