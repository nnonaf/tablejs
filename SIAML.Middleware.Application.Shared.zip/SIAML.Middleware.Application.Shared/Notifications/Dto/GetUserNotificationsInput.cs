using System;
using Abp.Notifications;
using SIAML.Middleware.Dto;

namespace SIAML.Middleware.Notifications.Dto
{
    public class GetUserNotificationsInput : PagedInputDto
    {
        public UserNotificationState? State { get; set; }

        public DateTime? StartDate { get; set; }

        public DateTime? EndDate { get; set; }
    }
}