﻿using System;
using System.Threading.Tasks;
using Abp.Application.Services;
using Abp.Application.Services.Dto;
using SIAML.Middleware.MaritalStatus.Dtos;
using SIAML.Middleware.Dto;

namespace SIAML.Middleware.MaritalStatus
{
    public interface IManageMaritalStatusesAppService : IApplicationService
    {
        Task<PagedResultDto<GetManageMaritalStatusForViewDto>> GetAll(GetAllManageMaritalStatusesInput input);

        Task<GetManageMaritalStatusForViewDto> GetManageMaritalStatusForView(int id);

        Task<GetManageMaritalStatusForEditOutput> GetManageMaritalStatusForEdit(EntityDto input);

        Task CreateOrEdit(CreateOrEditManageMaritalStatusDto input);

        Task Delete(EntityDto input);

        Task<FileDto> GetManageMaritalStatusesToExcel(GetAllManageMaritalStatusesForExcelInput input);

    }
}