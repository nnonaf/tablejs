﻿using System;
using Abp.Application.Services.Dto;

namespace SIAML.Middleware.MaritalStatus.Dtos
{
    public class ManageMaritalStatusDto : EntityDto
    {
        public string MaritalStatus { get; set; }

    }
}