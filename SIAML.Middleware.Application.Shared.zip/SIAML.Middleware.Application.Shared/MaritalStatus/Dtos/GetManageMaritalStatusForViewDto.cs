﻿namespace SIAML.Middleware.MaritalStatus.Dtos
{
    public class GetManageMaritalStatusForViewDto
    {
        public ManageMaritalStatusDto ManageMaritalStatus { get; set; }

    }
}