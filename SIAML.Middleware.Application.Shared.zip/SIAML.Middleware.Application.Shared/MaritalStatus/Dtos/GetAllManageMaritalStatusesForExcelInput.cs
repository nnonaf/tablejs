﻿using Abp.Application.Services.Dto;
using System;

namespace SIAML.Middleware.MaritalStatus.Dtos
{
    public class GetAllManageMaritalStatusesForExcelInput
    {
        public string Filter { get; set; }

        public string MaritalStatusFilter { get; set; }

    }
}