namespace SIAML.Middleware.Editions.Dto
{
	//Mapped in CustomDtoMapper
	public class LocalizableComboboxItemDto
	{
		public string Value { get; set; }

		public string DisplayText { get; set; }
	}
}