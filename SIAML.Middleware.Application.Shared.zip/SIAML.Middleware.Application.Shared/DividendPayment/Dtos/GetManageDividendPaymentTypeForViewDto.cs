﻿namespace SIAML.Middleware.DividendPayment.Dtos
{
    public class GetManageDividendPaymentTypeForViewDto
    {
        public ManageDividendPaymentTypeDto ManageDividendPaymentType { get; set; }

    }
}