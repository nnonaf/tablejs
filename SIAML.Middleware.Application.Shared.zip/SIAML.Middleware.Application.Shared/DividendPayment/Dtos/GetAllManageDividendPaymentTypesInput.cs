﻿using Abp.Application.Services.Dto;
using System;

namespace SIAML.Middleware.DividendPayment.Dtos
{
    public class GetAllManageDividendPaymentTypesInput : PagedAndSortedResultRequestDto
    {
        public string Filter { get; set; }

        public string DividendPaymentTypeFilter { get; set; }

    }
}