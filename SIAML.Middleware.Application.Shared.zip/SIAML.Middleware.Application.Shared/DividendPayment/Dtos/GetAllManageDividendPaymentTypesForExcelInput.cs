﻿using Abp.Application.Services.Dto;
using System;

namespace SIAML.Middleware.DividendPayment.Dtos
{
    public class GetAllManageDividendPaymentTypesForExcelInput
    {
        public string Filter { get; set; }

        public string DividendPaymentTypeFilter { get; set; }

    }
}