﻿using Abp.Application.Services.Dto;

namespace SIAML.Middleware.DividendPayment.Dtos
{
    public class GetAllForLookupTableInput : PagedAndSortedResultRequestDto
    {
        public string Filter { get; set; }
    }
}