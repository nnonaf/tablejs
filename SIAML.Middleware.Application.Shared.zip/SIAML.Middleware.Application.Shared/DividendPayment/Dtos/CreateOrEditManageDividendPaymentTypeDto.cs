﻿using System;
using Abp.Application.Services.Dto;
using System.ComponentModel.DataAnnotations;

namespace SIAML.Middleware.DividendPayment.Dtos
{
    public class CreateOrEditManageDividendPaymentTypeDto : EntityDto<int?>
    {

        [Required]
        [StringLength(ManageDividendPaymentTypeConsts.MaxDividendPaymentTypeLength, MinimumLength = ManageDividendPaymentTypeConsts.MinDividendPaymentTypeLength)]
        public string DividendPaymentType { get; set; }

    }
}