﻿using System;
using Abp.Application.Services.Dto;

namespace SIAML.Middleware.DividendPayment.Dtos
{
    public class ManageDividendPaymentTypeDto : EntityDto
    {
        public string DividendPaymentType { get; set; }

    }
}