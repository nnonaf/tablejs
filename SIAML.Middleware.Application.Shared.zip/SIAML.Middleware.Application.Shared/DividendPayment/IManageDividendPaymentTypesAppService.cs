﻿using System;
using System.Threading.Tasks;
using Abp.Application.Services;
using Abp.Application.Services.Dto;
using SIAML.Middleware.DividendPayment.Dtos;
using SIAML.Middleware.Dto;

namespace SIAML.Middleware.DividendPayment
{
    public interface IManageDividendPaymentTypesAppService : IApplicationService
    {
        Task<PagedResultDto<GetManageDividendPaymentTypeForViewDto>> GetAll(GetAllManageDividendPaymentTypesInput input);

        Task<GetManageDividendPaymentTypeForViewDto> GetManageDividendPaymentTypeForView(int id);

        Task<GetManageDividendPaymentTypeForEditOutput> GetManageDividendPaymentTypeForEdit(EntityDto input);

        Task CreateOrEdit(CreateOrEditManageDividendPaymentTypeDto input);

        Task Delete(EntityDto input);

        Task<FileDto> GetManageDividendPaymentTypesToExcel(GetAllManageDividendPaymentTypesForExcelInput input);

    }
}