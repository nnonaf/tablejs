using System.Threading.Tasks;
using Abp.Application.Services;
using SIAML.Middleware.Sessions.Dto;

namespace SIAML.Middleware.Sessions
{
    public interface ISessionAppService : IApplicationService
    {
        Task<GetCurrentLoginInformationsOutput> GetCurrentLoginInformations();

        Task<UpdateUserSignInTokenOutput> UpdateUserSignInToken();
    }
}
