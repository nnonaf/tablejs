﻿using System;
using System.Threading.Tasks;
using Abp.Application.Services;
using Abp.Application.Services.Dto;
using SIAML.Middleware.Sector.Dtos;
using SIAML.Middleware.Dto;

namespace SIAML.Middleware.Sector
{
    public interface IManageSectorsAppService : IApplicationService
    {
        Task<PagedResultDto<GetManageSectorForViewDto>> GetAll(GetAllManageSectorsInput input);

        Task<GetManageSectorForViewDto> GetManageSectorForView(int id);

        Task<GetManageSectorForEditOutput> GetManageSectorForEdit(EntityDto input);

        Task CreateOrEdit(CreateOrEditManageSectorDto input);

        Task Delete(EntityDto input);

        Task<FileDto> GetManageSectorsToExcel(GetAllManageSectorsForExcelInput input);

    }
}