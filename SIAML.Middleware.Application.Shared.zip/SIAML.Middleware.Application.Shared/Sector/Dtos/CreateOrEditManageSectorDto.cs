﻿using System;
using Abp.Application.Services.Dto;
using System.ComponentModel.DataAnnotations;

namespace SIAML.Middleware.Sector.Dtos
{
    public class CreateOrEditManageSectorDto : EntityDto<int?>
    {

        [Required]
        [StringLength(ManageSectorConsts.MaxSectorNameLength, MinimumLength = ManageSectorConsts.MinSectorNameLength)]
        public string SectorName { get; set; }

    }
}