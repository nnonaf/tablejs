﻿using System;
using Abp.Application.Services.Dto;
using System.ComponentModel.DataAnnotations;

namespace SIAML.Middleware.Sector.Dtos
{
    public class GetManageSectorForEditOutput
    {
        public CreateOrEditManageSectorDto ManageSector { get; set; }

    }
}