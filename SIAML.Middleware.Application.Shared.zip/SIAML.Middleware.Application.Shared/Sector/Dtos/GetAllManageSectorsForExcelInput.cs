﻿using Abp.Application.Services.Dto;
using System;

namespace SIAML.Middleware.Sector.Dtos
{
    public class GetAllManageSectorsForExcelInput
    {
        public string Filter { get; set; }

        public string SectorNameFilter { get; set; }

    }
}