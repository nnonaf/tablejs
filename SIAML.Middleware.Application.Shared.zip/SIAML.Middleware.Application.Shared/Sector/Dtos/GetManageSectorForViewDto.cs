﻿namespace SIAML.Middleware.Sector.Dtos
{
    public class GetManageSectorForViewDto
    {
        public ManageSectorDto ManageSector { get; set; }

    }
}