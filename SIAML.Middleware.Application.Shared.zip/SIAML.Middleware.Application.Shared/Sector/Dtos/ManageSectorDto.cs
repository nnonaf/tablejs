﻿using System;
using Abp.Application.Services.Dto;

namespace SIAML.Middleware.Sector.Dtos
{
    public class ManageSectorDto : EntityDto
    {
        public string SectorName { get; set; }

    }
}