namespace SIAML.Middleware.Caching.Dto
{
    public class CacheDto
    {
        public string Name { get; set; }
    }
}
