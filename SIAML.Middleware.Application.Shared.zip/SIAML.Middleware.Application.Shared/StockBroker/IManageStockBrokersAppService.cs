﻿using System;
using System.Threading.Tasks;
using Abp.Application.Services;
using Abp.Application.Services.Dto;
using SIAML.Middleware.StockBroker.Dtos;
using SIAML.Middleware.Dto;

namespace SIAML.Middleware.StockBroker
{
    public interface IManageStockBrokersAppService : IApplicationService
    {
        Task<PagedResultDto<GetManageStockBrokerForViewDto>> GetAll(GetAllManageStockBrokersInput input);

        Task<GetManageStockBrokerForViewDto> GetManageStockBrokerForView(int id);

        Task<GetManageStockBrokerForEditOutput> GetManageStockBrokerForEdit(EntityDto input);

        Task CreateOrEdit(CreateOrEditManageStockBrokerDto input);

        Task Delete(EntityDto input);

        Task<FileDto> GetManageStockBrokersToExcel(GetAllManageStockBrokersForExcelInput input);

    }
}