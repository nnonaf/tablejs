﻿using Abp.Application.Services.Dto;
using System;

namespace SIAML.Middleware.StockBroker.Dtos
{
    public class GetAllManageStockBrokersInput : PagedAndSortedResultRequestDto
    {
        public string Filter { get; set; }

        public string StockBrokerNameFilter { get; set; }

    }
}