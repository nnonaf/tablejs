﻿using System;
using Abp.Application.Services.Dto;

namespace SIAML.Middleware.StockBroker.Dtos
{
    public class ManageStockBrokerDto : EntityDto
    {
        public string StockBrokerName { get; set; }

    }
}