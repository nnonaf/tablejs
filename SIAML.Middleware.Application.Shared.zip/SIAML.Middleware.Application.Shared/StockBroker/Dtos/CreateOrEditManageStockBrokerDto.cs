﻿using System;
using Abp.Application.Services.Dto;
using System.ComponentModel.DataAnnotations;

namespace SIAML.Middleware.StockBroker.Dtos
{
    public class CreateOrEditManageStockBrokerDto : EntityDto<int?>
    {

        [Required]
        [StringLength(ManageStockBrokerConsts.MaxStockBrokerNameLength, MinimumLength = ManageStockBrokerConsts.MinStockBrokerNameLength)]
        public string StockBrokerName { get; set; }

    }
}