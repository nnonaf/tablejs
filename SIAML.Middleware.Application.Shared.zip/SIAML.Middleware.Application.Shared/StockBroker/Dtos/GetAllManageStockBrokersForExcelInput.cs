﻿using Abp.Application.Services.Dto;
using System;

namespace SIAML.Middleware.StockBroker.Dtos
{
    public class GetAllManageStockBrokersForExcelInput
    {
        public string Filter { get; set; }

        public string StockBrokerNameFilter { get; set; }

    }
}