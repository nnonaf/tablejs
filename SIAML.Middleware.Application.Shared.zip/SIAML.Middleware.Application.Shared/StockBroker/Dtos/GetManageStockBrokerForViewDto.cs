﻿namespace SIAML.Middleware.StockBroker.Dtos
{
    public class GetManageStockBrokerForViewDto
    {
        public ManageStockBrokerDto ManageStockBroker { get; set; }

    }
}