namespace SIAML.Middleware.DynamicEntityProperties
{
    public class DynamicEntityPropertyGetAllInput
    {
        public string EntityFullName { get; set; }
    }
}
