namespace SIAML.Middleware.DynamicEntityProperties.Dto
{
    public class GetAllEntitiesHasDynamicPropertyOutput
    {
        public string EntityFullName { get; set; }
    }
}