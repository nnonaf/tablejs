﻿using System;
using Abp.Application.Services.Dto;
using System.ComponentModel.DataAnnotations;

namespace SIAML.Middleware.MarketingChannel.Dtos
{
    public class GetManageMarketingChannelForEditOutput
    {
        public CreateOrEditManageMarketingChannelDto ManageMarketingChannel { get; set; }

    }
}