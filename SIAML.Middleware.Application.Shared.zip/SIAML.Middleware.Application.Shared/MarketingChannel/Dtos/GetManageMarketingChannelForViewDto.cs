﻿namespace SIAML.Middleware.MarketingChannel.Dtos
{
    public class GetManageMarketingChannelForViewDto
    {
        public ManageMarketingChannelDto ManageMarketingChannel { get; set; }

    }
}