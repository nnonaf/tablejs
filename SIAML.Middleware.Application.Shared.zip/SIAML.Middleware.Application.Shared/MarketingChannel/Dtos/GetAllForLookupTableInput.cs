﻿using Abp.Application.Services.Dto;

namespace SIAML.Middleware.MarketingChannel.Dtos
{
    public class GetAllForLookupTableInput : PagedAndSortedResultRequestDto
    {
        public string Filter { get; set; }
    }
}