﻿using Abp.Application.Services.Dto;
using System;

namespace SIAML.Middleware.MarketingChannel.Dtos
{
    public class GetAllManageMarketingChannelsForExcelInput
    {
        public string Filter { get; set; }

        public string MarketingChannelFilter { get; set; }

    }
}