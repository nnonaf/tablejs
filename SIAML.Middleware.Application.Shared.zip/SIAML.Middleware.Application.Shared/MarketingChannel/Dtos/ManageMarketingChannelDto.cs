﻿using System;
using Abp.Application.Services.Dto;

namespace SIAML.Middleware.MarketingChannel.Dtos
{
    public class ManageMarketingChannelDto : EntityDto
    {
        public string MarketingChannel { get; set; }

    }
}