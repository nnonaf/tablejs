﻿using System;
using System.Threading.Tasks;
using Abp.Application.Services;
using Abp.Application.Services.Dto;
using SIAML.Middleware.MarketingChannel.Dtos;
using SIAML.Middleware.Dto;

namespace SIAML.Middleware.MarketingChannel
{
    public interface IManageMarketingChannelsAppService : IApplicationService
    {
        Task<PagedResultDto<GetManageMarketingChannelForViewDto>> GetAll(GetAllManageMarketingChannelsInput input);

        Task<GetManageMarketingChannelForViewDto> GetManageMarketingChannelForView(int id);

        Task<GetManageMarketingChannelForEditOutput> GetManageMarketingChannelForEdit(EntityDto input);

        Task CreateOrEdit(CreateOrEditManageMarketingChannelDto input);

        Task Delete(EntityDto input);

        Task<FileDto> GetManageMarketingChannelsToExcel(GetAllManageMarketingChannelsForExcelInput input);

    }
}