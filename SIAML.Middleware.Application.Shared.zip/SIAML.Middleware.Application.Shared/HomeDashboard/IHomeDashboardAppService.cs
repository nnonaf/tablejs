using Abp.Application.Services;
using SIAML.Middleware.Tenants.Dashboard.Dto;
using System.Threading.Tasks;

namespace SIAML.Middleware.HomeDashboard
{
    public interface IHomeDashboardAppService : IApplicationService
    {
       // GetMemberActivityOutput GetMemberActivity();

        GetDashboardDataOutput GetDashboardData(GetDashboardDataInput input);

        GetSalesSummaryOutput GetSalesSummary(GetSalesSummaryInput input);

        GetRegionalStatsOutput GetRegionalStats();

        GetGeneralStatsOutput GetGeneralStats();
    }
}
