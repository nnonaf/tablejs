﻿using System;
using System.Threading.Tasks;
using Abp.Application.Services;
using Abp.Application.Services.Dto;
using SIAML.Middleware.BuyNewFeature.Dtos;
using SIAML.Middleware.Dto;
using SIAML.Middleware.NAVApp.Dtos.ClientsOnboarding;

namespace SIAML.Middleware.BuyNewFeature
{
    public interface IClientAdditionalAccountsAppService : IApplicationService
    {
        Task<PagedResultDto<GetClientAdditionalAccountForViewDto>> GetAll(GetAllClientAdditionalAccountsInput input);

        Task<GetClientAdditionalAccountForViewDto> GetClientAdditionalAccountForView(int id);

        Task<GetClientAdditionalAccountForEditOutput> GetClientAdditionalAccountForEdit(EntityDto input);

        Task CreateOrEdit(CreateOrEditClientAdditionalAccountDto input);

        Task Delete(EntityDto input);

        Task<FileDto> GetClientAdditionalAccountsToExcel(GetAllClientAdditionalAccountsForExcelInput input);

        Task<PagedResultDto<ClientAdditionalAccountManageFundDetailLookupTableDto>> GetAllManageFundDetailForLookupTable(GetAllForLookupTableInput input);

        Task<PagedResultDto<ClientAdditionalAccountManageBankLookupTableDto>> GetAllManageBankForLookupTable(GetAllForLookupTableInput input);

        GetCustomerDetailsResponseDto GetCustomerDetailsByEAccount(string EAccount);

    }
}