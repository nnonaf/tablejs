﻿using SIAML.Middleware.ApprovalStatusEnums;

using System;
using Abp.Application.Services.Dto;
using System.ComponentModel.DataAnnotations;

namespace SIAML.Middleware.BuyNewFeature.Dtos
{
    public class CreateOrEditClientAdditionalAccountDto : EntityDto<int?>
    {

        [Required]
        [StringLength(ClientAdditionalAccountConsts.MaxFirstNameLength, MinimumLength = ClientAdditionalAccountConsts.MinFirstNameLength)]
        public string FirstName { get; set; }

        [StringLength(ClientAdditionalAccountConsts.MaxMiddleNameLength, MinimumLength = ClientAdditionalAccountConsts.MinMiddleNameLength)]
        public string MiddleName { get; set; }

        [Required]
        [StringLength(ClientAdditionalAccountConsts.MaxLastNameLength, MinimumLength = ClientAdditionalAccountConsts.MinLastNameLength)]
        public string LastName { get; set; }

        [StringLength(ClientAdditionalAccountConsts.MaxFundCodeLength, MinimumLength = ClientAdditionalAccountConsts.MinFundCodeLength)]
        public string FundCode { get; set; }

        [Required]
        [StringLength(ClientAdditionalAccountConsts.MaxEmailLength, MinimumLength = ClientAdditionalAccountConsts.MinEmailLength)]
        public string Email { get; set; }

        [Required]
        [StringLength(ClientAdditionalAccountConsts.MaxPhoneLength, MinimumLength = ClientAdditionalAccountConsts.MinPhoneLength)]
        public string Phone { get; set; }

        [Required]
        [StringLength(ClientAdditionalAccountConsts.MaxGenderLength, MinimumLength = ClientAdditionalAccountConsts.MinGenderLength)]
        public string Gender { get; set; }

        [Required]
        [StringLength(ClientAdditionalAccountConsts.MaxAddressLength, MinimumLength = ClientAdditionalAccountConsts.MinAddressLength)]
        public string Address { get; set; }

        [StringLength(ClientAdditionalAccountConsts.MaxBankNameLength, MinimumLength = ClientAdditionalAccountConsts.MinBankNameLength)]
        public string BankName { get; set; }

        [StringLength(ClientAdditionalAccountConsts.MaxBankSortCodeLength, MinimumLength = ClientAdditionalAccountConsts.MinBankSortCodeLength)]
        public string BankSortCode { get; set; }

        [Required]
        [StringLength(ClientAdditionalAccountConsts.MaxBankAccountNameLength, MinimumLength = ClientAdditionalAccountConsts.MinBankAccountNameLength)]
        public string BankAccountName { get; set; }

        [Required]
        [StringLength(ClientAdditionalAccountConsts.MaxBankAccountNumberLength, MinimumLength = ClientAdditionalAccountConsts.MinBankAccountNumberLength)]
        public string BankAccountNumber { get; set; }

        public DateTime DateOfBirth { get; set; }

        [Required]
        [StringLength(ClientAdditionalAccountConsts.MaxBvnLength, MinimumLength = ClientAdditionalAccountConsts.MinBvnLength)]
        public string Bvn { get; set; }

        [Required]
        [StringLength(ClientAdditionalAccountConsts.MaxSourceChannelLength, MinimumLength = ClientAdditionalAccountConsts.MinSourceChannelLength)]
        public string SourceChannel { get; set; }

        [Required]
        [StringLength(ClientAdditionalAccountConsts.MaxBvnPhoneLength, MinimumLength = ClientAdditionalAccountConsts.MinBvnPhoneLength)]
        public string BvnPhone { get; set; }

        [StringLength(ClientAdditionalAccountConsts.MaxRefByLength, MinimumLength = ClientAdditionalAccountConsts.MinRefByLength)]
        public string RefBy { get; set; }

        [StringLength(ClientAdditionalAccountConsts.MaxNationalityLength, MinimumLength = ClientAdditionalAccountConsts.MinNationalityLength)]
        public string Nationality { get; set; }

        [StringLength(ClientAdditionalAccountConsts.MaxNationalityCodeLength, MinimumLength = ClientAdditionalAccountConsts.MinNationalityCodeLength)]
        public string NationalityCode { get; set; }

        [StringLength(ClientAdditionalAccountConsts.MaxPlaceOfBirthLength, MinimumLength = ClientAdditionalAccountConsts.MinPlaceOfBirthLength)]
        public string PlaceOfBirth { get; set; }

        [Required]
        public string WorkflowId { get; set; }

        public ApprovalStatusEnum ApprovalStatus { get; set; }

        [Required]
        [StringLength(ClientAdditionalAccountConsts.MaxRequestTypeLength, MinimumLength = ClientAdditionalAccountConsts.MinRequestTypeLength)]
        public string RequestType { get; set; }

        [Required]
        [StringLength(ClientAdditionalAccountConsts.MaxEaccountLength, MinimumLength = ClientAdditionalAccountConsts.MinEaccountLength)]
        public string Eaccount { get; set; }

        [StringLength(ClientAdditionalAccountConsts.MaxBankAccountStatusLength, MinimumLength = ClientAdditionalAccountConsts.MinBankAccountStatusLength)]
        public string BankAccountStatus { get; set; }

        public int? FundId { get; set; }

        public int? Bank { get; set; }

    }
}