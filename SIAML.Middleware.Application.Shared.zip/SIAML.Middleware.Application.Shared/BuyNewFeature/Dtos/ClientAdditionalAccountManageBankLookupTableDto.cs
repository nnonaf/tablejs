﻿using Abp.Application.Services.Dto;

namespace SIAML.Middleware.BuyNewFeature.Dtos
{
    public class ClientAdditionalAccountManageBankLookupTableDto
    {
        public int Id { get; set; }

        public string DisplayName { get; set; }

        public string BankCode { get; set; }
    }
}