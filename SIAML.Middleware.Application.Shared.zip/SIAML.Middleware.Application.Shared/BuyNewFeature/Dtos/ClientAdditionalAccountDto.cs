﻿using SIAML.Middleware.ApprovalStatusEnums;

using System;
using Abp.Application.Services.Dto;

namespace SIAML.Middleware.BuyNewFeature.Dtos
{
    public class ClientAdditionalAccountDto : EntityDto
    {
        public string FirstName { get; set; }

        public string MiddleName { get; set; }

        public string LastName { get; set; }

        public string FundCode { get; set; }

        public string Email { get; set; }

        public string Phone { get; set; }

        public string Gender { get; set; }

        public string Address { get; set; }

        public string BankName { get; set; }

        public string BankSortCode { get; set; }

        public string BankAccountName { get; set; }

        public string BankAccountNumber { get; set; }

        public DateTime DateOfBirth { get; set; }

        public string Bvn { get; set; }

        public string SourceChannel { get; set; }

        public string BvnPhone { get; set; }

        public string RefBy { get; set; }

        public string Nationality { get; set; }

        public string NationalityCode { get; set; }

        public string PlaceOfBirth { get; set; }

        public string WorkflowId { get; set; }

        public ApprovalStatusEnum ApprovalStatus { get; set; }

        public string RequestType { get; set; }

        public string Eaccount { get; set; }

        public int? FundId { get; set; }

        public int? Bank { get; set; }

    }
}