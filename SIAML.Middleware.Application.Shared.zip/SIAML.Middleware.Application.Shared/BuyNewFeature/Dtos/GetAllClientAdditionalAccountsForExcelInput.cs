﻿using Abp.Application.Services.Dto;
using System;

namespace SIAML.Middleware.BuyNewFeature.Dtos
{
    public class GetAllClientAdditionalAccountsForExcelInput
    {
        public string Filter { get; set; }

        public string FirstNameFilter { get; set; }

        public string MiddleNameFilter { get; set; }

        public string LastNameFilter { get; set; }

        public string FundCodeFilter { get; set; }

        public string EmailFilter { get; set; }

        public string PhoneFilter { get; set; }

        public string GenderFilter { get; set; }

        public string AddressFilter { get; set; }

        public string BankNameFilter { get; set; }

        public string BankSortCodeFilter { get; set; }

        public string BankAccountNameFilter { get; set; }

        public string BankAccountNumberFilter { get; set; }

        public DateTime? MaxDateOfBirthFilter { get; set; }
        public DateTime? MinDateOfBirthFilter { get; set; }

        public string BvnFilter { get; set; }

        public string SourceChannelFilter { get; set; }

        public string BvnPhoneFilter { get; set; }

        public string RefByFilter { get; set; }

        public string NationalityFilter { get; set; }

        public string NationalityCodeFilter { get; set; }

        public string PlaceOfBirthFilter { get; set; }

        public string WorkflowIdFilter { get; set; }

        public int? ApprovalStatusFilter { get; set; }

        public string RequestTypeFilter { get; set; }

        public string EaccountFilter { get; set; }

        public string ManageFundDetailDisplayPropertyFilter { get; set; }

        public string ManageBankBankNameFilter { get; set; }

    }
}