﻿namespace SIAML.Middleware.BuyNewFeature.Dtos
{
    public class GetClientAdditionalAccountForViewDto
    {
        public ClientAdditionalAccountDto ClientAdditionalAccount { get; set; }

        public string ManageFundDetailDisplayProperty { get; set; }

        public string ManageBankBankName { get; set; }

    }
}