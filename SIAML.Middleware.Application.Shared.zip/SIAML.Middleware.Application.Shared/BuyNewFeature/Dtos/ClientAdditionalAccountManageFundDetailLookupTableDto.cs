﻿using Abp.Application.Services.Dto;

namespace SIAML.Middleware.BuyNewFeature.Dtos
{
    public class ClientAdditionalAccountManageFundDetailLookupTableDto
    {
        public int Id { get; set; }

        public string DisplayName { get; set; }
    }
}