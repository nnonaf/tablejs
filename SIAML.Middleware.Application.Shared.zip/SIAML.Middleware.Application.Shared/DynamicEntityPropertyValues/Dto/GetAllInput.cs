namespace SIAML.Middleware.DynamicEntityPropertyValues.Dto
{
    public class GetAllInput
    {
        public string EntityId { get; set; }

        public int PropertyId { get; set; }
    }
}
