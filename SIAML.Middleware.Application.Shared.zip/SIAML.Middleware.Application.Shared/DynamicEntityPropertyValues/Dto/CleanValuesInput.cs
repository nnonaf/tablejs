namespace SIAML.Middleware.DynamicEntityPropertyValues.Dto
{
    public class CleanValuesInput
    {
        public int DynamicEntityPropertyId { get; set; }

        public string EntityId { get; set; }
    }
}
