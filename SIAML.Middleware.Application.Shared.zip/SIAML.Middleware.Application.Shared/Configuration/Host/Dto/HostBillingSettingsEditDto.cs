namespace SIAML.Middleware.Configuration.Host.Dto
{
    public class HostBillingSettingsEditDto
    {
        public string LegalName { get; set; }

        public string Address { get; set; }
    }
}