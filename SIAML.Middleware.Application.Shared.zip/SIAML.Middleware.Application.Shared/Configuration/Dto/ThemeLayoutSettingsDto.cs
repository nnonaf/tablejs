namespace SIAML.Middleware.Configuration.Dto
{
    public class ThemeLayoutSettingsDto
    {
        public string LayoutType { get; set; }
        
        public bool DarkMode { get; set; }
    }
}
