namespace SIAML.Middleware.Configuration.Dto
{
    public class ThemeFooterSettingsDto
    {
        public bool FixedFooter { get; set; }
    }
}