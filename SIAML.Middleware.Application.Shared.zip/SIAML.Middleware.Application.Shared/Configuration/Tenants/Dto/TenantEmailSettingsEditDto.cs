using Abp.Auditing;
using SIAML.Middleware.Configuration.Dto;

namespace SIAML.Middleware.Configuration.Tenants.Dto
{
    public class TenantEmailSettingsEditDto : EmailSettingsEditDto
    {
        public bool UseHostDefaultEmailSettings { get; set; }
    }
}