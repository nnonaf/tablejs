namespace SIAML.Middleware.Configuration.Tenants.Dto
{
    public class TenantBillingSettingsEditDto
    {
        public string LegalName { get; set; }
        public string Address { get; set; }
        public string TaxVatNo { get; set; }
    }
}