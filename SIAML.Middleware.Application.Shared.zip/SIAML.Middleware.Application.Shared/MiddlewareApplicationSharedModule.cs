using Abp.Modules;
using Abp.Reflection.Extensions;

namespace SIAML.Middleware
{
    [DependsOn(typeof(MiddlewareCoreSharedModule))]
    public class MiddlewareApplicationSharedModule : AbpModule
    {
        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(MiddlewareApplicationSharedModule).GetAssembly());
        }
    }
}