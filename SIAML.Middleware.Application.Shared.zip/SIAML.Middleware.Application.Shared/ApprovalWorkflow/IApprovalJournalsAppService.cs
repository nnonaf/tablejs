﻿using System;
using System.Threading.Tasks;
using Abp.Application.Services;
using Abp.Application.Services.Dto;
using SIAML.Middleware.ApprovalWorkflow.Dtos;
using SIAML.Middleware.Dto;

namespace SIAML.Middleware.ApprovalWorkflow
{
    public interface IApprovalJournalsAppService : IApplicationService
    {
        Task<PagedResultDto<GetApprovalJournalForViewDto>> GetAll(GetAllApprovalJournalsInput input);

        Task<GetApprovalJournalForViewDto> GetApprovalJournalForView(Guid id);

        Task<GetApprovalJournalForEditOutput> GetApprovalJournalForEdit(EntityDto<Guid> input);

        Task CreateOrEdit(CreateOrEditApprovalJournalDto input);

        // Task Delete(EntityDto<Guid> input);

        Task<FileDto> GetApprovalJournalsToExcel(GetAllApprovalJournalsForExcelInput input);

    }
}