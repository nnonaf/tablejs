﻿using System;
using Abp.Application.Services.Dto;
using System.ComponentModel.DataAnnotations;

namespace SIAML.Middleware.ApprovalWorkflow.Dtos
{
    public class GetApprovalJournalForEditOutput
    {
        public CreateOrEditApprovalJournalDto ApprovalJournal { get; set; }

    }
}