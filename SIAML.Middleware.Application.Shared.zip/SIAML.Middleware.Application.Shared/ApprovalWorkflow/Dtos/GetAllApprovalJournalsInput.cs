﻿using Abp.Application.Services.Dto;
using System;

namespace SIAML.Middleware.ApprovalWorkflow.Dtos
{
    public class GetAllApprovalJournalsInput : PagedAndSortedResultRequestDto
    {
        public string Filter { get; set; }

        public string ApprovalTypeFilter { get; set; }

        public string WorkflowIdFilter { get; set; }

        public int? MaxApprovalChainIdFilter { get; set; }
        public int? MinApprovalChainIdFilter { get; set; }

        public string ApprovalStatusFilter { get; set; }

        public string ApprovalCommentFilter { get; set; }

        public string CreatedByFilter { get; set; }

    }
}