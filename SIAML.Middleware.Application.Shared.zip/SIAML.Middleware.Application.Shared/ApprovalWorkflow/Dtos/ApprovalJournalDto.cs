﻿using System;
using Abp.Application.Services.Dto;

namespace SIAML.Middleware.ApprovalWorkflow.Dtos
{
    public class ApprovalJournalDto : EntityDto<Guid>
    {
        public string ApprovalType { get; set; }

        public string WorkflowId { get; set; }

        public int ApprovalChainId { get; set; }

        public string ApprovalStatus { get; set; }

        public string ApprovalComment { get; set; }


        public DateTime DateCreated { get; set; }

        public string CreatedBy { get; set; }

    }
}