﻿using System;
using Abp.Application.Services.Dto;
using System.ComponentModel.DataAnnotations;

namespace SIAML.Middleware.ApprovalWorkflow.Dtos
{
    public class CreateOrEditApprovalJournalDto : EntityDto<Guid?>
    {

        [Required]
        [StringLength(ApprovalJournalConsts.MaxApprovalTypeLength, MinimumLength = ApprovalJournalConsts.MinApprovalTypeLength)]
        public string ApprovalType { get; set; }

        [Required]
        [StringLength(ApprovalJournalConsts.MaxWorkflowIdLength, MinimumLength = ApprovalJournalConsts.MinWorkflowIdLength)]
        public string WorkflowId { get; set; }

        public int ApprovalChainId { get; set; }

        [Required]
        [StringLength(ApprovalJournalConsts.MaxApprovalStatusLength, MinimumLength = ApprovalJournalConsts.MinApprovalStatusLength)]
        public string ApprovalStatus { get; set; }

        [StringLength(ApprovalJournalConsts.MaxApprovalCommentLength, MinimumLength = ApprovalJournalConsts.MinApprovalCommentLength)]
        public string ApprovalComment { get; set; }

        [Required]
        [StringLength(ApprovalJournalConsts.MaxCreatedByLength, MinimumLength = ApprovalJournalConsts.MinCreatedByLength)]
        public string CreatedBy { get; set; }

    }
}