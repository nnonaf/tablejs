﻿namespace SIAML.Middleware.ApprovalWorkflow.Dtos
{
    public class GetApprovalJournalForViewDto
    {
        public ApprovalJournalDto ApprovalJournal { get; set; }

    }
}