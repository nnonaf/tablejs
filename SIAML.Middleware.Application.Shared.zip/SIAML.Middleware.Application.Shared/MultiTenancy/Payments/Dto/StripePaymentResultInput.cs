namespace SIAML.Middleware.MultiTenancy.Payments.Dto
{
    public class StripePaymentResultInput
    {
        public long PaymentId { get; set; }
    }
}
