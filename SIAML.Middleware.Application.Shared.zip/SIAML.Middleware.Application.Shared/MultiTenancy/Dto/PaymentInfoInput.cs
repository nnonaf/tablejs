namespace SIAML.Middleware.MultiTenancy.Dto
{
    public class PaymentInfoInput
    {
        public int? UpgradeEditionId { get; set; }
    }
}
