namespace SIAML.Middleware.MultiTenancy.HostDashboard.Dto
{
    public class GetTopStatsInput : DashboardInputBase
    {
    }
}