namespace SIAML.Middleware.MultiTenancy.HostDashboard.Dto
{
    public class GetEditionStatisticsInput : DashboardInputBase
    {
    }
}