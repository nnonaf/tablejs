namespace SIAML.Middleware.MultiTenancy.HostDashboard.Dto
{
    public class TenantEdition 
    {
        public string Label { get; set; }
        public int Value { get; set; }
    }
}