namespace SIAML.Middleware.MultiTenancy.HostDashboard.Dto
{
    public class GetEditionTenantStatisticsInput : DashboardInputBase
    {
    }
}