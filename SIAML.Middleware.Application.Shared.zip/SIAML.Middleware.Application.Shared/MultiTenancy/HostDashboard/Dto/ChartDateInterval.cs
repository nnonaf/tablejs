namespace SIAML.Middleware.MultiTenancy.HostDashboard.Dto
{
    public enum ChartDateInterval
    {
        Daily = 1,
        Weekly = 2,
        Monthly = 3
    }
}