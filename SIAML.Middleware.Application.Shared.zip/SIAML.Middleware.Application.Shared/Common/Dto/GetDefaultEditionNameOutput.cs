namespace SIAML.Middleware.Common.Dto
{
    public class GetDefaultEditionNameOutput
    {
        public string Name { get; set; }
    }
}
