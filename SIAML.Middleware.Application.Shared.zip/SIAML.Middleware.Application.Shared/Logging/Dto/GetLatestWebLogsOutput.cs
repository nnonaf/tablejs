using System.Collections.Generic;

namespace SIAML.Middleware.Logging.Dto
{
    public class GetLatestWebLogsOutput
    {
        public List<string> LatestWebLogLines { get; set; }
    }
}
