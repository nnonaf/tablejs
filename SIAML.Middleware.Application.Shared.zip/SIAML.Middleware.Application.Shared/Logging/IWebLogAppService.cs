using Abp.Application.Services;
using SIAML.Middleware.Dto;
using SIAML.Middleware.Logging.Dto;

namespace SIAML.Middleware.Logging
{
    public interface IWebLogAppService : IApplicationService
    {
        GetLatestWebLogsOutput GetLatestWebLogs();

        FileDto DownloadWebLogs();
    }
}
