﻿using System;
using System.Threading.Tasks;
using Abp.Application.Services;
using Abp.Application.Services.Dto;
using SIAML.Middleware.Relationship.Dtos;
using SIAML.Middleware.Dto;

namespace SIAML.Middleware.Relationship
{
    public interface IManageRelationshipsAppService : IApplicationService
    {
        Task<PagedResultDto<GetManageRelationshipForViewDto>> GetAll(GetAllManageRelationshipsInput input);

        Task<GetManageRelationshipForViewDto> GetManageRelationshipForView(int id);

        Task<GetManageRelationshipForEditOutput> GetManageRelationshipForEdit(EntityDto input);

        Task CreateOrEdit(CreateOrEditManageRelationshipDto input);

        Task Delete(EntityDto input);

        Task<FileDto> GetManageRelationshipsToExcel(GetAllManageRelationshipsForExcelInput input);

    }
}