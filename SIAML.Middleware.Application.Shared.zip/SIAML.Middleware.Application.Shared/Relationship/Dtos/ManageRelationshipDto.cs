﻿using System;
using Abp.Application.Services.Dto;

namespace SIAML.Middleware.Relationship.Dtos
{
    public class ManageRelationshipDto : EntityDto
    {
        public string RelationshipName { get; set; }

    }
}