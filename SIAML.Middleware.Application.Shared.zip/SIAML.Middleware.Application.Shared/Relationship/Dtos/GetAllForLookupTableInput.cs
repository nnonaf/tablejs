﻿using Abp.Application.Services.Dto;

namespace SIAML.Middleware.Relationship.Dtos
{
    public class GetAllForLookupTableInput : PagedAndSortedResultRequestDto
    {
        public string Filter { get; set; }
    }
}