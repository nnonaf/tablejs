﻿namespace SIAML.Middleware.Relationship.Dtos
{
    public class GetManageRelationshipForViewDto
    {
        public ManageRelationshipDto ManageRelationship { get; set; }

    }
}