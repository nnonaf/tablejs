﻿using System;
using Abp.Application.Services.Dto;
using System.ComponentModel.DataAnnotations;

namespace SIAML.Middleware.Relationship.Dtos
{
    public class CreateOrEditManageRelationshipDto : EntityDto<int?>
    {

        [Required]
        [StringLength(ManageRelationshipConsts.MaxRelationshipNameLength, MinimumLength = ManageRelationshipConsts.MinRelationshipNameLength)]
        public string RelationshipName { get; set; }

    }
}