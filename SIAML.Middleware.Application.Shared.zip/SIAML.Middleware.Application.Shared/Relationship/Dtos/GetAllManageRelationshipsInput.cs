﻿using Abp.Application.Services.Dto;
using System;

namespace SIAML.Middleware.Relationship.Dtos
{
    public class GetAllManageRelationshipsInput : PagedAndSortedResultRequestDto
    {
        public string Filter { get; set; }

        public string RelationshipNameFilter { get; set; }

    }
}