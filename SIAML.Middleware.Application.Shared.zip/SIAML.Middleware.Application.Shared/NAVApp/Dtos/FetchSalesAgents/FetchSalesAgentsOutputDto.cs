﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SIAML.Middleware.NAVApp.Dtos.FetchSalesAgents
{
    public class FetchSalesAgentsOutputDto
    {
        public string RepId { get; set; }
        public string RepName { get; set; }
    }
}
