﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SIAML.Middleware.NAVApp.Dtos.GetValsUnitPrice
{
    public class GetValsUnitPriceOutputDto
    {
        public decimal FundPrice { get; set; }
    }
}
