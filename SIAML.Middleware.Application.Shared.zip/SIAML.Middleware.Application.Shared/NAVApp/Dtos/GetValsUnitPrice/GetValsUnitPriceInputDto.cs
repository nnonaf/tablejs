﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SIAML.Middleware.NAVApp.Dtos.GetValsUnitPrice
{
    public class GetValsUnitPriceInputDto
    {
        public string FundId { get; set; }

        public string Date { get; set; }

       
    }
}
