﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SIAML.Middleware.NAVApp.Dtos.ClientsOnboarding
{
    public class ClientDetailsResponseDto
    {
        public string ClientNo { get; set; }

        public string FundId { get; set; }
    }
}
