﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SIAML.Middleware.NAVApp.Dtos.ClientsOnboarding
{
    public class ClientAccountsResponseDto
    {
        public bool IsSuccessful { get; set; }

        public string StatusCode { get; set; }

        public string StatusMessage { get; set; }

        public List<ClientDetailsResponseDto> ClientDetails { get; set; }
    }
}
