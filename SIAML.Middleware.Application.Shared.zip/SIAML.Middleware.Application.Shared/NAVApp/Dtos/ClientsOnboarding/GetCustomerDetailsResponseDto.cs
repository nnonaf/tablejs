﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SIAML.Middleware.NAVApp.Dtos.ClientsOnboarding
{
    public class GetCustomerDetailsResponseDto
    {
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
      //  public string Email { get; set; }
        public string Phone { get; set; }
        public string Gender { get; set; }
        public string Address { get; set; }
        public string BankName { get; set; }
        public string BankSortCode { get; set; }
        public string BankAccountName { get; set; }
        public string Bvn { get; set; }
        public string BvnPhone { get; set; }
        public string Nationality { get; set; }
        public string NationalityCode { get; set; }
        public string PlaceOfBirth { get; set; }

    }
}
