﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SIAML.Middleware.NAVApp.Dtos.ClientsOnboarding
{
    public class GetCustomerDetailsInputDto
    {
        public string EAccount { get; set; }
    }
}
