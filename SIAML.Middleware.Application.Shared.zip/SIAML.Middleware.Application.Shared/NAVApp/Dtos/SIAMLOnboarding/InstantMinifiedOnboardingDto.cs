﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace SIAML.Middleware.NAVApp.Dtos.SIAMLOnboarding
{
    public class InstantMinifiedOnboardingDto
    {
        [Required]
        [StringLength(InstantMinifiedOnboardingConsts.MaxFirstNameLength, MinimumLength = InstantMinifiedOnboardingConsts.MinFirstNameLength)]
        public string FirstName { get; set; }
        public string MiddleName { get; set; }

        [Required]
        [StringLength(InstantMinifiedOnboardingConsts.MaxLastNameLength, MinimumLength = InstantMinifiedOnboardingConsts.MinLastNameLength)]
        public string LastName { get; set; }

        [Required]
        public string FundId { get; set; }

        [Required]
        [StringLength(InstantMinifiedOnboardingConsts.MaxEmailLength, MinimumLength = InstantMinifiedOnboardingConsts.MinEmailLength)]
        public string Email { get; set; }

        [Required]
        [StringLength(InstantMinifiedOnboardingConsts.MaxPhoneLength, MinimumLength = InstantMinifiedOnboardingConsts.MinPhoneLength)]
        public string Phone { get; set; }

        [Required]
        [StringLength(InstantMinifiedOnboardingConsts.MaxGenderLength, MinimumLength = InstantMinifiedOnboardingConsts.MinGenderLength)]
        public string Gender { get; set; }

        [Required]
        [StringLength(InstantMinifiedOnboardingConsts.MaxAddressLength, MinimumLength = InstantMinifiedOnboardingConsts.MinAddressLength)]
        public string Address { get; set; }

        [Required]
        [StringLength(InstantMinifiedOnboardingConsts.MaxBankNameLength, MinimumLength = InstantMinifiedOnboardingConsts.MinBankNameLength)]
        public string BankName { get; set; }
        public string BankSortCode { get; set; }

        [Required]
        [StringLength(InstantMinifiedOnboardingConsts.MaxBankAccountNameLength, MinimumLength = InstantMinifiedOnboardingConsts.MinBankAccountNameLength)]
        public string BankAccountName { get; set; }

        [Required]
        [StringLength(InstantMinifiedOnboardingConsts.MaxBankAccountNumberLength, MinimumLength = InstantMinifiedOnboardingConsts.MinBankAccountNumberLength)]
        public string BankAccountNumber { get; set; }

        public DateTime DateOfBirth { get; set; }

        [Required]
        [StringLength(InstantMinifiedOnboardingConsts.MaxBvnLength, MinimumLength = InstantMinifiedOnboardingConsts.MinBvnLength)]
        public string Bvn { get; set; }

        [Required]
        [StringLength(InstantMinifiedOnboardingConsts.MaxSourceChannelLength, MinimumLength = InstantMinifiedOnboardingConsts.MinSourceChannelLength)]
        public string SourceChannel { get; set; }

        [Required]
        [StringLength(InstantMinifiedOnboardingConsts.MaxBvnPhoneLength, MinimumLength = InstantMinifiedOnboardingConsts.MinBvnPhoneLength)]
        public string BvnPhone { get; set; }
        public string RefBy { get; set; }
        public string Nationality { get; set; }
        public string NationalityCode { get; set; }
        public string PlaceOfBirth { get; set; }
    }
}
