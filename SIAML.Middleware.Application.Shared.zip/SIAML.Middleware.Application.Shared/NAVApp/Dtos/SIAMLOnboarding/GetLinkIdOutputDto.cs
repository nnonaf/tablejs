﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SIAML.Middleware.NAVApp.Dtos.SIAMLOnboarding
{
    public class GetLinkIdOutputDto
    {
        public string LinkId { get; set; }
        public string PhoneNo { get; set; }
    }
}
