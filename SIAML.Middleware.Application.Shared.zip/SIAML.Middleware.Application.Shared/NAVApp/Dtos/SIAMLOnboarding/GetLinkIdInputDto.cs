﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SIAML.Middleware.NAVApp.Dtos.SIAMLOnboarding
{
    public class GetLinkIdInputDto
    {
        public string Email { get; set; }
        public string Phone { get; set; }
    }
}
