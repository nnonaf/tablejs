﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SIAML.Middleware.NAVApp.Dtos.SIAMLOnboarding
{
    public class LinkAccountInputDto
    {
        public string Bvn { get; set; }
        public string LinkId { get; set; }
        public string Eaccount { get; set; }
    }
}
