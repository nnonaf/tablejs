﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SIAML.Middleware.NAVApp.Dtos.SIAMLOnboarding
{
    public class ProcessAdditionalAccountInputDto
    {
        public string Bvn { get; set; }
        public string PhoneNo { get; set; }
        public string Eaccount { get; set; }
        public string FundId { get; set; }
        public int? BankId { get; set; }
        public string BankAccountNumber { get; set; }
        public string BankAccountName { get; set; }
        public string WorkflowId { get; set; }
        public string Email { get; set; }

    }
}
