﻿using SIAML.Middleware.Education;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace SIAML.Middleware.NAVApp.Dtos.RedBoxNIP
{
    public class DoNIPRequestDto
    {
        [Required]
        [StringLength(DoNIPConsts.MaxAccountNumberLength, MinimumLength = DoNIPConsts.MinAccountNumberLength)]
        public string AccountNumber { get; set; }

        [Required]
        [StringLength(DoNIPConsts.MaxDestinationBankCodeLength, MinimumLength = DoNIPConsts.MinDestinationBankCodeLength)]
        public string DestinationBankCode { get; set; }
    }
}
