﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SIAML.Middleware.NAVApp.Dtos.RedBoxNIP
{
    public class DoNIPResponseDto
    {
        public string ResponseCode { get; set; }
        public string AccountName  { get; set; }
    }
}
