﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace SIAML.Middleware.NAVApp.Dtos.BVNValidation
{
    [XmlRoot(ElementName = "DocumentElement")]
    public class BVNDetailsRespValidationXMLDto
    {
        [XmlElement(ElementName = "BVN")]
        public BVN BVN { get; set; }
    }



    [XmlRoot(ElementName = "BVN")]
    public class BVN
    {

        [XmlElement(ElementName = "LASTNAME")]
        public string LASTNAME { get; set; }

        [XmlElement(ElementName = "FIRSTNAME")]
        public string FIRSTNAME { get; set; }

        [XmlElement(ElementName = "OTHERNAMES")]
        public string OTHERNAMES { get; set; }

        [XmlElement(ElementName = "DOB")]
        public string DOB { get; set; }

        [XmlElement(ElementName = "MOBILE_PHONE")]
        public string MOBILEPHONE { get; set; }

        [XmlAttribute(AttributeName = "diffgr")]
        public string Diffgr { get; set; }

        [XmlAttribute(AttributeName = "msdata")]
        public string Msdata { get; set; }

        [XmlAttribute(AttributeName = "id")]
        public string Id { get; set; }

        [XmlAttribute(AttributeName = "rowOrder")]
        public int RowOrder { get; set; }

        [XmlAttribute(AttributeName = "hasChanges")]
        public string HasChanges { get; set; }

        [XmlText]
        public string Text { get; set; }
    }

}
