﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace SIAML.Middleware.NAVApp.Dtos.BVNValidation
{
    public class BVNValidationRequestDto
    {

        [Required]

        [StringLength(BVNConsts.MaxBVNLength, MinimumLength = BVNConsts.MinBVNLength)]
        public string BVN { get; set; }
    }
}
