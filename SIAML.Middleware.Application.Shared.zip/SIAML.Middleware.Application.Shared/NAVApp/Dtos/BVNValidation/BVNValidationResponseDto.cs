﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SIAML.Middleware.NAVApp.Dtos.BVNValidation
{
    public class BVNValidationResponseDto
    {
        public bool Status { get; set; }
        public string LastName { get; set; }
        public string FirstName { get; set; }
        public string OtherNames { get; set; }
        public string DateOfBirth { get; set; }
        public string MobilePhone { get; set; }
    }
}
