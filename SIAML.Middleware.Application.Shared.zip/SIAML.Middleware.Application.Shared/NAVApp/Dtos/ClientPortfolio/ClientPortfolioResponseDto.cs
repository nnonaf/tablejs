﻿using SIAML.Middleware.NAVApp.Dtos.ClientsOnboarding;
using System;
using System.Collections.Generic;
using System.Text;

namespace SIAML.Middleware.NAVApp.Dtos.ClientPortfolio
{
    public class ClientPortfolioResponseDto
    {
       
            public bool IsSuccessful { get; set; }

            public string StatusCode { get; set; }

            public string StatusMessage { get; set; }

            public string FundId { get; set; }
        
    }
}
