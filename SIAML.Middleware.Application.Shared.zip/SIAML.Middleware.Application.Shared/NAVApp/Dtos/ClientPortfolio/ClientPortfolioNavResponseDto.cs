﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SIAML.Middleware.NAVApp.Dtos.ClientPortfolio
{
    public class ClientPortfolioNavResponseDto
    {
        public string return_value { get; set; }
    }
}
