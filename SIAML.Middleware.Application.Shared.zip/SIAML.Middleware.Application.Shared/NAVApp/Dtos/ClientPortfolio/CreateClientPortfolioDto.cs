﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SIAML.Middleware.NAVApp.Dtos.ClientPortfolio
{
    public class CreateClientPortfolioDto
    {
        public string Name { get; set; }
        public int FundSchemeType { get; set; }
        public int Class { get; set; }
    }
}
