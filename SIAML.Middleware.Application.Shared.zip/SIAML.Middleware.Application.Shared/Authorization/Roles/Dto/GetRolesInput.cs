using System.Collections.Generic;

namespace SIAML.Middleware.Authorization.Roles.Dto
{
    public class GetRolesInput
    {
        public List<string> Permissions { get; set; }
    }
}
