using System.ComponentModel.DataAnnotations;

namespace SIAML.Middleware.Authorization.Users.Dto
{
    public class ChangeUserLanguageDto
    {
        [Required]
        public string LanguageName { get; set; }
    }
}
