﻿using System;
using System.Threading.Tasks;
using Abp.Application.Services;
using Abp.Application.Services.Dto;
using SIAML.Middleware.PaymentMode.Dtos;
using SIAML.Middleware.Dto;

namespace SIAML.Middleware.PaymentMode
{
    public interface IManagePaymentModesAppService : IApplicationService
    {
        Task<PagedResultDto<GetManagePaymentModeForViewDto>> GetAll(GetAllManagePaymentModesInput input);

        Task<GetManagePaymentModeForViewDto> GetManagePaymentModeForView(int id);

        Task<GetManagePaymentModeForEditOutput> GetManagePaymentModeForEdit(EntityDto input);

        Task CreateOrEdit(CreateOrEditManagePaymentModeDto input);

        Task Delete(EntityDto input);

        Task<FileDto> GetManagePaymentModesToExcel(GetAllManagePaymentModesForExcelInput input);

    }
}