﻿using System;
using Abp.Application.Services.Dto;

namespace SIAML.Middleware.PaymentMode.Dtos
{
    public class ManagePaymentModeDto : EntityDto
    {
        public string PaymentMode { get; set; }

    }
}