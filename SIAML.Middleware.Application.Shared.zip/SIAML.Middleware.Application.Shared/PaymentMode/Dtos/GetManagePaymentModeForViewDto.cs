﻿namespace SIAML.Middleware.PaymentMode.Dtos
{
    public class GetManagePaymentModeForViewDto
    {
        public ManagePaymentModeDto ManagePaymentMode { get; set; }

    }
}