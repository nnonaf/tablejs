﻿using System;
using Abp.Application.Services.Dto;
using System.ComponentModel.DataAnnotations;

namespace SIAML.Middleware.PaymentMode.Dtos
{
    public class GetManagePaymentModeForEditOutput
    {
        public CreateOrEditManagePaymentModeDto ManagePaymentMode { get; set; }

    }
}