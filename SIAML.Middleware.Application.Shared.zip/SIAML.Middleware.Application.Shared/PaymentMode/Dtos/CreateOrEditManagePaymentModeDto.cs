﻿using System;
using Abp.Application.Services.Dto;
using System.ComponentModel.DataAnnotations;

namespace SIAML.Middleware.PaymentMode.Dtos
{
    public class CreateOrEditManagePaymentModeDto : EntityDto<int?>
    {

        [Required]
        [StringLength(ManagePaymentModeConsts.MaxPaymentModeLength, MinimumLength = ManagePaymentModeConsts.MinPaymentModeLength)]
        public string PaymentMode { get; set; }

    }
}