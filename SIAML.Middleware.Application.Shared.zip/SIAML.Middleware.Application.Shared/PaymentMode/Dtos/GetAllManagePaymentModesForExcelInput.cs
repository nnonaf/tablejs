﻿using Abp.Application.Services.Dto;
using System;

namespace SIAML.Middleware.PaymentMode.Dtos
{
    public class GetAllManagePaymentModesForExcelInput
    {
        public string Filter { get; set; }

        public string PaymentModeFilter { get; set; }

    }
}