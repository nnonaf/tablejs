﻿using System;
using System.Threading.Tasks;
using Abp.Application.Services;
using Abp.Application.Services.Dto;
using SIAML.Middleware.FundDetails.Dtos;
using SIAML.Middleware.Dto;

namespace SIAML.Middleware.FundDetails
{
    public interface IManageFundDetailsAppService : IApplicationService
    {
        Task<PagedResultDto<GetManageFundDetailForViewDto>> GetAll(GetAllManageFundDetailsInput input);

        Task<GetManageFundDetailForViewDto> GetManageFundDetailForView(int id);

        Task<GetManageFundDetailForEditOutput> GetManageFundDetailForEdit(EntityDto input);

        Task CreateOrEdit(CreateOrEditManageFundDetailDto input);

        Task Delete(EntityDto input);

        Task<FileDto> GetManageFundDetailsToExcel(GetAllManageFundDetailsForExcelInput input);

        Task<PagedResultDto<ManageFundDetailManageCurrencyLookupTableDto>> GetAllManageCurrencyForLookupTable(GetAllForLookupTableInput input);

    }
}