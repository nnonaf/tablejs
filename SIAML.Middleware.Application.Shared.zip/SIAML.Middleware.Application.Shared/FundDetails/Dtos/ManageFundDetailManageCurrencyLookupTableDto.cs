﻿using Abp.Application.Services.Dto;

namespace SIAML.Middleware.FundDetails.Dtos
{
    public class ManageFundDetailManageCurrencyLookupTableDto
    {
        public int Id { get; set; }

        public string DisplayName { get; set; }
    }
}