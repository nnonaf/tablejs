﻿using SIAML.Middleware.DistributionFrequencyEnums;

using System;
using Abp.Application.Services.Dto;

namespace SIAML.Middleware.FundDetails.Dtos
{
    public class ManageFundDetailDto : EntityDto
    {
        public string FundId { get; set; }

        public string FundName { get; set; }

        public string AssetAllocation { get; set; }

        public bool AnyInvestmentRestricted { get; set; }

        public string RestrictedInvestment { get; set; }

        public bool AnyGuarantee { get; set; }

        public string Guarantee { get; set; }

        public string InvestmentHorizon { get; set; }

        public string InvestmentObjective { get; set; }

        public string Risk { get; set; }

        public string Redemption { get; set; }

        public decimal? NominalValue { get; set; }

        public decimal MinimumInvestment { get; set; }

        public decimal SubsequentInvestment { get; set; }

        public string HandlingCharges { get; set; }

        public DateTime InceptionDate { get; set; }

        public DistributionFrequencyEnum DistributionFrequency { get; set; }

        public int? Currency { get; set; }

    }
}