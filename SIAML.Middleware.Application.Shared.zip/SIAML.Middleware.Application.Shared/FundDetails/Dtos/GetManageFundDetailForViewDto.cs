﻿namespace SIAML.Middleware.FundDetails.Dtos
{
    public class GetManageFundDetailForViewDto
    {
        public ManageFundDetailDto ManageFundDetail { get; set; }

        public string ManageCurrencyCurrencyMnemonic { get; set; }

    }
}