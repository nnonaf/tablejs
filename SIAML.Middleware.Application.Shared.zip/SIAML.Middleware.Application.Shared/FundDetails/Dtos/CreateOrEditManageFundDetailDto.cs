﻿using SIAML.Middleware.DistributionFrequencyEnums;

using System;
using Abp.Application.Services.Dto;
using System.ComponentModel.DataAnnotations;

namespace SIAML.Middleware.FundDetails.Dtos
{
    public class CreateOrEditManageFundDetailDto : EntityDto<int?>
    {

        [Required]
        [StringLength(ManageFundDetailConsts.MaxFundIdLength, MinimumLength = ManageFundDetailConsts.MinFundIdLength)]
        public string FundId { get; set; }

        [Required]
        [StringLength(ManageFundDetailConsts.MaxFundNameLength, MinimumLength = ManageFundDetailConsts.MinFundNameLength)]
        public string FundName { get; set; }

        [Required]
        [StringLength(ManageFundDetailConsts.MaxAssetAllocationLength, MinimumLength = ManageFundDetailConsts.MinAssetAllocationLength)]
        public string AssetAllocation { get; set; }

        public bool AnyInvestmentRestricted { get; set; }

        [StringLength(ManageFundDetailConsts.MaxRestrictedInvestmentLength, MinimumLength = ManageFundDetailConsts.MinRestrictedInvestmentLength)]
        public string RestrictedInvestment { get; set; }

        public bool AnyGuarantee { get; set; }

        [StringLength(ManageFundDetailConsts.MaxGuaranteeLength, MinimumLength = ManageFundDetailConsts.MinGuaranteeLength)]
        public string Guarantee { get; set; }

        [Required]
        [StringLength(ManageFundDetailConsts.MaxInvestmentHorizonLength, MinimumLength = ManageFundDetailConsts.MinInvestmentHorizonLength)]
        public string InvestmentHorizon { get; set; }

        [Required]
        [StringLength(ManageFundDetailConsts.MaxInvestmentObjectiveLength, MinimumLength = ManageFundDetailConsts.MinInvestmentObjectiveLength)]
        public string InvestmentObjective { get; set; }

        [Required]
        [StringLength(ManageFundDetailConsts.MaxRiskLength, MinimumLength = ManageFundDetailConsts.MinRiskLength)]
        public string Risk { get; set; }

        [Required]
        [StringLength(ManageFundDetailConsts.MaxRedemptionLength, MinimumLength = ManageFundDetailConsts.MinRedemptionLength)]
        public string Redemption { get; set; }

        public decimal? NominalValue { get; set; }

        public decimal MinimumInvestment { get; set; }

        public decimal SubsequentInvestment { get; set; }

        [Required]
        [StringLength(ManageFundDetailConsts.MaxHandlingChargesLength, MinimumLength = ManageFundDetailConsts.MinHandlingChargesLength)]
        public string HandlingCharges { get; set; }

        public DateTime InceptionDate { get; set; }

        public DistributionFrequencyEnum DistributionFrequency { get; set; }

        public int? Currency { get; set; }

    }
}