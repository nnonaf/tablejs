﻿using Abp.Application.Services.Dto;
using System;

namespace SIAML.Middleware.FundDetails.Dtos
{
    public class GetAllManageFundDetailsForExcelInput
    {
        public string Filter { get; set; }

        public string FundIdFilter { get; set; }

        public string FundNameFilter { get; set; }

        public string AssetAllocationFilter { get; set; }

        public int? AnyInvestmentRestrictedFilter { get; set; }

        public string RestrictedInvestmentFilter { get; set; }

        public int? AnyGuaranteeFilter { get; set; }

        public string GuaranteeFilter { get; set; }

        public string InvestmentHorizonFilter { get; set; }

        public string InvestmentObjectiveFilter { get; set; }

        public string RiskFilter { get; set; }

        public string RedemptionFilter { get; set; }

        public decimal? MaxNominalValueFilter { get; set; }
        public decimal? MinNominalValueFilter { get; set; }

        public decimal? MaxMinimumInvestmentFilter { get; set; }
        public decimal? MinMinimumInvestmentFilter { get; set; }

        public decimal? MaxSubsequentInvestmentFilter { get; set; }
        public decimal? MinSubsequentInvestmentFilter { get; set; }

        public string HandlingChargesFilter { get; set; }

        public DateTime? MaxInceptionDateFilter { get; set; }
        public DateTime? MinInceptionDateFilter { get; set; }

        public int? DistributionFrequencyFilter { get; set; }

        public string ManageCurrencyCurrencyMnemonicFilter { get; set; }

    }
}