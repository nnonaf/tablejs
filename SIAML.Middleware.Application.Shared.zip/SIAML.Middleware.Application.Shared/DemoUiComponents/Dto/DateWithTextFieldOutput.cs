namespace SIAML.Middleware.DemoUiComponents.Dto
{
    public class DateWithTextFieldOutput : DateFieldOutput
    {
        public string Text { get; set; }
    }
}