using System;

namespace SIAML.Middleware.DemoUiComponents.Dto
{
    public class SendAndGetDateWithTextInput
    {
        public string Text { get; set; }

        public DateTime Date { get; set; }
    }
}