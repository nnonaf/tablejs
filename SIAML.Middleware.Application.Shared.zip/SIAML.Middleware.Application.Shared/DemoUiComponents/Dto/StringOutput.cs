namespace SIAML.Middleware.DemoUiComponents.Dto
{
    public class StringOutput
    {
        public string Output { get; set; }
    }
}