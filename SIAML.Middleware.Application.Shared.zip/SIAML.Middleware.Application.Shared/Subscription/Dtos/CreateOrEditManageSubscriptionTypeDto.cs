﻿using System;
using Abp.Application.Services.Dto;
using System.ComponentModel.DataAnnotations;

namespace SIAML.Middleware.Subscription.Dtos
{
    public class CreateOrEditManageSubscriptionTypeDto : EntityDto<int?>
    {

        [Required]
        [StringLength(ManageSubscriptionTypeConsts.MaxSubscriptionTypeLength, MinimumLength = ManageSubscriptionTypeConsts.MinSubscriptionTypeLength)]
        public string SubscriptionType { get; set; }

    }
}