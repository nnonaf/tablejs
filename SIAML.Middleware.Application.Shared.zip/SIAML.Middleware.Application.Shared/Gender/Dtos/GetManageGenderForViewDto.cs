﻿namespace SIAML.Middleware.Gender.Dtos
{
    public class GetManageGenderForViewDto
    {
        public ManageGenderDto ManageGender { get; set; }

    }
}