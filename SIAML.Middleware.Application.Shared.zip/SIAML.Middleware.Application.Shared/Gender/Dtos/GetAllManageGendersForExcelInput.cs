﻿using Abp.Application.Services.Dto;
using System;

namespace SIAML.Middleware.Gender.Dtos
{
    public class GetAllManageGendersForExcelInput
    {
        public string Filter { get; set; }

        public string GenderFilter { get; set; }

    }
}