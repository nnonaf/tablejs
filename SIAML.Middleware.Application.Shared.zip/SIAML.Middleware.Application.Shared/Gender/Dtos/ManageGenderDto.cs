﻿using System;
using Abp.Application.Services.Dto;

namespace SIAML.Middleware.Gender.Dtos
{
    public class ManageGenderDto : EntityDto
    {
        public string Gender { get; set; }

    }
}