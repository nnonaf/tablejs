﻿using System;
using Abp.Application.Services.Dto;
using System.ComponentModel.DataAnnotations;

namespace SIAML.Middleware.Gender.Dtos
{
    public class CreateOrEditManageGenderDto : EntityDto<int?>
    {

        [Required]
        [StringLength(ManageGenderConsts.MaxGenderLength, MinimumLength = ManageGenderConsts.MinGenderLength)]
        public string Gender { get; set; }

    }
}