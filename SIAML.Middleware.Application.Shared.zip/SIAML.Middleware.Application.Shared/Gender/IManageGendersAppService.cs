﻿using System;
using System.Threading.Tasks;
using Abp.Application.Services;
using Abp.Application.Services.Dto;
using SIAML.Middleware.Gender.Dtos;
using SIAML.Middleware.Dto;

namespace SIAML.Middleware.Gender
{
    public interface IManageGendersAppService : IApplicationService
    {
        Task<PagedResultDto<GetManageGenderForViewDto>> GetAll(GetAllManageGendersInput input);

        Task<GetManageGenderForViewDto> GetManageGenderForView(int id);

        Task<GetManageGenderForEditOutput> GetManageGenderForEdit(EntityDto input);

        Task CreateOrEdit(CreateOrEditManageGenderDto input);

        Task Delete(EntityDto input);

        Task<FileDto> GetManageGendersToExcel(GetAllManageGendersForExcelInput input);

    }
}