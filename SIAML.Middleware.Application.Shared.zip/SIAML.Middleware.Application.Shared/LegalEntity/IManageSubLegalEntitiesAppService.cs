﻿using System;
using System.Threading.Tasks;
using Abp.Application.Services;
using Abp.Application.Services.Dto;
using SIAML.Middleware.LegalEntity.Dtos;
using SIAML.Middleware.Dto;

namespace SIAML.Middleware.LegalEntity
{
    public interface IManageSubLegalEntitiesAppService : IApplicationService
    {
        Task<PagedResultDto<GetManageSubLegalEntityForViewDto>> GetAll(GetAllManageSubLegalEntitiesInput input);

        Task<GetManageSubLegalEntityForViewDto> GetManageSubLegalEntityForView(int id);

        Task<GetManageSubLegalEntityForEditOutput> GetManageSubLegalEntityForEdit(EntityDto input);

        Task CreateOrEdit(CreateOrEditManageSubLegalEntityDto input);

        Task Delete(EntityDto input);

        Task<FileDto> GetManageSubLegalEntitiesToExcel(GetAllManageSubLegalEntitiesForExcelInput input);

        Task<PagedResultDto<ManageSubLegalEntityManageLegalEntityLookupTableDto>> GetAllManageLegalEntityForLookupTable(GetAllForLookupTableInput input);

    }
}