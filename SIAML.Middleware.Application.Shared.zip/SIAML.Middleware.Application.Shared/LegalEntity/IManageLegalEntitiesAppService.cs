﻿using System;
using System.Threading.Tasks;
using Abp.Application.Services;
using Abp.Application.Services.Dto;
using SIAML.Middleware.LegalEntity.Dtos;
using SIAML.Middleware.Dto;

namespace SIAML.Middleware.LegalEntity
{
    public interface IManageLegalEntitiesAppService : IApplicationService
    {
        Task<PagedResultDto<GetManageLegalEntityForViewDto>> GetAll(GetAllManageLegalEntitiesInput input);

        Task<GetManageLegalEntityForViewDto> GetManageLegalEntityForView(int id);

        Task<GetManageLegalEntityForEditOutput> GetManageLegalEntityForEdit(EntityDto input);

        Task CreateOrEdit(CreateOrEditManageLegalEntityDto input);

        Task Delete(EntityDto input);

        Task<FileDto> GetManageLegalEntitiesToExcel(GetAllManageLegalEntitiesForExcelInput input);

    }
}