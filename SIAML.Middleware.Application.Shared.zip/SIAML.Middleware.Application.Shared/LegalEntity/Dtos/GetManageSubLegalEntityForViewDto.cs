﻿namespace SIAML.Middleware.LegalEntity.Dtos
{
    public class GetManageSubLegalEntityForViewDto
    {
        public ManageSubLegalEntityDto ManageSubLegalEntity { get; set; }

        public string ManageLegalEntityLegalEntityType { get; set; }

    }
}