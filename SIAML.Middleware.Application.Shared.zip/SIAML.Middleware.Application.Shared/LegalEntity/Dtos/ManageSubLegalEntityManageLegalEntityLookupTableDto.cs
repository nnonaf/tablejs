﻿using Abp.Application.Services.Dto;

namespace SIAML.Middleware.LegalEntity.Dtos
{
    public class ManageSubLegalEntityManageLegalEntityLookupTableDto
    {
        public int Id { get; set; }

        public string DisplayName { get; set; }
    }
}