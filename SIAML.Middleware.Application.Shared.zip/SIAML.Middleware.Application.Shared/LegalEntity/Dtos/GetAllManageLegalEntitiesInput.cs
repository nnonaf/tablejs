﻿using Abp.Application.Services.Dto;
using System;

namespace SIAML.Middleware.LegalEntity.Dtos
{
    public class GetAllManageLegalEntitiesInput : PagedAndSortedResultRequestDto
    {
        public string Filter { get; set; }

        public string LegalEntityTypeFilter { get; set; }

        public int? RiskCategoryFilter { get; set; }

    }
}