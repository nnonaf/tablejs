﻿using SIAML.Middleware.RiskCategoryEnums;

using System;
using Abp.Application.Services.Dto;

namespace SIAML.Middleware.LegalEntity.Dtos
{
    public class ManageLegalEntityDto : EntityDto
    {
        public string LegalEntityType { get; set; }

        public RiskCategoryEnum RiskCategory { get; set; }

    }
}