﻿using Abp.Application.Services.Dto;
using System;

namespace SIAML.Middleware.LegalEntity.Dtos
{
    public class GetAllManageLegalEntitiesForExcelInput
    {
        public string Filter { get; set; }

        public string LegalEntityTypeFilter { get; set; }

        public int? RiskCategoryFilter { get; set; }

    }
}