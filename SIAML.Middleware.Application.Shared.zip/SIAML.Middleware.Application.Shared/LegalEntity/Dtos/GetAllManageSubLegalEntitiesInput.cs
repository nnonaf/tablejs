﻿using Abp.Application.Services.Dto;
using System;

namespace SIAML.Middleware.LegalEntity.Dtos
{
    public class GetAllManageSubLegalEntitiesInput : PagedAndSortedResultRequestDto
    {
        public string Filter { get; set; }

        public string SubLegalEntityTypeFilter { get; set; }

        public int? LegalEntityId { get; set; }

        public string ManageLegalEntityLegalEntityTypeFilter { get; set; }

    }
}