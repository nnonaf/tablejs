﻿using System;
using Abp.Application.Services.Dto;
using System.ComponentModel.DataAnnotations;

namespace SIAML.Middleware.LegalEntity.Dtos
{
    public class GetManageSubLegalEntityForEditOutput
    {
        public CreateOrEditManageSubLegalEntityDto ManageSubLegalEntity { get; set; }

        public string ManageLegalEntityLegalEntityType { get; set; }

    }
}