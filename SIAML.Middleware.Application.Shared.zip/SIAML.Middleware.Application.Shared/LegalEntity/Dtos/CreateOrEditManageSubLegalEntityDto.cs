﻿using System;
using Abp.Application.Services.Dto;
using System.ComponentModel.DataAnnotations;

namespace SIAML.Middleware.LegalEntity.Dtos
{
    public class CreateOrEditManageSubLegalEntityDto : EntityDto<int?>
    {

        [Required]
        [StringLength(ManageSubLegalEntityConsts.MaxSubLegalEntityTypeLength, MinimumLength = ManageSubLegalEntityConsts.MinSubLegalEntityTypeLength)]
        public string SubLegalEntityType { get; set; }

        public int? LegalEntityId { get; set; }

    }
}