﻿using SIAML.Middleware.RiskCategoryEnums;

using System;
using Abp.Application.Services.Dto;
using System.ComponentModel.DataAnnotations;

namespace SIAML.Middleware.LegalEntity.Dtos
{
    public class CreateOrEditManageLegalEntityDto : EntityDto<int?>
    {

        [Required]
        [StringLength(ManageLegalEntityConsts.MaxLegalEntityTypeLength, MinimumLength = ManageLegalEntityConsts.MinLegalEntityTypeLength)]
        public string LegalEntityType { get; set; }

        public RiskCategoryEnum RiskCategory { get; set; }

    }
}