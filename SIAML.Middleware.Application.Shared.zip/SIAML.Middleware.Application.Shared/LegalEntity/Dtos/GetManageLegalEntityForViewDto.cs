﻿namespace SIAML.Middleware.LegalEntity.Dtos
{
    public class GetManageLegalEntityForViewDto
    {
        public ManageLegalEntityDto ManageLegalEntity { get; set; }

    }
}