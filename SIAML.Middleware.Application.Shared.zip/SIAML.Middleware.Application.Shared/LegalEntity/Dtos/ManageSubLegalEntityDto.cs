﻿using System;
using Abp.Application.Services.Dto;

namespace SIAML.Middleware.LegalEntity.Dtos
{
    public class ManageSubLegalEntityDto : EntityDto
    {
        public string SubLegalEntityType { get; set; }

        public int? LegalEntityId { get; set; }

    }
}