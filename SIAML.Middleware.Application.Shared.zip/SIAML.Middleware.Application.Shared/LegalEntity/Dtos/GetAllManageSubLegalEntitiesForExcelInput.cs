﻿using Abp.Application.Services.Dto;
using System;

namespace SIAML.Middleware.LegalEntity.Dtos
{
    public class GetAllManageSubLegalEntitiesForExcelInput
    {
        public string Filter { get; set; }

        public string SubLegalEntityTypeFilter { get; set; }

        public string ManageLegalEntityLegalEntityTypeFilter { get; set; }

    }
}