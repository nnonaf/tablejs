﻿using System;
using Abp.Application.Services.Dto;
using System.ComponentModel.DataAnnotations;

namespace SIAML.Middleware.LegalEntity.Dtos
{
    public class GetManageLegalEntityForEditOutput
    {
        public CreateOrEditManageLegalEntityDto ManageLegalEntity { get; set; }

    }
}