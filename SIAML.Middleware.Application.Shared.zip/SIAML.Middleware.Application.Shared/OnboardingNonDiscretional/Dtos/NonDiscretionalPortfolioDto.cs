﻿using SIAML.Middleware.NonDiscretionalFundSchemeTypeEnums;
using SIAML.Middleware.NonDiscretionalPortfolioClassEnums;

using System;
using Abp.Application.Services.Dto;

namespace SIAML.Middleware.OnboardingNonDiscretional.Dtos
{
    public class NonDiscretionalPortfolioDto : EntityDto
    {
        public string PortfolioName { get; set; }

        public NonDiscretionalFundSchemeTypeEnum FundSchemeType { get; set; }

        public NonDiscretionalPortfolioClassEnum PortfolioClass { get; set; }

        public string Eaccount { get; set; }

        public string FundCode { get; set; }

    }
}