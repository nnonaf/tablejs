﻿using SIAML.Middleware.NonDiscretionalFundSchemeTypeEnums;
using SIAML.Middleware.NonDiscretionalPortfolioClassEnums;

using System;
using Abp.Application.Services.Dto;
using System.ComponentModel.DataAnnotations;

namespace SIAML.Middleware.OnboardingNonDiscretional.Dtos
{
    public class CreateOrEditNonDiscretionalPortfolioDto : EntityDto<int?>
    {

        [Required]
        [StringLength(NonDiscretionalPortfolioConsts.MaxPortfolioNameLength, MinimumLength = NonDiscretionalPortfolioConsts.MinPortfolioNameLength)]
        public string PortfolioName { get; set; }

        public NonDiscretionalFundSchemeTypeEnum FundSchemeType { get; set; }

        public NonDiscretionalPortfolioClassEnum PortfolioClass { get; set; }

        [Required]
        public string OnboardingSubscriptionWorkflowId { get; set; }

        public string Eaccount { get; set; }

        
        [StringLength(NonDiscretionalPortfolioConsts.MaxFundCodeLength, MinimumLength = NonDiscretionalPortfolioConsts.MinFundCodeLength)]
        public string FundCode { get; set; }

    }
}