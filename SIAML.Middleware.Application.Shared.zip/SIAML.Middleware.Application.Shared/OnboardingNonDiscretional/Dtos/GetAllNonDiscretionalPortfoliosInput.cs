﻿using Abp.Application.Services.Dto;
using System;

namespace SIAML.Middleware.OnboardingNonDiscretional.Dtos
{
    public class GetAllNonDiscretionalPortfoliosInput : PagedAndSortedResultRequestDto
    {
        public string Filter { get; set; }

        public string PortfolioNameFilter { get; set; }

        public int? FundSchemeTypeFilter { get; set; }

        public int? PortfolioClassFilter { get; set; }

        public string EaccountFilter { get; set; }

        public string FundCodeFilter { get; set; }

        public string OnboardingSubscriptionWorkflowIdFilter { get; set; }

    }
}