﻿namespace SIAML.Middleware.OnboardingNonDiscretional.Dtos
{
    public class GetNonDiscretionalPortfolioForViewDto
    {
        public NonDiscretionalPortfolioDto NonDiscretionalPortfolio { get; set; }

    }
}