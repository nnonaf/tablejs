﻿using System;
using System.Threading.Tasks;
using Abp.Application.Services;
using Abp.Application.Services.Dto;
using SIAML.Middleware.OnboardingNonDiscretional.Dtos;
using SIAML.Middleware.Dto;

namespace SIAML.Middleware.OnboardingNonDiscretional
{
    public interface INonDiscretionalPortfoliosAppService : IApplicationService
    {
        Task<PagedResultDto<GetNonDiscretionalPortfolioForViewDto>> GetAll(GetAllNonDiscretionalPortfoliosInput input);

        Task<GetNonDiscretionalPortfolioForViewDto> GetNonDiscretionalPortfolioForView(int id);

        Task<GetNonDiscretionalPortfolioForEditOutput> GetNonDiscretionalPortfolioForEdit(EntityDto input);

        Task CreateOrEdit(CreateOrEditNonDiscretionalPortfolioDto input);

        Task Delete(EntityDto input);

        Task<FileDto> GetNonDiscretionalPortfoliosToExcel(GetAllNonDiscretionalPortfoliosForExcelInput input);

    }
}