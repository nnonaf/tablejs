using Abp.AspNetCore.Mvc.Authorization;
using SIAML.Middleware.Authorization.Users.Profile;
using SIAML.Middleware.Graphics;
using SIAML.Middleware.Storage;

namespace SIAML.Middleware.Web.Controllers
{
    [AbpMvcAuthorize]
    public class ProfileController : ProfileControllerBase
    {
        public ProfileController(
            ITempFileCacheManager tempFileCacheManager,
            IProfileAppService profileAppService,
            IImageFormatValidator imageFormatValidator) :
            base(tempFileCacheManager, profileAppService, imageFormatValidator)
        {
        }
    }
}