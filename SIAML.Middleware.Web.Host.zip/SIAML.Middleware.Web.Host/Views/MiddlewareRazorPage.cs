using Abp.AspNetCore.Mvc.Views;

namespace SIAML.Middleware.Web.Views
{
    public abstract class MiddlewareRazorPage<TModel> : AbpRazorPage<TModel>
    {
        protected MiddlewareRazorPage()
        {
            LocalizationSourceName = MiddlewareConsts.LocalizationSourceName;
        }
    }
}
