﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SIAML.Middleware.Migrations
{
    /// <inheritdoc />
    public partial class ModifiedJoint : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<int>(
                name: "EmployerSegment",
                table: "ClientJointStaging",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AddColumn<int>(
                name: "DividendPaymentTypeId",
                table: "ClientJointStaging",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "EmployeeGrade",
                table: "ClientJointStaging",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<Guid>(
                name: "SignatureUpload",
                table: "ClientJointStaging",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_ClientJointStaging_DividendPaymentTypeId",
                table: "ClientJointStaging",
                column: "DividendPaymentTypeId");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointStaging_Tbl_DividendPaymentTypes_DividendPaymentTypeId",
                table: "ClientJointStaging",
                column: "DividendPaymentTypeId",
                principalTable: "Tbl_DividendPaymentTypes",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointStaging_Tbl_DividendPaymentTypes_DividendPaymentTypeId",
                table: "ClientJointStaging");

            migrationBuilder.DropIndex(
                name: "IX_ClientJointStaging_DividendPaymentTypeId",
                table: "ClientJointStaging");

            migrationBuilder.DropColumn(
                name: "DividendPaymentTypeId",
                table: "ClientJointStaging");

            migrationBuilder.DropColumn(
                name: "EmployeeGrade",
                table: "ClientJointStaging");

            migrationBuilder.DropColumn(
                name: "SignatureUpload",
                table: "ClientJointStaging");

            migrationBuilder.AlterColumn<string>(
                name: "EmployerSegment",
                table: "ClientJointStaging",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");
        }
    }
}
