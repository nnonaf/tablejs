﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SIAML.Middleware.Migrations
{
    /// <inheritdoc />
    public partial class AddedCorporateDetails : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ExternalAppValue",
                table: "Tbl_DividendPaymentTypes");

            migrationBuilder.AlterColumn<int>(
                name: "CorporateLegalEntityType",
                table: "ClientWorkPad",
                type: "int",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "ArticleOfAssociationUpload",
                table: "ClientWorkPad",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "CertificateOfIncorporationUpload",
                table: "ClientWorkPad",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "CorporateSubLegalEntityType",
                table: "ClientWorkPad",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "FormCAC2Upload",
                table: "ClientWorkPad",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "FormCAC7Upload",
                table: "ClientWorkPad",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "LegalSearchReportUpload",
                table: "ClientWorkPad",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "CorporateLegalEntityType",
                table: "Client",
                type: "int",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "ArticleOfAssociationUpload",
                table: "Client",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "CertificateOfIncorporationUpload",
                table: "Client",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "CorporateSubLegalEntityType",
                table: "Client",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "FormCAC2Upload",
                table: "Client",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "FormCAC7Upload",
                table: "Client",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "LegalSearchReportUpload",
                table: "Client",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "Tbl_BusinessConfigurations",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MaxNoOfFundTypes = table.Column<int>(type: "int", nullable: false),
                    MaxNoOfSignatories = table.Column<int>(type: "int", nullable: false),
                    MaxNoOfDirectors = table.Column<int>(type: "int", nullable: false),
                    MaxNoOfJointSubscribers = table.Column<int>(type: "int", nullable: false),
                    AllowMultiFundSubscription = table.Column<bool>(type: "bit", nullable: false),
                    AllowNonFundType = table.Column<bool>(type: "bit", nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    DeleterUserId = table.Column<long>(type: "bigint", nullable: true),
                    DeletionTime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tbl_BusinessConfigurations", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Tbl_LegalEntities",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    LegalEntityType = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: false),
                    RiskCategory = table.Column<int>(type: "int", nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    DeleterUserId = table.Column<long>(type: "bigint", nullable: true),
                    DeletionTime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tbl_LegalEntities", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Tbl_OnboardingSubscriptionDirectors",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Surname = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    FirstName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    OtherName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    DateOfBirth = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Address = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: true),
                    Email = table.Column<string>(type: "nvarchar(70)", maxLength: 70, nullable: true),
                    PhoneNumber = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    IdIssueDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IdExpiryDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    OnboardingSubscriptionWorkflowId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    IdNumber = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    PassportPhotographUpload = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    ProofOfAddressUpload = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    ProofOfIdentityUpload = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    NationalityId = table.Column<int>(type: "int", nullable: true),
                    IdTypeId = table.Column<int>(type: "int", nullable: true),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    DeleterUserId = table.Column<long>(type: "bigint", nullable: true),
                    DeletionTime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tbl_OnboardingSubscriptionDirectors", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Tbl_OnboardingSubscriptionDirectors_Tbl_Countries_NationalityId",
                        column: x => x.NationalityId,
                        principalTable: "Tbl_Countries",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_Tbl_OnboardingSubscriptionDirectors_Tbl_IdTypes_IdTypeId",
                        column: x => x.IdTypeId,
                        principalTable: "Tbl_IdTypes",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "Tbl_OnboardingSubscriptionSignatories",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Surname = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    FirstName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    OtherName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    DateOfBirth = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Address = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: true),
                    Email = table.Column<string>(type: "nvarchar(70)", maxLength: 70, nullable: true),
                    PhoneNumber = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    IdIssueDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IdExpiryDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    OnboardingSubscriptionWorkflowId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    IdNumber = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    PassportPhotographUpload = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    ProofOfAddressUpload = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    ProofOfIdentityUpload = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    NationalityId = table.Column<int>(type: "int", nullable: true),
                    IdTypeId = table.Column<int>(type: "int", nullable: true),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    DeleterUserId = table.Column<long>(type: "bigint", nullable: true),
                    DeletionTime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tbl_OnboardingSubscriptionSignatories", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Tbl_OnboardingSubscriptionSignatories_Tbl_Countries_NationalityId",
                        column: x => x.NationalityId,
                        principalTable: "Tbl_Countries",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_Tbl_OnboardingSubscriptionSignatories_Tbl_IdTypes_IdTypeId",
                        column: x => x.IdTypeId,
                        principalTable: "Tbl_IdTypes",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "Tbl_SubLegalEntities",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SubLegalEntityType = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: false),
                    LegalEntityId = table.Column<int>(type: "int", nullable: true),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    DeleterUserId = table.Column<long>(type: "bigint", nullable: true),
                    DeletionTime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tbl_SubLegalEntities", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Tbl_SubLegalEntities_Tbl_LegalEntities_LegalEntityId",
                        column: x => x.LegalEntityId,
                        principalTable: "Tbl_LegalEntities",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateIndex(
                name: "IX_ClientWorkPad_CorporateLegalEntityType",
                table: "ClientWorkPad",
                column: "CorporateLegalEntityType");

            migrationBuilder.CreateIndex(
                name: "IX_ClientWorkPad_CorporateSubLegalEntityType",
                table: "ClientWorkPad",
                column: "CorporateSubLegalEntityType");

            migrationBuilder.CreateIndex(
                name: "IX_Client_CorporateLegalEntityType",
                table: "Client",
                column: "CorporateLegalEntityType");

            migrationBuilder.CreateIndex(
                name: "IX_Client_CorporateSubLegalEntityType",
                table: "Client",
                column: "CorporateSubLegalEntityType");

            migrationBuilder.CreateIndex(
                name: "IX_Tbl_OnboardingSubscriptionDirectors_IdTypeId",
                table: "Tbl_OnboardingSubscriptionDirectors",
                column: "IdTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_Tbl_OnboardingSubscriptionDirectors_NationalityId",
                table: "Tbl_OnboardingSubscriptionDirectors",
                column: "NationalityId");

            migrationBuilder.CreateIndex(
                name: "IX_Tbl_OnboardingSubscriptionSignatories_IdTypeId",
                table: "Tbl_OnboardingSubscriptionSignatories",
                column: "IdTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_Tbl_OnboardingSubscriptionSignatories_NationalityId",
                table: "Tbl_OnboardingSubscriptionSignatories",
                column: "NationalityId");

            migrationBuilder.CreateIndex(
                name: "IX_Tbl_SubLegalEntities_LegalEntityId",
                table: "Tbl_SubLegalEntities",
                column: "LegalEntityId");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Tbl_LegalEntities_CorporateLegalEntityType",
                table: "Client",
                column: "CorporateLegalEntityType",
                principalTable: "Tbl_LegalEntities",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Tbl_SubLegalEntities_CorporateSubLegalEntityType",
                table: "Client",
                column: "CorporateSubLegalEntityType",
                principalTable: "Tbl_SubLegalEntities",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientWorkPad_Tbl_LegalEntities_CorporateLegalEntityType",
                table: "ClientWorkPad",
                column: "CorporateLegalEntityType",
                principalTable: "Tbl_LegalEntities",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientWorkPad_Tbl_SubLegalEntities_CorporateSubLegalEntityType",
                table: "ClientWorkPad",
                column: "CorporateSubLegalEntityType",
                principalTable: "Tbl_SubLegalEntities",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Client_Tbl_LegalEntities_CorporateLegalEntityType",
                table: "Client");

            migrationBuilder.DropForeignKey(
                name: "FK_Client_Tbl_SubLegalEntities_CorporateSubLegalEntityType",
                table: "Client");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientWorkPad_Tbl_LegalEntities_CorporateLegalEntityType",
                table: "ClientWorkPad");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientWorkPad_Tbl_SubLegalEntities_CorporateSubLegalEntityType",
                table: "ClientWorkPad");

            migrationBuilder.DropTable(
                name: "Tbl_BusinessConfigurations");

            migrationBuilder.DropTable(
                name: "Tbl_OnboardingSubscriptionDirectors");

            migrationBuilder.DropTable(
                name: "Tbl_OnboardingSubscriptionSignatories");

            migrationBuilder.DropTable(
                name: "Tbl_SubLegalEntities");

            migrationBuilder.DropTable(
                name: "Tbl_LegalEntities");

            migrationBuilder.DropIndex(
                name: "IX_ClientWorkPad_CorporateLegalEntityType",
                table: "ClientWorkPad");

            migrationBuilder.DropIndex(
                name: "IX_ClientWorkPad_CorporateSubLegalEntityType",
                table: "ClientWorkPad");

            migrationBuilder.DropIndex(
                name: "IX_Client_CorporateLegalEntityType",
                table: "Client");

            migrationBuilder.DropIndex(
                name: "IX_Client_CorporateSubLegalEntityType",
                table: "Client");

            migrationBuilder.DropColumn(
                name: "ArticleOfAssociationUpload",
                table: "ClientWorkPad");

            migrationBuilder.DropColumn(
                name: "CertificateOfIncorporationUpload",
                table: "ClientWorkPad");

            migrationBuilder.DropColumn(
                name: "CorporateSubLegalEntityType",
                table: "ClientWorkPad");

            migrationBuilder.DropColumn(
                name: "FormCAC2Upload",
                table: "ClientWorkPad");

            migrationBuilder.DropColumn(
                name: "FormCAC7Upload",
                table: "ClientWorkPad");

            migrationBuilder.DropColumn(
                name: "LegalSearchReportUpload",
                table: "ClientWorkPad");

            migrationBuilder.DropColumn(
                name: "ArticleOfAssociationUpload",
                table: "Client");

            migrationBuilder.DropColumn(
                name: "CertificateOfIncorporationUpload",
                table: "Client");

            migrationBuilder.DropColumn(
                name: "CorporateSubLegalEntityType",
                table: "Client");

            migrationBuilder.DropColumn(
                name: "FormCAC2Upload",
                table: "Client");

            migrationBuilder.DropColumn(
                name: "FormCAC7Upload",
                table: "Client");

            migrationBuilder.DropColumn(
                name: "LegalSearchReportUpload",
                table: "Client");

            migrationBuilder.AddColumn<string>(
                name: "ExternalAppValue",
                table: "Tbl_DividendPaymentTypes",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AlterColumn<string>(
                name: "CorporateLegalEntityType",
                table: "ClientWorkPad",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "CorporateLegalEntityType",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);
        }
    }
}
