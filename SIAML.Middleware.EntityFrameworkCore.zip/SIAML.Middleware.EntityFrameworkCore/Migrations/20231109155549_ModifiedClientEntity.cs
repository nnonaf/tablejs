﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SIAML.Middleware.Migrations
{
    /// <inheritdoc />
    public partial class ModifiedClientEntity : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Client_SIAML_Users_SalesOfficer",
                table: "Client");

            migrationBuilder.DropForeignKey(
                name: "FK_Client_Tbl_SubscriptionTypes_ManageSubscriptionTypeId",
                table: "Client");

            migrationBuilder.DropIndex(
                name: "IX_Client_SalesOfficer",
                table: "Client");

            migrationBuilder.AlterColumn<string>(
                name: "WorkFlowType",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "WebStatus",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "WebPassCode",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "UpdatedBy",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "TransRef",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "TransId",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Tin",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(200)",
                oldMaxLength: 200,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Tag",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "SubscriberType",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "SubProfile",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Status",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "StagingId",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Source",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "SchoolSession",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(200)",
                oldMaxLength: 200,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "SchoolId",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(200)",
                oldMaxLength: 200,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "SchoolClass",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(200)",
                oldMaxLength: 200,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "SalesOfficer",
                table: "Client",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(long),
                oldType: "bigint",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "RsaPin",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "ReturnCode",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "ResidentialAddress2",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "ResidentialAddress",
                table: "Client",
                type: "nvarchar(150)",
                maxLength: 150,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "RecordSourceId",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "RecordLocationId",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "RecordId",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "ReceivedBy",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "ProofOfAddressType",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "PromoId",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "PlaceOfIssue",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "PhoneNumber",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(200)",
                oldMaxLength: 200,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "PFA",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "OtherNames",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "OrderId",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Official_Phone",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Nok_OtherNames",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Nok_Mobile_Phone",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Nok_LastName",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Nok_FirstName",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Nok_Email",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Nok_Country_Code",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "NokCity",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(250)",
                oldMaxLength: 250,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "NokAddress2",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "NokAddress",
                table: "Client",
                type: "nvarchar(150)",
                maxLength: 150,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Narration",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Mothers_Maiden_Name",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Mobile_Phone",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "ManageSubscriptionTypeId",
                table: "Client",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AlterColumn<string>(
                name: "MailingState",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "MailingCity",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "MailingAddress2",
                table: "Client",
                type: "nvarchar(150)",
                maxLength: 150,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "MailingAddress",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Maiden_Name",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "LevelOfEducation",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "LastUpdatedBy",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "LastName",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "KYCStatusPassport",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "KYCStatusIdMeans",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "KYCStatusDates",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "KYCStatusAddressProof",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "IncomeRangePerAnnum",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "IdNumber",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "FullName",
                table: "Client",
                type: "nvarchar(150)",
                maxLength: 150,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "FirstName",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Employer_Id",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "EmployerWebsite",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "EmployerTelephone",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "EmployerSegment",
                table: "Client",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "EmployerName",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "EmployerFax",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "EmployerAddress",
                table: "Client",
                type: "nvarchar(150)",
                maxLength: 150,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Email",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "DividendPayment",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Designation",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Created_By",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Country_Code_Official",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(150)",
                oldMaxLength: 150,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Country_Code",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "CorporateWebsite",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "CorporateStreetName",
                table: "Client",
                type: "nvarchar(150)",
                maxLength: 150,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "CorporateRCRegistrationNumber",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "CorporatePlaceOfIncorporation",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(200)",
                oldMaxLength: 200,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "CorporateNameOfInstitution",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "CorporateNameOfContactPerson",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "CorporateLocality",
                table: "Client",
                type: "nvarchar(150)",
                maxLength: 150,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "CorporateLegalEntityType",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "CorporateFaxNumber",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(200)",
                oldMaxLength: 200,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "CorporateEmailAddress",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "CorporateDesignation",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "CorporateContactEmailAddress",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "CorporateCity",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "CorporateBusinessType",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "CorporateBusinessAddress",
                table: "Client",
                type: "nvarchar(150)",
                maxLength: 150,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "ConfirmedBy",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Comment",
                table: "Client",
                type: "nvarchar(150)",
                maxLength: 150,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "ClientId",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "ChildSurname",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "ChildMiddleName",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "ChildFirstName",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "CSCSAccountNumber",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "CHN",
                table: "Client",
                type: "nvarchar(150)",
                maxLength: 150,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "BvnStatus",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "BvnOtherNames",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "BvnMobilePhone",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "BvnLastName",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "BvnFirstName",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "BvnDob",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Bvn",
                table: "Client",
                type: "nvarchar(15)",
                maxLength: 15,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "BeneficiaryName",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "BeneficiaryAccount",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "BankAccountStatus",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "BankAccountNumber",
                table: "Client",
                type: "nvarchar(10)",
                maxLength: 10,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "BankAccountName",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Approver",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "ApprovedBy",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "ApprovalStatus",
                table: "Client",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "AgentId",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "AgentCode",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "AdditionalInformation",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "AdditionalFlag",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AddColumn<string>(
                name: "DestinationUrl",
                table: "Client",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "DividendPaymentTypeId",
                table: "Client",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "EmployeeGrade",
                table: "Client",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<Guid>(
                name: "PepApprovalFormUpload",
                table: "Client",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "SalesOfficerType",
                table: "Client",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "SignatureUpload",
                table: "Client",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "SubscriptionTypeId",
                table: "Client",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateTable(
                name: "ClientJointStaging",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TenantId = table.Column<int>(type: "int", nullable: true),
                    MarketingConsent = table.Column<bool>(type: "bit", nullable: false),
                    DataPrivacy = table.Column<bool>(type: "bit", nullable: false),
                    ResearchConsent = table.Column<bool>(type: "bit", nullable: false),
                    MarketOtherConsent = table.Column<bool>(type: "bit", nullable: false),
                    IdIssueDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    FirstName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    OtherNames = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    FullName = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: true),
                    MaidenName = table.Column<string>(name: "Maiden_Name", type: "nvarchar(100)", maxLength: 100, nullable: true),
                    MothersMaidenName = table.Column<string>(name: "Mothers_Maiden_Name", type: "nvarchar(100)", maxLength: 100, nullable: true),
                    EmployerId = table.Column<string>(name: "Employer_Id", type: "nvarchar(50)", maxLength: 50, nullable: true),
                    Designation = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    DateOfBirth = table.Column<DateTime>(name: "Date_Of_Birth", type: "datetime2", nullable: true),
                    Email = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    MobilePhone = table.Column<string>(name: "Mobile_Phone", type: "nvarchar(50)", maxLength: 50, nullable: true),
                    OfficialPhone = table.Column<string>(name: "Official_Phone", type: "nvarchar(50)", maxLength: 50, nullable: true),
                    NokLastName = table.Column<string>(name: "Nok_LastName", type: "nvarchar(100)", maxLength: 100, nullable: true),
                    NokFirstName = table.Column<string>(name: "Nok_FirstName", type: "nvarchar(100)", maxLength: 100, nullable: true),
                    NokOtherNames = table.Column<string>(name: "Nok_OtherNames", type: "nvarchar(100)", maxLength: 100, nullable: true),
                    NokEmail = table.Column<string>(name: "Nok_Email", type: "nvarchar(100)", maxLength: 100, nullable: true),
                    NokMobilePhone = table.Column<string>(name: "Nok_Mobile_Phone", type: "nvarchar(50)", maxLength: 50, nullable: true),
                    NokDateOfBirth = table.Column<DateTime>(name: "Nok_Date_Of_Birth", type: "datetime2", nullable: true),
                    NokAddress = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: true),
                    NokAddress2 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    NotifySms = table.Column<bool>(type: "bit", nullable: false),
                    NotifyEmail = table.Column<bool>(type: "bit", nullable: false),
                    NotifyPostal = table.Column<bool>(type: "bit", nullable: false),
                    BankAccountName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    BankAccountNumber = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: true),
                    BankAccountStatus = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    Bvn = table.Column<string>(type: "nvarchar(15)", maxLength: 15, nullable: true),
                    BvnLastName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    BvnFirstName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    BvnOtherNames = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    BvnMobilePhone = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    BvnDob = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    BvnStatus = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    CSCSAccountNumber = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    CHN = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: true),
                    PFA = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    RsaPin = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Status = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    KYCStatusPassport = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    KYCStatusDates = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    KYCStatusIdMeans = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    KYCStatusAddressProof = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    KYCStatus = table.Column<int>(type: "int", nullable: false),
                    RecordSourceId = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    RecordLocationId = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    AgentId = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    PromoId = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    ResidentialAddress = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: true),
                    ResidentialAddress2 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    MailingAddress = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    MailingAddress2 = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: true),
                    MailingCity = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    MailingState = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Passport = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Signature = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    IdNumber = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    IdExpiryDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ProofOfAddress = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: true),
                    ProofOfAddressType = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    WebStatus = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    WebPassCode = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    SubProfile = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    LinkId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    AdditionalInformation = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    SchoolId = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    SchoolClass = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    SchoolSession = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    SchoolSessionStart = table.Column<DateTime>(type: "datetime2", nullable: true),
                    StagingId = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    InvestorId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    RegistrationDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    CreatedBy = table.Column<string>(name: "Created_By", type: "nvarchar(100)", maxLength: 100, nullable: true),
                    DateCreated = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ConfirmedBy = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    DateConfirmed = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ApprovedBy = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    DateApproved = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastUpdatedBy = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    DateLastUpdated = table.Column<DateTime>(type: "datetime2", nullable: true),
                    WorkFlowType = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    TransRef = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    OrderId = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    RecordId = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    ClientId = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    Amount = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    Tag = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    Source = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    BeneficiaryName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    BeneficiaryAccount = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    ValueDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ApprovalStatus = table.Column<int>(type: "int", nullable: false),
                    Approver = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    AgentCode = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    OfferPrice = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    SubscriberType = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    OnlineRedemption = table.Column<int>(type: "int", nullable: false),
                    Units = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    TransId = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    ReceivedBy = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    MarketingSource = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    DividendPayment = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    EmailIdemnity = table.Column<int>(type: "int", nullable: false),
                    AdditionalFlag = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    PEP = table.Column<int>(type: "int", nullable: false),
                    CorporateNameOfInstitution = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    CorporateRCRegistrationNumber = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    CorporatePlaceOfIncorporation = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    CorporateDateOfIncorporation = table.Column<DateTime>(type: "datetime2", nullable: true),
                    CorporateBusinessType = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    PhoneNumber = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    CorporateLegalEntityType = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    CorporateWebsite = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    CorporateFaxNumber = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    CorporateEmailAddress = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    CorporateCity = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    CorporateBusinessAddress = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: true),
                    CorporateStreetName = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: true),
                    CorporateAnnualTurnover = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    CorporateLocality = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: true),
                    CorporateNameOfContactPerson = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    CorporateContactEmailAddress = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    CorporateDesignation = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    Narration = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    ReturnCode = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    UpdatedBy = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    Comment = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: true),
                    ChildSurname = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    ChildFirstName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    ChildMiddleName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    ChildDateOfBirth = table.Column<DateTime>(type: "datetime2", nullable: true),
                    IncomeRangePerAnnum = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Tin = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    PlaceOfIssue = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    LevelOfEducation = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    EmployerAddress = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: true),
                    EmployerTelephone = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    EmployerFax = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    EmployerSegment = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    EmployerWebsite = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    EmployerName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    RiskCategory = table.Column<int>(type: "int", nullable: false),
                    RiskSubCategory = table.Column<int>(type: "int", nullable: false),
                    CallOverStatus = table.Column<int>(type: "int", nullable: false),
                    NokCity = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    CountryCode = table.Column<string>(name: "Country_Code", type: "nvarchar(50)", maxLength: 50, nullable: true),
                    CountryCodeOfficial = table.Column<string>(name: "Country_Code_Official", type: "nvarchar(50)", maxLength: 50, nullable: true),
                    NokCountryCode = table.Column<string>(name: "Nok_Country_Code", type: "nvarchar(50)", maxLength: 50, nullable: true),
                    SubscribeToFund = table.Column<bool>(type: "bit", nullable: false),
                    AllDocumentsUpload = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    PurchaseOrderUpload = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    PassportPhotographUpload = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    ProofOfAddressUpload = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    ProofOfIdentityUpload = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    EvidencePaymentUpload = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    PepApprovalFormUpload = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    SubscriptionTypeId = table.Column<int>(type: "int", nullable: false),
                    OnboardingSubscriptionWorkflowId = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DestinationUrl = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ManageSubscriptionTypeId = table.Column<int>(type: "int", nullable: true),
                    Title = table.Column<int>(type: "int", nullable: true),
                    MaritalStatus = table.Column<int>(name: "Marital_Status", type: "int", nullable: true),
                    Nationality = table.Column<int>(type: "int", nullable: true),
                    CountryOfBirth = table.Column<int>(type: "int", nullable: true),
                    StateOfOrigin = table.Column<int>(name: "State_Of_Origin", type: "int", nullable: true),
                    NokTitle = table.Column<int>(name: "Nok_Title", type: "int", nullable: true),
                    NokGender = table.Column<int>(name: "Nok_Gender", type: "int", nullable: true),
                    NokCountry = table.Column<int>(type: "int", nullable: true),
                    NokState = table.Column<int>(type: "int", nullable: true),
                    NokRelationship = table.Column<int>(type: "int", nullable: true),
                    ResidentialState = table.Column<int>(type: "int", nullable: true),
                    MarketingChannelId = table.Column<int>(type: "int", nullable: true),
                    Gender = table.Column<int>(type: "int", nullable: true),
                    Religion = table.Column<int>(type: "int", nullable: true),
                    Bank = table.Column<int>(type: "int", nullable: true),
                    ResidentialCountry = table.Column<int>(type: "int", nullable: true),
                    IdType = table.Column<int>(type: "int", nullable: true),
                    MailingCountry = table.Column<int>(type: "int", nullable: true),
                    PaymentMode = table.Column<int>(type: "int", nullable: true),
                    EmploymentStatus = table.Column<int>(type: "int", nullable: true),
                    NokMaritalStatus = table.Column<int>(type: "int", nullable: true),
                    JobType = table.Column<int>(type: "int", nullable: true),
                    StockBroker = table.Column<int>(type: "int", nullable: true),
                    RelationshipId = table.Column<int>(type: "int", nullable: true),
                    FundId = table.Column<int>(type: "int", nullable: true),
                    CorporateBusinessSector = table.Column<int>(type: "int", nullable: true),
                    CorporateCountry = table.Column<int>(type: "int", nullable: true),
                    CorporateState = table.Column<int>(type: "int", nullable: true),
                    ChildTitle = table.Column<int>(type: "int", nullable: true),
                    ChildGender = table.Column<int>(type: "int", nullable: true),
                    ChildCountryOfBirth = table.Column<int>(type: "int", nullable: true),
                    OtherNationality = table.Column<int>(type: "int", nullable: true),
                    OnboardingPlatform = table.Column<int>(type: "int", nullable: true),
                    SalesOfficer = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SalesOfficerType = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ResidentialCity = table.Column<int>(type: "int", nullable: true),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    DeleterUserId = table.Column<long>(type: "bigint", nullable: true),
                    DeletionTime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ClientJointStaging", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ClientJointStaging_Tbl_Banks_Bank",
                        column: x => x.Bank,
                        principalTable: "Tbl_Banks",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientJointStaging_Tbl_Countries_ChildCountryOfBirth",
                        column: x => x.ChildCountryOfBirth,
                        principalTable: "Tbl_Countries",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientJointStaging_Tbl_Countries_CorporateCountry",
                        column: x => x.CorporateCountry,
                        principalTable: "Tbl_Countries",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientJointStaging_Tbl_Countries_CountryOfBirth",
                        column: x => x.CountryOfBirth,
                        principalTable: "Tbl_Countries",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientJointStaging_Tbl_Countries_MailingCountry",
                        column: x => x.MailingCountry,
                        principalTable: "Tbl_Countries",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientJointStaging_Tbl_Countries_Nationality",
                        column: x => x.Nationality,
                        principalTable: "Tbl_Countries",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientJointStaging_Tbl_Countries_NokCountry",
                        column: x => x.NokCountry,
                        principalTable: "Tbl_Countries",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientJointStaging_Tbl_Countries_OtherNationality",
                        column: x => x.OtherNationality,
                        principalTable: "Tbl_Countries",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientJointStaging_Tbl_Countries_ResidentialCountry",
                        column: x => x.ResidentialCountry,
                        principalTable: "Tbl_Countries",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientJointStaging_Tbl_EmploymentStatus_EmploymentStatus",
                        column: x => x.EmploymentStatus,
                        principalTable: "Tbl_EmploymentStatus",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientJointStaging_Tbl_FundDetails_FundId",
                        column: x => x.FundId,
                        principalTable: "Tbl_FundDetails",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientJointStaging_Tbl_Genders_ChildGender",
                        column: x => x.ChildGender,
                        principalTable: "Tbl_Genders",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientJointStaging_Tbl_Genders_Gender",
                        column: x => x.Gender,
                        principalTable: "Tbl_Genders",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientJointStaging_Tbl_Genders_Nok_Gender",
                        column: x => x.NokGender,
                        principalTable: "Tbl_Genders",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientJointStaging_Tbl_IdTypes_IdType",
                        column: x => x.IdType,
                        principalTable: "Tbl_IdTypes",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientJointStaging_Tbl_JobTypes_JobType",
                        column: x => x.JobType,
                        principalTable: "Tbl_JobTypes",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientJointStaging_Tbl_MaritalStatus_Marital_Status",
                        column: x => x.MaritalStatus,
                        principalTable: "Tbl_MaritalStatus",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientJointStaging_Tbl_MaritalStatus_NokMaritalStatus",
                        column: x => x.NokMaritalStatus,
                        principalTable: "Tbl_MaritalStatus",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientJointStaging_Tbl_MarketingChannels_MarketingChannelId",
                        column: x => x.MarketingChannelId,
                        principalTable: "Tbl_MarketingChannels",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientJointStaging_Tbl_OnboardingPlatforms_OnboardingPlatform",
                        column: x => x.OnboardingPlatform,
                        principalTable: "Tbl_OnboardingPlatforms",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientJointStaging_Tbl_PaymentModes_PaymentMode",
                        column: x => x.PaymentMode,
                        principalTable: "Tbl_PaymentModes",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientJointStaging_Tbl_Relationships_NokRelationship",
                        column: x => x.NokRelationship,
                        principalTable: "Tbl_Relationships",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientJointStaging_Tbl_Relationships_RelationshipId",
                        column: x => x.RelationshipId,
                        principalTable: "Tbl_Relationships",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientJointStaging_Tbl_Religion_Religion",
                        column: x => x.Religion,
                        principalTable: "Tbl_Religion",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientJointStaging_Tbl_Sector_CorporateBusinessSector",
                        column: x => x.CorporateBusinessSector,
                        principalTable: "Tbl_Sector",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientJointStaging_Tbl_States_CorporateState",
                        column: x => x.CorporateState,
                        principalTable: "Tbl_States",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientJointStaging_Tbl_States_NokState",
                        column: x => x.NokState,
                        principalTable: "Tbl_States",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientJointStaging_Tbl_States_ResidentialState",
                        column: x => x.ResidentialState,
                        principalTable: "Tbl_States",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientJointStaging_Tbl_States_State_Of_Origin",
                        column: x => x.StateOfOrigin,
                        principalTable: "Tbl_States",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientJointStaging_Tbl_StockBrokers_StockBroker",
                        column: x => x.StockBroker,
                        principalTable: "Tbl_StockBrokers",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientJointStaging_Tbl_SubscriptionTypes_ManageSubscriptionTypeId",
                        column: x => x.ManageSubscriptionTypeId,
                        principalTable: "Tbl_SubscriptionTypes",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientJointStaging_Tbl_Titles_ChildTitle",
                        column: x => x.ChildTitle,
                        principalTable: "Tbl_Titles",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientJointStaging_Tbl_Titles_Nok_Title",
                        column: x => x.NokTitle,
                        principalTable: "Tbl_Titles",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientJointStaging_Tbl_Titles_Title",
                        column: x => x.Title,
                        principalTable: "Tbl_Titles",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientJointStaging_Tbl_Town_ResidentialCity",
                        column: x => x.ResidentialCity,
                        principalTable: "Tbl_Town",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "Tbl_ApprovalJournals",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ApprovalType = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    WorkflowId = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: false),
                    ApprovalChainId = table.Column<int>(type: "int", nullable: false),
                    ApprovalStatus = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    ApprovalComment = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    CreatedBy = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    DeleterUserId = table.Column<long>(type: "bigint", nullable: true),
                    DeletionTime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tbl_ApprovalJournals", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Tbl_DividendPaymentTypes",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DividendPaymentType = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    ExternalAppValue = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    DeleterUserId = table.Column<long>(type: "bigint", nullable: true),
                    DeletionTime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tbl_DividendPaymentTypes", x => x.Id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Client_DividendPaymentTypeId",
                table: "Client",
                column: "DividendPaymentTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_ClientJointStaging_Bank",
                table: "ClientJointStaging",
                column: "Bank");

            migrationBuilder.CreateIndex(
                name: "IX_ClientJointStaging_ChildCountryOfBirth",
                table: "ClientJointStaging",
                column: "ChildCountryOfBirth");

            migrationBuilder.CreateIndex(
                name: "IX_ClientJointStaging_ChildGender",
                table: "ClientJointStaging",
                column: "ChildGender");

            migrationBuilder.CreateIndex(
                name: "IX_ClientJointStaging_ChildTitle",
                table: "ClientJointStaging",
                column: "ChildTitle");

            migrationBuilder.CreateIndex(
                name: "IX_ClientJointStaging_CorporateBusinessSector",
                table: "ClientJointStaging",
                column: "CorporateBusinessSector");

            migrationBuilder.CreateIndex(
                name: "IX_ClientJointStaging_CorporateCountry",
                table: "ClientJointStaging",
                column: "CorporateCountry");

            migrationBuilder.CreateIndex(
                name: "IX_ClientJointStaging_CorporateState",
                table: "ClientJointStaging",
                column: "CorporateState");

            migrationBuilder.CreateIndex(
                name: "IX_ClientJointStaging_CountryOfBirth",
                table: "ClientJointStaging",
                column: "CountryOfBirth");

            migrationBuilder.CreateIndex(
                name: "IX_ClientJointStaging_EmploymentStatus",
                table: "ClientJointStaging",
                column: "EmploymentStatus");

            migrationBuilder.CreateIndex(
                name: "IX_ClientJointStaging_FundId",
                table: "ClientJointStaging",
                column: "FundId");

            migrationBuilder.CreateIndex(
                name: "IX_ClientJointStaging_Gender",
                table: "ClientJointStaging",
                column: "Gender");

            migrationBuilder.CreateIndex(
                name: "IX_ClientJointStaging_IdType",
                table: "ClientJointStaging",
                column: "IdType");

            migrationBuilder.CreateIndex(
                name: "IX_ClientJointStaging_JobType",
                table: "ClientJointStaging",
                column: "JobType");

            migrationBuilder.CreateIndex(
                name: "IX_ClientJointStaging_MailingCountry",
                table: "ClientJointStaging",
                column: "MailingCountry");

            migrationBuilder.CreateIndex(
                name: "IX_ClientJointStaging_ManageSubscriptionTypeId",
                table: "ClientJointStaging",
                column: "ManageSubscriptionTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_ClientJointStaging_Marital_Status",
                table: "ClientJointStaging",
                column: "Marital_Status");

            migrationBuilder.CreateIndex(
                name: "IX_ClientJointStaging_MarketingChannelId",
                table: "ClientJointStaging",
                column: "MarketingChannelId");

            migrationBuilder.CreateIndex(
                name: "IX_ClientJointStaging_Nationality",
                table: "ClientJointStaging",
                column: "Nationality");

            migrationBuilder.CreateIndex(
                name: "IX_ClientJointStaging_Nok_Gender",
                table: "ClientJointStaging",
                column: "Nok_Gender");

            migrationBuilder.CreateIndex(
                name: "IX_ClientJointStaging_Nok_Title",
                table: "ClientJointStaging",
                column: "Nok_Title");

            migrationBuilder.CreateIndex(
                name: "IX_ClientJointStaging_NokCountry",
                table: "ClientJointStaging",
                column: "NokCountry");

            migrationBuilder.CreateIndex(
                name: "IX_ClientJointStaging_NokMaritalStatus",
                table: "ClientJointStaging",
                column: "NokMaritalStatus");

            migrationBuilder.CreateIndex(
                name: "IX_ClientJointStaging_NokRelationship",
                table: "ClientJointStaging",
                column: "NokRelationship");

            migrationBuilder.CreateIndex(
                name: "IX_ClientJointStaging_NokState",
                table: "ClientJointStaging",
                column: "NokState");

            migrationBuilder.CreateIndex(
                name: "IX_ClientJointStaging_OnboardingPlatform",
                table: "ClientJointStaging",
                column: "OnboardingPlatform");

            migrationBuilder.CreateIndex(
                name: "IX_ClientJointStaging_OtherNationality",
                table: "ClientJointStaging",
                column: "OtherNationality");

            migrationBuilder.CreateIndex(
                name: "IX_ClientJointStaging_PaymentMode",
                table: "ClientJointStaging",
                column: "PaymentMode");

            migrationBuilder.CreateIndex(
                name: "IX_ClientJointStaging_RelationshipId",
                table: "ClientJointStaging",
                column: "RelationshipId");

            migrationBuilder.CreateIndex(
                name: "IX_ClientJointStaging_Religion",
                table: "ClientJointStaging",
                column: "Religion");

            migrationBuilder.CreateIndex(
                name: "IX_ClientJointStaging_ResidentialCity",
                table: "ClientJointStaging",
                column: "ResidentialCity");

            migrationBuilder.CreateIndex(
                name: "IX_ClientJointStaging_ResidentialCountry",
                table: "ClientJointStaging",
                column: "ResidentialCountry");

            migrationBuilder.CreateIndex(
                name: "IX_ClientJointStaging_ResidentialState",
                table: "ClientJointStaging",
                column: "ResidentialState");

            migrationBuilder.CreateIndex(
                name: "IX_ClientJointStaging_State_Of_Origin",
                table: "ClientJointStaging",
                column: "State_Of_Origin");

            migrationBuilder.CreateIndex(
                name: "IX_ClientJointStaging_StockBroker",
                table: "ClientJointStaging",
                column: "StockBroker");

            migrationBuilder.CreateIndex(
                name: "IX_ClientJointStaging_Title",
                table: "ClientJointStaging",
                column: "Title");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Tbl_DividendPaymentTypes_DividendPaymentTypeId",
                table: "Client",
                column: "DividendPaymentTypeId",
                principalTable: "Tbl_DividendPaymentTypes",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Tbl_SubscriptionTypes_ManageSubscriptionTypeId",
                table: "Client",
                column: "ManageSubscriptionTypeId",
                principalTable: "Tbl_SubscriptionTypes",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Client_Tbl_DividendPaymentTypes_DividendPaymentTypeId",
                table: "Client");

            migrationBuilder.DropForeignKey(
                name: "FK_Client_Tbl_SubscriptionTypes_ManageSubscriptionTypeId",
                table: "Client");

            migrationBuilder.DropTable(
                name: "ClientJointStaging");

            migrationBuilder.DropTable(
                name: "Tbl_ApprovalJournals");

            migrationBuilder.DropTable(
                name: "Tbl_DividendPaymentTypes");

            migrationBuilder.DropIndex(
                name: "IX_Client_DividendPaymentTypeId",
                table: "Client");

            migrationBuilder.DropColumn(
                name: "DestinationUrl",
                table: "Client");

            migrationBuilder.DropColumn(
                name: "DividendPaymentTypeId",
                table: "Client");

            migrationBuilder.DropColumn(
                name: "EmployeeGrade",
                table: "Client");

            migrationBuilder.DropColumn(
                name: "PepApprovalFormUpload",
                table: "Client");

            migrationBuilder.DropColumn(
                name: "SalesOfficerType",
                table: "Client");

            migrationBuilder.DropColumn(
                name: "SignatureUpload",
                table: "Client");

            migrationBuilder.DropColumn(
                name: "SubscriptionTypeId",
                table: "Client");

            migrationBuilder.AlterColumn<string>(
                name: "WorkFlowType",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "WebStatus",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "WebPassCode",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "UpdatedBy",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "TransRef",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "TransId",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Tin",
                table: "Client",
                type: "nvarchar(200)",
                maxLength: 200,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Tag",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "SubscriberType",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "SubProfile",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Status",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "StagingId",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Source",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "SchoolSession",
                table: "Client",
                type: "nvarchar(200)",
                maxLength: 200,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "SchoolId",
                table: "Client",
                type: "nvarchar(200)",
                maxLength: 200,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "SchoolClass",
                table: "Client",
                type: "nvarchar(200)",
                maxLength: 200,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<long>(
                name: "SalesOfficer",
                table: "Client",
                type: "bigint",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "RsaPin",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "ReturnCode",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "ResidentialAddress2",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "ResidentialAddress",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(150)",
                oldMaxLength: 150,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "RecordSourceId",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "RecordLocationId",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "RecordId",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "ReceivedBy",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "ProofOfAddressType",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "PromoId",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "PlaceOfIssue",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "PhoneNumber",
                table: "Client",
                type: "nvarchar(200)",
                maxLength: 200,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "PFA",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "OtherNames",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "OrderId",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Official_Phone",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Nok_OtherNames",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Nok_Mobile_Phone",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Nok_LastName",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Nok_FirstName",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Nok_Email",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Nok_Country_Code",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "NokCity",
                table: "Client",
                type: "nvarchar(250)",
                maxLength: 250,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "NokAddress2",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "NokAddress",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(150)",
                oldMaxLength: 150,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Narration",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Mothers_Maiden_Name",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Mobile_Phone",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "ManageSubscriptionTypeId",
                table: "Client",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "MailingState",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "MailingCity",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "MailingAddress2",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(150)",
                oldMaxLength: 150,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "MailingAddress",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Maiden_Name",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "LevelOfEducation",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "LastUpdatedBy",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "LastName",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "KYCStatusPassport",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "KYCStatusIdMeans",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "KYCStatusDates",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "KYCStatusAddressProof",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "IncomeRangePerAnnum",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "IdNumber",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "FullName",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(150)",
                oldMaxLength: 150,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "FirstName",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Employer_Id",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "EmployerWebsite",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "EmployerTelephone",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "EmployerSegment",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AlterColumn<string>(
                name: "EmployerName",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "EmployerFax",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "EmployerAddress",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(150)",
                oldMaxLength: 150,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Email",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "DividendPayment",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Designation",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Created_By",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Country_Code_Official",
                table: "Client",
                type: "nvarchar(150)",
                maxLength: 150,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Country_Code",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "CorporateWebsite",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "CorporateStreetName",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(150)",
                oldMaxLength: 150,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "CorporateRCRegistrationNumber",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "CorporatePlaceOfIncorporation",
                table: "Client",
                type: "nvarchar(200)",
                maxLength: 200,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "CorporateNameOfInstitution",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "CorporateNameOfContactPerson",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "CorporateLocality",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(150)",
                oldMaxLength: 150,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "CorporateLegalEntityType",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "CorporateFaxNumber",
                table: "Client",
                type: "nvarchar(200)",
                maxLength: 200,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "CorporateEmailAddress",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "CorporateDesignation",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "CorporateContactEmailAddress",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "CorporateCity",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "CorporateBusinessType",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "CorporateBusinessAddress",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(150)",
                oldMaxLength: 150,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "ConfirmedBy",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Comment",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(150)",
                oldMaxLength: 150,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "ClientId",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "ChildSurname",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "ChildMiddleName",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "ChildFirstName",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "CSCSAccountNumber",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "CHN",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(150)",
                oldMaxLength: 150,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "BvnStatus",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "BvnOtherNames",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "BvnMobilePhone",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "BvnLastName",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "BvnFirstName",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "BvnDob",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Bvn",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(15)",
                oldMaxLength: 15,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "BeneficiaryName",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "BeneficiaryAccount",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "BankAccountStatus",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "BankAccountNumber",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(10)",
                oldMaxLength: 10,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "BankAccountName",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Approver",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "ApprovedBy",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "ApprovalStatus",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AlterColumn<string>(
                name: "AgentId",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "AgentCode",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "AdditionalInformation",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "AdditionalFlag",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Client_SalesOfficer",
                table: "Client",
                column: "SalesOfficer");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_SIAML_Users_SalesOfficer",
                table: "Client",
                column: "SalesOfficer",
                principalTable: "SIAML_Users",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Tbl_SubscriptionTypes_ManageSubscriptionTypeId",
                table: "Client",
                column: "ManageSubscriptionTypeId",
                principalTable: "Tbl_SubscriptionTypes",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
