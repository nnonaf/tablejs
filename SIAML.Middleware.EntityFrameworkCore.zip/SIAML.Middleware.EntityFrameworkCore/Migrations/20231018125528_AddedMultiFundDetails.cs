﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SIAML.Middleware.Migrations
{
    /// <inheritdoc />
    public partial class AddedMultiFundDetails : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "OnboardingSubscriptionWorkflowId",
                table: "Client",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "Tbl_OnboardingSubscriptionCustomerFunds",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    OnboardingSubscriptionWorkflowId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    FundPrice = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Units = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    FundName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Amount = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    FundDetailId = table.Column<int>(type: "int", nullable: true),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    DeleterUserId = table.Column<long>(type: "bigint", nullable: true),
                    DeletionTime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tbl_OnboardingSubscriptionCustomerFunds", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Tbl_OnboardingSubscriptionCustomerFunds_Tbl_FundDetails_FundDetailId",
                        column: x => x.FundDetailId,
                        principalTable: "Tbl_FundDetails",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateIndex(
                name: "IX_Tbl_OnboardingSubscriptionCustomerFunds_FundDetailId",
                table: "Tbl_OnboardingSubscriptionCustomerFunds",
                column: "FundDetailId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Tbl_OnboardingSubscriptionCustomerFunds");

            migrationBuilder.DropColumn(
                name: "OnboardingSubscriptionWorkflowId",
                table: "Client");
        }
    }
}
