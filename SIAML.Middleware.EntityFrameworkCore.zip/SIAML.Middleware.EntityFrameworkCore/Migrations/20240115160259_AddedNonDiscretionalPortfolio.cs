﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SIAML.Middleware.Migrations
{
    /// <inheritdoc />
    public partial class AddedNonDiscretionalPortfolio : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "LegalEntityType",
                table: "Tbl_LegalEntities",
                type: "nvarchar(30)",
                maxLength: 30,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(150)",
                oldMaxLength: 150);

            migrationBuilder.CreateTable(
                name: "Tbl_NonDiscretionalPortfolios",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PortfolioName = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: false),
                    FundSchemeType = table.Column<int>(type: "int", nullable: false),
                    PortfolioClass = table.Column<int>(type: "int", nullable: false),
                    OnboardingSubscriptionWorkflowId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Eaccount = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    FundCode = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    DeleterUserId = table.Column<long>(type: "bigint", nullable: true),
                    DeletionTime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tbl_NonDiscretionalPortfolios", x => x.Id);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Tbl_NonDiscretionalPortfolios");

            migrationBuilder.AlterColumn<string>(
                name: "LegalEntityType",
                table: "Tbl_LegalEntities",
                type: "nvarchar(150)",
                maxLength: 150,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(30)",
                oldMaxLength: 30);
        }
    }
}
