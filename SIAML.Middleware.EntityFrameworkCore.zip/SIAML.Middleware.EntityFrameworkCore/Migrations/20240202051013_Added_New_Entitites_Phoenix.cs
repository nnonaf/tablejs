﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SIAML.Middleware.Migrations
{
    /// <inheritdoc />
    public partial class AddedNewEntititesPhoenix : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "PhoneNumber",
                table: "Tbl_OnboardingSubscriptionSignatories",
                type: "nvarchar(18)",
                maxLength: 18,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(20)",
                oldMaxLength: 20);

            migrationBuilder.AddColumn<string>(
                name: "Mobile_Phone_Category",
                table: "Tbl_OnboardingSubscriptionSignatories",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "PhoneNumber",
                table: "Tbl_OnboardingSubscriptionDirectors",
                type: "nvarchar(18)",
                maxLength: 18,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(20)",
                oldMaxLength: 20);

            migrationBuilder.AddColumn<string>(
                name: "Mobile_Phone_Category",
                table: "Tbl_OnboardingSubscriptionDirectors",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Nok_Mobile_Phone",
                table: "ClientJointSecondary",
                type: "nvarchar(18)",
                maxLength: 18,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Mobile_Phone",
                table: "ClientJointSecondary",
                type: "nvarchar(18)",
                maxLength: 18,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Mobile_Phone_Category",
                table: "ClientJointSecondary",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Nok_Mobile_Phone_Category",
                table: "ClientJointSecondary",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Nok_Mobile_Phone",
                table: "Client",
                type: "nvarchar(18)",
                maxLength: 18,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Mobile_Phone",
                table: "Client",
                type: "nvarchar(18)",
                maxLength: 18,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "GoogleSearchUpload",
                table: "Client",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Mobile_Phone_Category",
                table: "Client",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Nok_Mobile_Phone_Category",
                table: "Client",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "SafeWatchUpload",
                table: "Client",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "Tbl_ClientAdditionalAccounts",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FirstName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    MiddleName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    LastName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    FundCode = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    Email = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Phone = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    Gender = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    Address = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    BankName = table.Column<string>(type: "nvarchar(25)", maxLength: 25, nullable: true),
                    BankSortCode = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    BankAccountName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    BankAccountNumber = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    DateOfBirth = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Bvn = table.Column<string>(type: "nvarchar(11)", maxLength: 11, nullable: false),
                    SourceChannel = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    BvnPhone = table.Column<string>(type: "nvarchar(15)", maxLength: 15, nullable: false),
                    RefBy = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Nationality = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    NationalityCode = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: true),
                    PlaceOfBirth = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    WorkflowId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ApprovalStatus = table.Column<int>(type: "int", nullable: false),
                    RequestType = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Eaccount = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    BankAccountStatus = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    FundId = table.Column<int>(type: "int", nullable: true),
                    Bank = table.Column<int>(type: "int", nullable: true),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    DeleterUserId = table.Column<long>(type: "bigint", nullable: true),
                    DeletionTime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tbl_ClientAdditionalAccounts", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Tbl_ClientAdditionalAccounts_Tbl_Banks_Bank",
                        column: x => x.Bank,
                        principalTable: "Tbl_Banks",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_Tbl_ClientAdditionalAccounts_Tbl_FundDetails_FundId",
                        column: x => x.FundId,
                        principalTable: "Tbl_FundDetails",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateIndex(
                name: "IX_Tbl_ClientAdditionalAccounts_Bank",
                table: "Tbl_ClientAdditionalAccounts",
                column: "Bank");

            migrationBuilder.CreateIndex(
                name: "IX_Tbl_ClientAdditionalAccounts_FundId",
                table: "Tbl_ClientAdditionalAccounts",
                column: "FundId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Tbl_ClientAdditionalAccounts");

            migrationBuilder.DropColumn(
                name: "Mobile_Phone_Category",
                table: "Tbl_OnboardingSubscriptionSignatories");

            migrationBuilder.DropColumn(
                name: "Mobile_Phone_Category",
                table: "Tbl_OnboardingSubscriptionDirectors");

            migrationBuilder.DropColumn(
                name: "Mobile_Phone_Category",
                table: "ClientJointSecondary");

            migrationBuilder.DropColumn(
                name: "Nok_Mobile_Phone_Category",
                table: "ClientJointSecondary");

            migrationBuilder.DropColumn(
                name: "GoogleSearchUpload",
                table: "Client");

            migrationBuilder.DropColumn(
                name: "Mobile_Phone_Category",
                table: "Client");

            migrationBuilder.DropColumn(
                name: "Nok_Mobile_Phone_Category",
                table: "Client");

            migrationBuilder.DropColumn(
                name: "SafeWatchUpload",
                table: "Client");

            migrationBuilder.AlterColumn<string>(
                name: "PhoneNumber",
                table: "Tbl_OnboardingSubscriptionSignatories",
                type: "nvarchar(20)",
                maxLength: 20,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(18)",
                oldMaxLength: 18);

            migrationBuilder.AlterColumn<string>(
                name: "PhoneNumber",
                table: "Tbl_OnboardingSubscriptionDirectors",
                type: "nvarchar(20)",
                maxLength: 20,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(18)",
                oldMaxLength: 18);

            migrationBuilder.AlterColumn<string>(
                name: "Nok_Mobile_Phone",
                table: "ClientJointSecondary",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(18)",
                oldMaxLength: 18,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Mobile_Phone",
                table: "ClientJointSecondary",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(18)",
                oldMaxLength: 18,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Nok_Mobile_Phone",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(18)",
                oldMaxLength: 18,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Mobile_Phone",
                table: "Client",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(18)",
                oldMaxLength: 18,
                oldNullable: true);
        }
    }
}
