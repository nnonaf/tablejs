﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SIAML.Middleware.Migrations
{
    /// <inheritdoc />
    public partial class ModifiedOnboardingSubscriptionEntity : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "EvidencePaymentUpload",
                table: "ClientJointStaging",
                newName: "AdditionalUpload");

            migrationBuilder.RenameColumn(
                name: "EvidencePaymentUpload",
                table: "Client",
                newName: "AdditionalUpload");

            migrationBuilder.AddColumn<string>(
                name: "BankAccountNameMismatchComment",
                table: "Client",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "BvnNameMismatchComment",
                table: "Client",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "MarketGroupConsent",
                table: "Client",
                type: "bit",
                nullable: false,
                defaultValue: false);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "BankAccountNameMismatchComment",
                table: "Client");

            migrationBuilder.DropColumn(
                name: "BvnNameMismatchComment",
                table: "Client");

            migrationBuilder.DropColumn(
                name: "MarketGroupConsent",
                table: "Client");

            migrationBuilder.RenameColumn(
                name: "AdditionalUpload",
                table: "ClientJointStaging",
                newName: "EvidencePaymentUpload");

            migrationBuilder.RenameColumn(
                name: "AdditionalUpload",
                table: "Client",
                newName: "EvidencePaymentUpload");
        }
    }
}
