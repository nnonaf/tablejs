﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SIAML.Middleware.Migrations
{
    /// <inheritdoc />
    public partial class PhoenixEntities : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Tbl_SubscriptionWorkflows");

            migrationBuilder.CreateTable(
                name: "ManageCurrencies",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CurrrencyName = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: false),
                    CurrencyMnemonic = table.Column<string>(type: "nvarchar(5)", maxLength: 5, nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    DeleterUserId = table.Column<long>(type: "bigint", nullable: true),
                    DeletionTime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ManageCurrencies", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Tbl_Banks",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    BankCode = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    BankName = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    DeleterUserId = table.Column<long>(type: "bigint", nullable: true),
                    DeletionTime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tbl_Banks", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Tbl_Countries",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CountryName = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: false),
                    CountryCode = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    DeleterUserId = table.Column<long>(type: "bigint", nullable: true),
                    DeletionTime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tbl_Countries", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Tbl_Education",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    EducationName = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    DeleterUserId = table.Column<long>(type: "bigint", nullable: true),
                    DeletionTime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tbl_Education", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Tbl_EmploymentStatus",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    EmploymentStatus = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    DeleterUserId = table.Column<long>(type: "bigint", nullable: true),
                    DeletionTime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tbl_EmploymentStatus", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Tbl_Genders",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Gender = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    DeleterUserId = table.Column<long>(type: "bigint", nullable: true),
                    DeletionTime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tbl_Genders", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Tbl_IdTypes",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    IdTypeName = table.Column<string>(type: "nvarchar(350)", maxLength: 350, nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    DeleterUserId = table.Column<long>(type: "bigint", nullable: true),
                    DeletionTime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tbl_IdTypes", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Tbl_JobTypes",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    JobTypeName = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    DeleterUserId = table.Column<long>(type: "bigint", nullable: true),
                    DeletionTime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tbl_JobTypes", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Tbl_MaritalStatus",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MaritalStatus = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    DeleterUserId = table.Column<long>(type: "bigint", nullable: true),
                    DeletionTime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tbl_MaritalStatus", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Tbl_MarketingChannels",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MarketingChannel = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    DeleterUserId = table.Column<long>(type: "bigint", nullable: true),
                    DeletionTime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tbl_MarketingChannels", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Tbl_OnboardingPlatforms",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    OnboardingPlatform = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    DeleterUserId = table.Column<long>(type: "bigint", nullable: true),
                    DeletionTime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tbl_OnboardingPlatforms", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Tbl_PaymentModes",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PaymentMode = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    DeleterUserId = table.Column<long>(type: "bigint", nullable: true),
                    DeletionTime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tbl_PaymentModes", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Tbl_Relationships",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RelationshipName = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    DeleterUserId = table.Column<long>(type: "bigint", nullable: true),
                    DeletionTime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tbl_Relationships", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Tbl_Religion",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Religion = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    DeleterUserId = table.Column<long>(type: "bigint", nullable: true),
                    DeletionTime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tbl_Religion", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Tbl_Sector",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SectorName = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    DeleterUserId = table.Column<long>(type: "bigint", nullable: true),
                    DeletionTime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tbl_Sector", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Tbl_StockBrokers",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    StockBrokerName = table.Column<string>(type: "nvarchar(300)", maxLength: 300, nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    DeleterUserId = table.Column<long>(type: "bigint", nullable: true),
                    DeletionTime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tbl_StockBrokers", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Tbl_SubscriptionTypes",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SubscriptionType = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    DeleterUserId = table.Column<long>(type: "bigint", nullable: true),
                    DeletionTime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tbl_SubscriptionTypes", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Tbl_Titles",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Title = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    DeleterUserId = table.Column<long>(type: "bigint", nullable: true),
                    DeletionTime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tbl_Titles", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Tbl_FundDetails",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FundId = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: false),
                    FundName = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: false),
                    AssetAllocation = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    AnyInvestmentRestricted = table.Column<bool>(type: "bit", nullable: false),
                    RestrictedInvestment = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    AnyGuarantee = table.Column<bool>(type: "bit", nullable: false),
                    Guarantee = table.Column<string>(type: "nvarchar(350)", maxLength: 350, nullable: true),
                    InvestmentHorizon = table.Column<string>(type: "nvarchar(350)", maxLength: 350, nullable: false),
                    InvestmentObjective = table.Column<string>(type: "nvarchar(350)", maxLength: 350, nullable: false),
                    Risk = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    Redemption = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: false),
                    NominalValue = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    MinimumInvestment = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    SubsequentInvestment = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    HandlingCharges = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: false),
                    InceptionDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    DistributionFrequency = table.Column<int>(type: "int", nullable: false),
                    Currency = table.Column<int>(type: "int", nullable: true),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    DeleterUserId = table.Column<long>(type: "bigint", nullable: true),
                    DeletionTime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tbl_FundDetails", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Tbl_FundDetails_ManageCurrencies_Currency",
                        column: x => x.Currency,
                        principalTable: "ManageCurrencies",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "Tbl_States",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    StateName = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    CountryId = table.Column<int>(type: "int", nullable: true),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    DeleterUserId = table.Column<long>(type: "bigint", nullable: true),
                    DeletionTime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tbl_States", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Tbl_States_Tbl_Countries_CountryId",
                        column: x => x.CountryId,
                        principalTable: "Tbl_Countries",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "Client",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TenantId = table.Column<int>(type: "int", nullable: true),
                    MarketingConsent = table.Column<bool>(type: "bit", nullable: false),
                    DataPrivacy = table.Column<bool>(type: "bit", nullable: false),
                    IdIssueDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    FirstName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    OtherNames = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    FullName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    MaidenName = table.Column<string>(name: "Maiden_Name", type: "nvarchar(500)", maxLength: 500, nullable: true),
                    MothersMaidenName = table.Column<string>(name: "Mothers_Maiden_Name", type: "nvarchar(500)", maxLength: 500, nullable: true),
                    EmployerId = table.Column<string>(name: "Employer_Id", type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Designation = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Gender = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Religion = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    DateOfBirth = table.Column<DateTime>(name: "Date_Of_Birth", type: "datetime2", nullable: true),
                    Email = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    MobilePhone = table.Column<string>(name: "Mobile_Phone", type: "nvarchar(500)", maxLength: 500, nullable: true),
                    OfficialPhone = table.Column<string>(name: "Official_Phone", type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NokLastName = table.Column<string>(name: "Nok_LastName", type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NokFirstName = table.Column<string>(name: "Nok_FirstName", type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NokOtherNames = table.Column<string>(name: "Nok_OtherNames", type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NokEmail = table.Column<string>(name: "Nok_Email", type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NokMobilePhone = table.Column<string>(name: "Nok_Mobile_Phone", type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NokDateOfBirth = table.Column<DateTime>(name: "Nok_Date_Of_Birth", type: "datetime2", nullable: true),
                    NokRelationship = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NokAddress = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NokAddress2 = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NokCity = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NokState = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NokCountry = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NotifySMS = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NotifyEmail = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NotifyPostal = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Bank = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    BankAccountName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    BankAccountNumber = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    BankAccountStatus = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Bvn = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    BvnLastName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    BvnFirstName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    BvnOtherNames = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    BvnMobilePhone = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    BvnDob = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    BvnStatus = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    StockBroker = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CSCSAccountNumber = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CHN = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    PFA = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    RsaPin = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Status = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    KYCStatusPassport = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    KYCStatusDates = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    KYCStatusIdMeans = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    KYCStatusAddressProof = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    KYCStatus = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    RecordSourceId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    RecordLocationId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    AgentId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    PromoId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    MarketingChannelId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ResidentialAddress = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ResidentialAddress2 = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ResidentialCity = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ResidentialState = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ResidentialCountry = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    MailingAddress = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    MailingAddress2 = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    MailingCity = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    MailingState = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    MailingCountry = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Passport = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Signature = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    IdType = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    IdNumber = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    IdExpiryDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ProofOfAddress = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: true),
                    ProofOfAddressType = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    WebStatus = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    WebPassCode = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    SubProfile = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    LinkId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    RelationshipId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    AdditionalInformation = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    SchoolId = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    SchoolClass = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    SchoolSession = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    SchoolSessionStart = table.Column<DateTime>(type: "datetime2", nullable: true),
                    StagingId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    InvestorId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    RegistrationDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    CreatedBy = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    DateCreated = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ConfirmedBy = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    DateConfirmed = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ApprovedBy = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    DateApproved = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastUpdatedBy = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    DateLastUpdated = table.Column<DateTime>(type: "datetime2", nullable: true),
                    WorkFlowType = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    TransRef = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    OrderId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    RecordId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ClientId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Amount = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    FundId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Tag = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Source = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    BeneficiaryName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    BeneficiaryAccount = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ValueDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ApprovalStatus = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Approver = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    AgentCode = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    PaymentMode = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    OfferPrice = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    SubscriberType = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    OnlineRedemption = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Units = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    TransId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    SalesOfficer = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ReceivedBy = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    MarketingSource = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    DividendPayment = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    EmailIdemnity = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    AdditionalFlag = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    OnboardingPlatform = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    PEP = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    CorporateNameOfInstitution = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateRCRegistrationNumber = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporatePlaceOfIncorporation = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    CorporateDateOfIncorporation = table.Column<DateTime>(type: "datetime2", nullable: true),
                    CorporateBusinessSector = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateBusinessType = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    PhoneNumber = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    CorporateLegalEntityType = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateWebsite = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateFaxNumber = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    CorporateEmailAddress = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateCountry = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateCity = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateState = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateBusinessAddress = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateStreetName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateAnnualTurnover = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    CorporateLocality = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateNameOfContactPerson = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateContactEmailAddress = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateDesignation = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Narration = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ReturnCode = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    JobType = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    UpdatedBy = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Comment = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ChildTitle = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    ChildGender = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    ChildSurname = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ChildFirstName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ChildMiddleName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ChildDateOfBirth = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ChildCountryOfBirth = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    IncomeRangePerAnnum = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Tin = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    NokMaritalStatus = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    PlaceOfIssue = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    OtherNationality = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    EmploymentStatus = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    LevelOfEducation = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    EmployerAddress = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    EmployerTelephone = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    EmployerFax = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    EmployerSegment = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    EmployerWebsite = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    EmployerName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    RiskCategory = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    RiskSubCategory = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CallOverStatus = table.Column<int>(type: "int", nullable: true),
                    ClientType = table.Column<int>(type: "int", nullable: false),
                    Title = table.Column<int>(type: "int", nullable: true),
                    MaritalStatus = table.Column<int>(name: "Marital_Status", type: "int", nullable: true),
                    Nationality = table.Column<int>(type: "int", nullable: true),
                    StateOfOrigin = table.Column<int>(name: "State_Of_Origin", type: "int", nullable: true),
                    CountryCode = table.Column<int>(name: "Country_Code", type: "int", nullable: true),
                    CountryCodeOfficial = table.Column<int>(name: "Country_Code_Official", type: "int", nullable: true),
                    NokTitle = table.Column<int>(name: "Nok_Title", type: "int", nullable: true),
                    NokGender = table.Column<int>(name: "Nok_Gender", type: "int", nullable: true),
                    NokCountryCode = table.Column<int>(name: "Nok_Country_Code", type: "int", nullable: true),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    DeleterUserId = table.Column<long>(type: "bigint", nullable: true),
                    DeletionTime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Client", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Client_Tbl_Countries_Country_Code",
                        column: x => x.CountryCode,
                        principalTable: "Tbl_Countries",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_Client_Tbl_Countries_Country_Code_Official",
                        column: x => x.CountryCodeOfficial,
                        principalTable: "Tbl_Countries",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_Client_Tbl_Countries_Nationality",
                        column: x => x.Nationality,
                        principalTable: "Tbl_Countries",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_Client_Tbl_Countries_Nok_Country_Code",
                        column: x => x.NokCountryCode,
                        principalTable: "Tbl_Countries",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_Client_Tbl_Countries_State_Of_Origin",
                        column: x => x.StateOfOrigin,
                        principalTable: "Tbl_Countries",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_Client_Tbl_Genders_Nok_Gender",
                        column: x => x.NokGender,
                        principalTable: "Tbl_Genders",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_Client_Tbl_MaritalStatus_Marital_Status",
                        column: x => x.MaritalStatus,
                        principalTable: "Tbl_MaritalStatus",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_Client_Tbl_SubscriptionTypes_ClientType",
                        column: x => x.ClientType,
                        principalTable: "Tbl_SubscriptionTypes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Client_Tbl_Titles_Nok_Title",
                        column: x => x.NokTitle,
                        principalTable: "Tbl_Titles",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_Client_Tbl_Titles_Title",
                        column: x => x.Title,
                        principalTable: "Tbl_Titles",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateIndex(
                name: "IX_Client_ClientType",
                table: "Client",
                column: "ClientType");

            migrationBuilder.CreateIndex(
                name: "IX_Client_Country_Code",
                table: "Client",
                column: "Country_Code");

            migrationBuilder.CreateIndex(
                name: "IX_Client_Country_Code_Official",
                table: "Client",
                column: "Country_Code_Official");

            migrationBuilder.CreateIndex(
                name: "IX_Client_Marital_Status",
                table: "Client",
                column: "Marital_Status");

            migrationBuilder.CreateIndex(
                name: "IX_Client_Nationality",
                table: "Client",
                column: "Nationality");

            migrationBuilder.CreateIndex(
                name: "IX_Client_Nok_Country_Code",
                table: "Client",
                column: "Nok_Country_Code");

            migrationBuilder.CreateIndex(
                name: "IX_Client_Nok_Gender",
                table: "Client",
                column: "Nok_Gender");

            migrationBuilder.CreateIndex(
                name: "IX_Client_Nok_Title",
                table: "Client",
                column: "Nok_Title");

            migrationBuilder.CreateIndex(
                name: "IX_Client_State_Of_Origin",
                table: "Client",
                column: "State_Of_Origin");

            migrationBuilder.CreateIndex(
                name: "IX_Client_TenantId",
                table: "Client",
                column: "TenantId");

            migrationBuilder.CreateIndex(
                name: "IX_Client_Title",
                table: "Client",
                column: "Title");

            migrationBuilder.CreateIndex(
                name: "IX_Tbl_FundDetails_Currency",
                table: "Tbl_FundDetails",
                column: "Currency");

            migrationBuilder.CreateIndex(
                name: "IX_Tbl_States_CountryId",
                table: "Tbl_States",
                column: "CountryId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Client");

            migrationBuilder.DropTable(
                name: "Tbl_Banks");

            migrationBuilder.DropTable(
                name: "Tbl_Education");

            migrationBuilder.DropTable(
                name: "Tbl_EmploymentStatus");

            migrationBuilder.DropTable(
                name: "Tbl_FundDetails");

            migrationBuilder.DropTable(
                name: "Tbl_IdTypes");

            migrationBuilder.DropTable(
                name: "Tbl_JobTypes");

            migrationBuilder.DropTable(
                name: "Tbl_MarketingChannels");

            migrationBuilder.DropTable(
                name: "Tbl_OnboardingPlatforms");

            migrationBuilder.DropTable(
                name: "Tbl_PaymentModes");

            migrationBuilder.DropTable(
                name: "Tbl_Relationships");

            migrationBuilder.DropTable(
                name: "Tbl_Religion");

            migrationBuilder.DropTable(
                name: "Tbl_Sector");

            migrationBuilder.DropTable(
                name: "Tbl_States");

            migrationBuilder.DropTable(
                name: "Tbl_StockBrokers");

            migrationBuilder.DropTable(
                name: "Tbl_Genders");

            migrationBuilder.DropTable(
                name: "Tbl_MaritalStatus");

            migrationBuilder.DropTable(
                name: "Tbl_SubscriptionTypes");

            migrationBuilder.DropTable(
                name: "Tbl_Titles");

            migrationBuilder.DropTable(
                name: "ManageCurrencies");

            migrationBuilder.DropTable(
                name: "Tbl_Countries");

            migrationBuilder.CreateTable(
                name: "Tbl_SubscriptionWorkflows",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AdditionalFlag = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    AdditionalInformation = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    AgentCode = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    AgentId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Amount = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    ApprovalStatus = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ApprovedBy = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Approver = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Bank = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    BankAccountName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    BankAccountNumber = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    BankAccountStatus = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    BeneficiaryAccount = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    BeneficiaryName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Bvn = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    BvnDob = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    BvnFirstName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    BvnLastName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    BvnMobilePhone = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    BvnOtherNames = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    BvnStatus = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CHN = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CSCSAccountNumber = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CallOverStatus = table.Column<int>(type: "int", nullable: true),
                    ChildCountryOfBirth = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ChildDateOfBirth = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ChildFirstName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ChildGender = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    ChildMiddleName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ChildSurname = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ChildTitle = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    ClientId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ClientType = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Comment = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ConfirmedBy = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateAnnualTurnover = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    CorporateBusinessAddress = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateBusinessSector = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateBusinessType = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateCity = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateContactEmailAddress = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateCountry = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateDateOfIncorporation = table.Column<DateTime>(type: "datetime2", nullable: true),
                    CorporateDesignation = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateEmailAddress = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateFaxNumber = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    CorporateLegalEntityType = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateLocality = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateNameOfContactPerson = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateNameOfInstitution = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporatePlaceOfIncorporation = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    CorporateRCRegistrationNumber = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateState = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateStreetName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateWebsite = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CountryCode = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CountryCodeOfficial = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CreatedBy = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    DataPrivacy = table.Column<bool>(type: "bit", nullable: false),
                    DateApproved = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DateConfirmed = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DateCreated = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DateLastUpdated = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DateOfBirth = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeleterUserId = table.Column<long>(type: "bigint", nullable: true),
                    DeletionTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Designation = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    DividendPayment = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Email = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    EmailIdemnity = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    EmployerAddress = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    EmployerFax = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    EmployerId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    EmployerName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    EmployerSegment = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    EmployerTelephone = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    EmployerWebsite = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    EmploymentStatus = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    FirstName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    FullName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    FundId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Gender = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    IdExpiryDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    IdIssueDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    IdNumber = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    IdType = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    IncomeRangePerAnnum = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    InvestorId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    JobType = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    KYCStatus = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    KYCStatusAddressProof = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    KYCStatusDates = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    KYCStatusIdMeans = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    KYCStatusPassport = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    LastUpdatedBy = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    LevelOfEducation = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    LinkId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    MaidenName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    MailingAddress = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    MailingAddress2 = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    MailingCity = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    MailingCountry = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    MailingState = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    MaritalStatus = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    MarketingChannelId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    MarketingConsent = table.Column<bool>(type: "bit", nullable: false),
                    MarketingSource = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    MobilePhone = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    MothersMaidenName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Narration = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Nationality = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NokAddress = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NokAddress2 = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NokCity = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NokCountry = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NokCountryCode = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NokDateOfBirth = table.Column<DateTime>(type: "datetime2", nullable: true),
                    NokEmail = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NokFirstName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NokGender = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NokLastName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NokMaritalStatus = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NokMobilePhone = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NokOtherNames = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NokRelationship = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NokState = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NokTitle = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NotifyEmail = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NotifyPostal = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NotifySMS = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    OfferPrice = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    OfficialPhone = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    OnboardingPlatform = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    OnlineRedemption = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    OrderId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    OtherNames = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    OtherNationality = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    PEP = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    PFA = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Passport = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    PaymentMode = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    PhoneNumber = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    PlaceOfIssue = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    PromoId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ProofOfAddress = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: true),
                    ProofOfAddressType = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ReceivedBy = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    RecordId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    RecordLocationId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    RecordSourceId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    RegistrationDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    RelationshipId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Religion = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ResidentialAddress = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ResidentialAddress2 = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ResidentialCity = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ResidentialCountry = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ResidentialState = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ReturnCode = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    RiskCategory = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    RiskSubCategory = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    RsaPin = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    SalesOfficer = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    SchoolClass = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    SchoolId = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    SchoolSession = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    SchoolSessionStart = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Signature = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Source = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    StagingId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    StateOfOrigin = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Status = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    StockBroker = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    SubProfile = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    SubscriberType = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Tag = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    TenantId = table.Column<int>(type: "int", nullable: true),
                    Tin = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    Title = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    TransId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    TransRef = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Units = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    UpdatedBy = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ValueDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    WebPassCode = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    WebStatus = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    WorkFlowType = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tbl_SubscriptionWorkflows", x => x.Id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Tbl_SubscriptionWorkflows_TenantId",
                table: "Tbl_SubscriptionWorkflows",
                column: "TenantId");
        }
    }
}
