﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SIAML.Middleware.Migrations
{
    /// <inheritdoc />
    public partial class ModifiedCliententitiy : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Client_Tbl_States_NokState",
                table: "Client");

            migrationBuilder.DropForeignKey(
                name: "FK_Client_Tbl_States_ResidentialState",
                table: "Client");

            migrationBuilder.DropForeignKey(
                name: "FK_Client_Tbl_States_State_Of_Origin",
                table: "Client");

            migrationBuilder.DropForeignKey(
                name: "FK_Client_Tbl_Town_ResidentialCity",
                table: "Client");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointSecondary_Tbl_States_NokState",
                table: "ClientJointSecondary");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointSecondary_Tbl_States_ResidentialState",
                table: "ClientJointSecondary");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointSecondary_Tbl_States_State_Of_Origin",
                table: "ClientJointSecondary");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointSecondary_Tbl_Town_ResidentialCity",
                table: "ClientJointSecondary");

            migrationBuilder.DropIndex(
                name: "IX_ClientJointSecondary_NokState",
                table: "ClientJointSecondary");

            migrationBuilder.DropIndex(
                name: "IX_ClientJointSecondary_ResidentialCity",
                table: "ClientJointSecondary");

            migrationBuilder.DropIndex(
                name: "IX_ClientJointSecondary_ResidentialState",
                table: "ClientJointSecondary");

            migrationBuilder.DropIndex(
                name: "IX_ClientJointSecondary_State_Of_Origin",
                table: "ClientJointSecondary");

            migrationBuilder.DropIndex(
                name: "IX_Client_NokState",
                table: "Client");

            migrationBuilder.DropIndex(
                name: "IX_Client_ResidentialCity",
                table: "Client");

            migrationBuilder.DropIndex(
                name: "IX_Client_ResidentialState",
                table: "Client");

            migrationBuilder.DropIndex(
                name: "IX_Client_State_Of_Origin",
                table: "Client");

            migrationBuilder.AddColumn<int>(
                name: "NokStateFkId",
                table: "ClientJointSecondary",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ResidentialCityFkId",
                table: "ClientJointSecondary",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ResidentialStateFkId",
                table: "ClientJointSecondary",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "State_Of_OriginFkId",
                table: "ClientJointSecondary",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "NokStateFkId",
                table: "Client",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ResidentialCityFkId",
                table: "Client",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ResidentialStateFkId",
                table: "Client",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "State_Of_OriginFkId",
                table: "Client",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_ClientJointSecondary_NokStateFkId",
                table: "ClientJointSecondary",
                column: "NokStateFkId");

            migrationBuilder.CreateIndex(
                name: "IX_ClientJointSecondary_ResidentialCityFkId",
                table: "ClientJointSecondary",
                column: "ResidentialCityFkId");

            migrationBuilder.CreateIndex(
                name: "IX_ClientJointSecondary_ResidentialStateFkId",
                table: "ClientJointSecondary",
                column: "ResidentialStateFkId");

            migrationBuilder.CreateIndex(
                name: "IX_ClientJointSecondary_State_Of_OriginFkId",
                table: "ClientJointSecondary",
                column: "State_Of_OriginFkId");

            migrationBuilder.CreateIndex(
                name: "IX_Client_NokStateFkId",
                table: "Client",
                column: "NokStateFkId");

            migrationBuilder.CreateIndex(
                name: "IX_Client_ResidentialCityFkId",
                table: "Client",
                column: "ResidentialCityFkId");

            migrationBuilder.CreateIndex(
                name: "IX_Client_ResidentialStateFkId",
                table: "Client",
                column: "ResidentialStateFkId");

            migrationBuilder.CreateIndex(
                name: "IX_Client_State_Of_OriginFkId",
                table: "Client",
                column: "State_Of_OriginFkId");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Tbl_States_NokStateFkId",
                table: "Client",
                column: "NokStateFkId",
                principalTable: "Tbl_States",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Tbl_States_ResidentialStateFkId",
                table: "Client",
                column: "ResidentialStateFkId",
                principalTable: "Tbl_States",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Tbl_States_State_Of_OriginFkId",
                table: "Client",
                column: "State_Of_OriginFkId",
                principalTable: "Tbl_States",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Tbl_Town_ResidentialCityFkId",
                table: "Client",
                column: "ResidentialCityFkId",
                principalTable: "Tbl_Town",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointSecondary_Tbl_States_NokStateFkId",
                table: "ClientJointSecondary",
                column: "NokStateFkId",
                principalTable: "Tbl_States",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointSecondary_Tbl_States_ResidentialStateFkId",
                table: "ClientJointSecondary",
                column: "ResidentialStateFkId",
                principalTable: "Tbl_States",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointSecondary_Tbl_States_State_Of_OriginFkId",
                table: "ClientJointSecondary",
                column: "State_Of_OriginFkId",
                principalTable: "Tbl_States",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointSecondary_Tbl_Town_ResidentialCityFkId",
                table: "ClientJointSecondary",
                column: "ResidentialCityFkId",
                principalTable: "Tbl_Town",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Client_Tbl_States_NokStateFkId",
                table: "Client");

            migrationBuilder.DropForeignKey(
                name: "FK_Client_Tbl_States_ResidentialStateFkId",
                table: "Client");

            migrationBuilder.DropForeignKey(
                name: "FK_Client_Tbl_States_State_Of_OriginFkId",
                table: "Client");

            migrationBuilder.DropForeignKey(
                name: "FK_Client_Tbl_Town_ResidentialCityFkId",
                table: "Client");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointSecondary_Tbl_States_NokStateFkId",
                table: "ClientJointSecondary");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointSecondary_Tbl_States_ResidentialStateFkId",
                table: "ClientJointSecondary");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointSecondary_Tbl_States_State_Of_OriginFkId",
                table: "ClientJointSecondary");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointSecondary_Tbl_Town_ResidentialCityFkId",
                table: "ClientJointSecondary");

            migrationBuilder.DropIndex(
                name: "IX_ClientJointSecondary_NokStateFkId",
                table: "ClientJointSecondary");

            migrationBuilder.DropIndex(
                name: "IX_ClientJointSecondary_ResidentialCityFkId",
                table: "ClientJointSecondary");

            migrationBuilder.DropIndex(
                name: "IX_ClientJointSecondary_ResidentialStateFkId",
                table: "ClientJointSecondary");

            migrationBuilder.DropIndex(
                name: "IX_ClientJointSecondary_State_Of_OriginFkId",
                table: "ClientJointSecondary");

            migrationBuilder.DropIndex(
                name: "IX_Client_NokStateFkId",
                table: "Client");

            migrationBuilder.DropIndex(
                name: "IX_Client_ResidentialCityFkId",
                table: "Client");

            migrationBuilder.DropIndex(
                name: "IX_Client_ResidentialStateFkId",
                table: "Client");

            migrationBuilder.DropIndex(
                name: "IX_Client_State_Of_OriginFkId",
                table: "Client");

            migrationBuilder.DropColumn(
                name: "NokStateFkId",
                table: "ClientJointSecondary");

            migrationBuilder.DropColumn(
                name: "ResidentialCityFkId",
                table: "ClientJointSecondary");

            migrationBuilder.DropColumn(
                name: "ResidentialStateFkId",
                table: "ClientJointSecondary");

            migrationBuilder.DropColumn(
                name: "State_Of_OriginFkId",
                table: "ClientJointSecondary");

            migrationBuilder.DropColumn(
                name: "NokStateFkId",
                table: "Client");

            migrationBuilder.DropColumn(
                name: "ResidentialCityFkId",
                table: "Client");

            migrationBuilder.DropColumn(
                name: "ResidentialStateFkId",
                table: "Client");

            migrationBuilder.DropColumn(
                name: "State_Of_OriginFkId",
                table: "Client");

            migrationBuilder.CreateIndex(
                name: "IX_ClientJointSecondary_NokState",
                table: "ClientJointSecondary",
                column: "NokState");

            migrationBuilder.CreateIndex(
                name: "IX_ClientJointSecondary_ResidentialCity",
                table: "ClientJointSecondary",
                column: "ResidentialCity");

            migrationBuilder.CreateIndex(
                name: "IX_ClientJointSecondary_ResidentialState",
                table: "ClientJointSecondary",
                column: "ResidentialState");

            migrationBuilder.CreateIndex(
                name: "IX_ClientJointSecondary_State_Of_Origin",
                table: "ClientJointSecondary",
                column: "State_Of_Origin");

            migrationBuilder.CreateIndex(
                name: "IX_Client_NokState",
                table: "Client",
                column: "NokState");

            migrationBuilder.CreateIndex(
                name: "IX_Client_ResidentialCity",
                table: "Client",
                column: "ResidentialCity");

            migrationBuilder.CreateIndex(
                name: "IX_Client_ResidentialState",
                table: "Client",
                column: "ResidentialState");

            migrationBuilder.CreateIndex(
                name: "IX_Client_State_Of_Origin",
                table: "Client",
                column: "State_Of_Origin");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Tbl_States_NokState",
                table: "Client",
                column: "NokState",
                principalTable: "Tbl_States",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Tbl_States_ResidentialState",
                table: "Client",
                column: "ResidentialState",
                principalTable: "Tbl_States",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Tbl_States_State_Of_Origin",
                table: "Client",
                column: "State_Of_Origin",
                principalTable: "Tbl_States",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Tbl_Town_ResidentialCity",
                table: "Client",
                column: "ResidentialCity",
                principalTable: "Tbl_Town",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointSecondary_Tbl_States_NokState",
                table: "ClientJointSecondary",
                column: "NokState",
                principalTable: "Tbl_States",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointSecondary_Tbl_States_ResidentialState",
                table: "ClientJointSecondary",
                column: "ResidentialState",
                principalTable: "Tbl_States",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointSecondary_Tbl_States_State_Of_Origin",
                table: "ClientJointSecondary",
                column: "State_Of_Origin",
                principalTable: "Tbl_States",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointSecondary_Tbl_Town_ResidentialCity",
                table: "ClientJointSecondary",
                column: "ResidentialCity",
                principalTable: "Tbl_Town",
                principalColumn: "Id");
        }
    }
}
