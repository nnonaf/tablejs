﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SIAML.Middleware.Migrations
{
    /// <inheritdoc />
    public partial class InitialMigration : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "SIAML_AuditLogs",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TenantId = table.Column<int>(type: "int", nullable: true),
                    UserId = table.Column<long>(type: "bigint", nullable: true),
                    ServiceName = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    MethodName = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    Parameters = table.Column<string>(type: "nvarchar(1024)", maxLength: 1024, nullable: true),
                    ReturnValue = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ExecutionTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ExecutionDuration = table.Column<int>(type: "int", nullable: false),
                    ClientIpAddress = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: true),
                    ClientName = table.Column<string>(type: "nvarchar(128)", maxLength: 128, nullable: true),
                    BrowserInfo = table.Column<string>(type: "nvarchar(512)", maxLength: 512, nullable: true),
                    ExceptionMessage = table.Column<string>(type: "nvarchar(1024)", maxLength: 1024, nullable: true),
                    Exception = table.Column<string>(type: "nvarchar(2000)", maxLength: 2000, nullable: true),
                    ImpersonatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    ImpersonatorTenantId = table.Column<int>(type: "int", nullable: true),
                    CustomData = table.Column<string>(type: "nvarchar(2000)", maxLength: 2000, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SIAML_AuditLogs", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "SIAML_BackgroundJobs",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    JobType = table.Column<string>(type: "nvarchar(512)", maxLength: 512, nullable: false),
                    JobArgs = table.Column<string>(type: "nvarchar(max)", maxLength: 1048576, nullable: false),
                    TryCount = table.Column<short>(type: "smallint", nullable: false),
                    NextTryTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    LastTryTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    IsAbandoned = table.Column<bool>(type: "bit", nullable: false),
                    Priority = table.Column<byte>(type: "tinyint", nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SIAML_BackgroundJobs", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "SIAML_BinaryObjects",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    TenantId = table.Column<int>(type: "int", nullable: true),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Bytes = table.Column<byte[]>(type: "varbinary(max)", maxLength: 10240, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SIAML_BinaryObjects", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "SIAML_ChatMessages",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserId = table.Column<long>(type: "bigint", nullable: false),
                    TenantId = table.Column<int>(type: "int", nullable: true),
                    TargetUserId = table.Column<long>(type: "bigint", nullable: false),
                    TargetTenantId = table.Column<int>(type: "int", nullable: true),
                    Message = table.Column<string>(type: "nvarchar(max)", maxLength: 4096, nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Side = table.Column<int>(type: "int", nullable: false),
                    ReadState = table.Column<int>(type: "int", nullable: false),
                    ReceiverReadState = table.Column<int>(type: "int", nullable: false),
                    SharedMessageId = table.Column<Guid>(type: "uniqueidentifier", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SIAML_ChatMessages", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "SIAML_DynamicProperties",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PropertyName = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    DisplayName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    InputType = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Permission = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TenantId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SIAML_DynamicProperties", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "SIAML_Editions",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(32)", maxLength: 32, nullable: false),
                    DisplayName = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    DeleterUserId = table.Column<long>(type: "bigint", nullable: true),
                    DeletionTime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SIAML_Editions", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "SIAML_EntityChangeSets",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    BrowserInfo = table.Column<string>(type: "nvarchar(512)", maxLength: 512, nullable: true),
                    ClientIpAddress = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: true),
                    ClientName = table.Column<string>(type: "nvarchar(128)", maxLength: 128, nullable: true),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ExtensionData = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ImpersonatorTenantId = table.Column<int>(type: "int", nullable: true),
                    ImpersonatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    Reason = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    TenantId = table.Column<int>(type: "int", nullable: true),
                    UserId = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SIAML_EntityChangeSets", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "SIAML_Friendships",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserId = table.Column<long>(type: "bigint", nullable: false),
                    TenantId = table.Column<int>(type: "int", nullable: true),
                    FriendUserId = table.Column<long>(type: "bigint", nullable: false),
                    FriendTenantId = table.Column<int>(type: "int", nullable: true),
                    FriendUserName = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: false),
                    FriendTenancyName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    FriendProfilePictureId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    State = table.Column<int>(type: "int", nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SIAML_Friendships", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "SIAML_Invoices",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    InvoiceNo = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    InvoiceDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    TenantLegalName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TenantAddress = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TenantTaxNo = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SIAML_Invoices", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "SIAML_Languages",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TenantId = table.Column<int>(type: "int", nullable: true),
                    Name = table.Column<string>(type: "nvarchar(128)", maxLength: 128, nullable: false),
                    DisplayName = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: false),
                    Icon = table.Column<string>(type: "nvarchar(128)", maxLength: 128, nullable: true),
                    IsDisabled = table.Column<bool>(type: "bit", nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    DeleterUserId = table.Column<long>(type: "bigint", nullable: true),
                    DeletionTime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SIAML_Languages", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "SIAML_LanguageTexts",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TenantId = table.Column<int>(type: "int", nullable: true),
                    LanguageName = table.Column<string>(type: "nvarchar(128)", maxLength: 128, nullable: false),
                    Source = table.Column<string>(type: "nvarchar(128)", maxLength: 128, nullable: false),
                    Key = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: false),
                    Value = table.Column<string>(type: "nvarchar(max)", maxLength: 67108864, nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SIAML_LanguageTexts", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "SIAML_Notifications",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    NotificationName = table.Column<string>(type: "nvarchar(96)", maxLength: 96, nullable: false),
                    Data = table.Column<string>(type: "nvarchar(max)", maxLength: 1048576, nullable: true),
                    DataTypeName = table.Column<string>(type: "nvarchar(512)", maxLength: 512, nullable: true),
                    EntityTypeName = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: true),
                    EntityTypeAssemblyQualifiedName = table.Column<string>(type: "nvarchar(512)", maxLength: 512, nullable: true),
                    EntityId = table.Column<string>(type: "nvarchar(96)", maxLength: 96, nullable: true),
                    Severity = table.Column<byte>(type: "tinyint", nullable: false),
                    UserIds = table.Column<string>(type: "nvarchar(max)", maxLength: 131072, nullable: true),
                    ExcludedUserIds = table.Column<string>(type: "nvarchar(max)", maxLength: 131072, nullable: true),
                    TenantIds = table.Column<string>(type: "nvarchar(max)", maxLength: 131072, nullable: true),
                    TargetNotifiers = table.Column<string>(type: "nvarchar(1024)", maxLength: 1024, nullable: true),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SIAML_Notifications", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "SIAML_NotificationSubscriptions",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    TenantId = table.Column<int>(type: "int", nullable: true),
                    UserId = table.Column<long>(type: "bigint", nullable: false),
                    NotificationName = table.Column<string>(type: "nvarchar(96)", maxLength: 96, nullable: true),
                    EntityTypeName = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: true),
                    EntityTypeAssemblyQualifiedName = table.Column<string>(type: "nvarchar(512)", maxLength: 512, nullable: true),
                    EntityId = table.Column<string>(type: "nvarchar(96)", maxLength: 96, nullable: true),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SIAML_NotificationSubscriptions", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "SIAML_OrganizationUnitRoles",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TenantId = table.Column<int>(type: "int", nullable: true),
                    RoleId = table.Column<int>(type: "int", nullable: false),
                    OrganizationUnitId = table.Column<long>(type: "bigint", nullable: false),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SIAML_OrganizationUnitRoles", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "SIAML_OrganizationUnits",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TenantId = table.Column<int>(type: "int", nullable: true),
                    ParentId = table.Column<long>(type: "bigint", nullable: true),
                    Code = table.Column<string>(type: "nvarchar(95)", maxLength: 95, nullable: false),
                    DisplayName = table.Column<string>(type: "nvarchar(128)", maxLength: 128, nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    DeleterUserId = table.Column<long>(type: "bigint", nullable: true),
                    DeletionTime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SIAML_OrganizationUnits", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SIAML_OrganizationUnits_SIAML_OrganizationUnits_ParentId",
                        column: x => x.ParentId,
                        principalTable: "SIAML_OrganizationUnits",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "SIAML_PersistedGrants",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    Type = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    SubjectId = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    SessionId = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    ClientId = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    Description = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Expiration = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ConsumedTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Data = table.Column<string>(type: "nvarchar(max)", maxLength: 50000, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SIAML_PersistedGrants", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "SIAML_RecentPasswords",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    TenantId = table.Column<int>(type: "int", nullable: true),
                    UserId = table.Column<long>(type: "bigint", nullable: false),
                    Password = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SIAML_RecentPasswords", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "SIAML_SubscriptionPaymentsExtensionData",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SubscriptionPaymentId = table.Column<long>(type: "bigint", nullable: false),
                    Key = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    Value = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SIAML_SubscriptionPaymentsExtensionData", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "SIAML_TenantNotifications",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    TenantId = table.Column<int>(type: "int", nullable: true),
                    NotificationName = table.Column<string>(type: "nvarchar(96)", maxLength: 96, nullable: false),
                    Data = table.Column<string>(type: "nvarchar(max)", maxLength: 1048576, nullable: true),
                    DataTypeName = table.Column<string>(type: "nvarchar(512)", maxLength: 512, nullable: true),
                    EntityTypeName = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: true),
                    EntityTypeAssemblyQualifiedName = table.Column<string>(type: "nvarchar(512)", maxLength: 512, nullable: true),
                    EntityId = table.Column<string>(type: "nvarchar(96)", maxLength: 96, nullable: true),
                    Severity = table.Column<byte>(type: "tinyint", nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SIAML_TenantNotifications", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "SIAML_UserAccounts",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TenantId = table.Column<int>(type: "int", nullable: true),
                    UserId = table.Column<long>(type: "bigint", nullable: false),
                    UserLinkId = table.Column<long>(type: "bigint", nullable: true),
                    UserName = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    EmailAddress = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    DeleterUserId = table.Column<long>(type: "bigint", nullable: true),
                    DeletionTime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SIAML_UserAccounts", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "SIAML_UserDelegations",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SourceUserId = table.Column<long>(type: "bigint", nullable: false),
                    TargetUserId = table.Column<long>(type: "bigint", nullable: false),
                    TenantId = table.Column<int>(type: "int", nullable: true),
                    StartTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    EndTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    DeleterUserId = table.Column<long>(type: "bigint", nullable: true),
                    DeletionTime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SIAML_UserDelegations", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "SIAML_UserLoginAttempts",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TenantId = table.Column<int>(type: "int", nullable: true),
                    TenancyName = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: true),
                    UserId = table.Column<long>(type: "bigint", nullable: true),
                    UserNameOrEmailAddress = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    ClientIpAddress = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: true),
                    ClientName = table.Column<string>(type: "nvarchar(128)", maxLength: 128, nullable: true),
                    BrowserInfo = table.Column<string>(type: "nvarchar(512)", maxLength: 512, nullable: true),
                    Result = table.Column<byte>(type: "tinyint", nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SIAML_UserLoginAttempts", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "SIAML_UserNotifications",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    TenantId = table.Column<int>(type: "int", nullable: true),
                    UserId = table.Column<long>(type: "bigint", nullable: false),
                    TenantNotificationId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    State = table.Column<int>(type: "int", nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    TargetNotifiers = table.Column<string>(type: "nvarchar(1024)", maxLength: 1024, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SIAML_UserNotifications", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "SIAML_Users",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ProfilePictureId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    ShouldChangePasswordOnNextLogin = table.Column<bool>(type: "bit", nullable: false),
                    SignInTokenExpireTimeUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    SignInToken = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    GoogleAuthenticatorKey = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    RecoveryCode = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    DeleterUserId = table.Column<long>(type: "bigint", nullable: true),
                    DeletionTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    AuthenticationSource = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: true),
                    UserName = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: false),
                    TenantId = table.Column<int>(type: "int", nullable: true),
                    EmailAddress = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: false),
                    Name = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: false),
                    Surname = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: false),
                    Password = table.Column<string>(type: "nvarchar(128)", maxLength: 128, nullable: false),
                    EmailConfirmationCode = table.Column<string>(type: "nvarchar(328)", maxLength: 328, nullable: true),
                    PasswordResetCode = table.Column<string>(type: "nvarchar(328)", maxLength: 328, nullable: true),
                    LockoutEndDateUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    AccessFailedCount = table.Column<int>(type: "int", nullable: false),
                    IsLockoutEnabled = table.Column<bool>(type: "bit", nullable: false),
                    PhoneNumber = table.Column<string>(type: "nvarchar(32)", maxLength: 32, nullable: true),
                    IsPhoneNumberConfirmed = table.Column<bool>(type: "bit", nullable: false),
                    SecurityStamp = table.Column<string>(type: "nvarchar(128)", maxLength: 128, nullable: true),
                    IsTwoFactorEnabled = table.Column<bool>(type: "bit", nullable: false),
                    IsEmailConfirmed = table.Column<bool>(type: "bit", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    NormalizedUserName = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: false),
                    NormalizedEmailAddress = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: false),
                    ConcurrencyStamp = table.Column<string>(type: "nvarchar(128)", maxLength: 128, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SIAML_Users", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SIAML_Users_SIAML_Users_CreatorUserId",
                        column: x => x.CreatorUserId,
                        principalTable: "SIAML_Users",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_SIAML_Users_SIAML_Users_DeleterUserId",
                        column: x => x.DeleterUserId,
                        principalTable: "SIAML_Users",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_SIAML_Users_SIAML_Users_LastModifierUserId",
                        column: x => x.LastModifierUserId,
                        principalTable: "SIAML_Users",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "SIAML_WebhookEvents",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    WebhookName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Data = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    TenantId = table.Column<int>(type: "int", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    DeletionTime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SIAML_WebhookEvents", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "SIAML_WebhookSubscriptions",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    TenantId = table.Column<int>(type: "int", nullable: true),
                    WebhookUri = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Secret = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    Webhooks = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Headers = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SIAML_WebhookSubscriptions", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Tbl_SubscriptionWorkflows",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TenantId = table.Column<int>(type: "int", nullable: true),
                    ClientType = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Title = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    MarketingConsent = table.Column<bool>(type: "bit", nullable: false),
                    DataPrivacy = table.Column<bool>(type: "bit", nullable: false),
                    IdIssueDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    FirstName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    OtherNames = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    FullName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    MaidenName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    MothersMaidenName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    EmployerId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Designation = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Gender = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Religion = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    MaritalStatus = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Nationality = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    StateOfOrigin = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    DateOfBirth = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Email = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CountryCode = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    MobilePhone = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CountryCodeOfficial = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    OfficialPhone = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NokTitle = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NokLastName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NokFirstName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NokOtherNames = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NokGender = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NokEmail = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NokCountryCode = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NokMobilePhone = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NokDateOfBirth = table.Column<DateTime>(type: "datetime2", nullable: true),
                    NokRelationship = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NokAddress = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NokAddress2 = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NokCity = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NokState = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NokCountry = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NotifySMS = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NotifyEmail = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NotifyPostal = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Bank = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    BankAccountName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    BankAccountNumber = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    BankAccountStatus = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Bvn = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    BvnLastName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    BvnFirstName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    BvnOtherNames = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    BvnMobilePhone = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    BvnDob = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    BvnStatus = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    StockBroker = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CSCSAccountNumber = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CHN = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    PFA = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    RsaPin = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Status = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    KYCStatusPassport = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    KYCStatusDates = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    KYCStatusIdMeans = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    KYCStatusAddressProof = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    KYCStatus = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    RecordSourceId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    RecordLocationId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    AgentId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    PromoId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    MarketingChannelId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ResidentialAddress = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ResidentialAddress2 = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ResidentialCity = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ResidentialState = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ResidentialCountry = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    MailingAddress = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    MailingAddress2 = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    MailingCity = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    MailingState = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    MailingCountry = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Passport = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Signature = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    IdType = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    IdNumber = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    IdExpiryDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ProofOfAddress = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: true),
                    ProofOfAddressType = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    WebStatus = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    WebPassCode = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    SubProfile = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    LinkId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    RelationshipId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    AdditionalInformation = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    SchoolId = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    SchoolClass = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    SchoolSession = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    SchoolSessionStart = table.Column<DateTime>(type: "datetime2", nullable: true),
                    StagingId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    InvestorId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    RegistrationDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    CreatedBy = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    DateCreated = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ConfirmedBy = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    DateConfirmed = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ApprovedBy = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    DateApproved = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastUpdatedBy = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    DateLastUpdated = table.Column<DateTime>(type: "datetime2", nullable: true),
                    WorkFlowType = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    TransRef = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    OrderId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    RecordId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ClientId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Amount = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    FundId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Tag = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Source = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    BeneficiaryName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    BeneficiaryAccount = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ValueDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ApprovalStatus = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Approver = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    AgentCode = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    PaymentMode = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    OfferPrice = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    SubscriberType = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    OnlineRedemption = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Units = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    TransId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    SalesOfficer = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ReceivedBy = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    MarketingSource = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    DividendPayment = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    EmailIdemnity = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    AdditionalFlag = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    OnboardingPlatform = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    PEP = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    CorporateNameOfInstitution = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateRCRegistrationNumber = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporatePlaceOfIncorporation = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    CorporateDateOfIncorporation = table.Column<DateTime>(type: "datetime2", nullable: true),
                    CorporateBusinessSector = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateBusinessType = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    PhoneNumber = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    CorporateLegalEntityType = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateWebsite = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateFaxNumber = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    CorporateEmailAddress = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateCountry = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateCity = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateState = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateBusinessAddress = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateStreetName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateAnnualTurnover = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    CorporateLocality = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateNameOfContactPerson = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateContactEmailAddress = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateDesignation = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Narration = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ReturnCode = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    JobType = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    UpdatedBy = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Comment = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ChildTitle = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    ChildGender = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    ChildSurname = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ChildFirstName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ChildMiddleName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ChildDateOfBirth = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ChildCountryOfBirth = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    IncomeRangePerAnnum = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Tin = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    NokMaritalStatus = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    PlaceOfIssue = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    OtherNationality = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    EmploymentStatus = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    LevelOfEducation = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    EmployerAddress = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    EmployerTelephone = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    EmployerFax = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    EmployerSegment = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    EmployerWebsite = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    EmployerName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    RiskCategory = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    RiskSubCategory = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CallOverStatus = table.Column<int>(type: "int", nullable: true),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    DeleterUserId = table.Column<long>(type: "bigint", nullable: true),
                    DeletionTime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tbl_SubscriptionWorkflows", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Tbl_WorkflowManagements",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    StaffId = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    DeleterUserId = table.Column<long>(type: "bigint", nullable: true),
                    DeletionTime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tbl_WorkflowManagements", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "SIAML_DynamicEntityProperties",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    EntityFullName = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    DynamicPropertyId = table.Column<int>(type: "int", nullable: false),
                    TenantId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SIAML_DynamicEntityProperties", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SIAML_DynamicEntityProperties_SIAML_DynamicProperties_DynamicPropertyId",
                        column: x => x.DynamicPropertyId,
                        principalTable: "SIAML_DynamicProperties",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "SIAML_DynamicPropertyValues",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Value = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    TenantId = table.Column<int>(type: "int", nullable: true),
                    DynamicPropertyId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SIAML_DynamicPropertyValues", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SIAML_DynamicPropertyValues_SIAML_DynamicProperties_DynamicPropertyId",
                        column: x => x.DynamicPropertyId,
                        principalTable: "SIAML_DynamicProperties",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AbpEditions",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false),
                    ExpiringEditionId = table.Column<int>(type: "int", nullable: true),
                    DailyPrice = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    WeeklyPrice = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    MonthlyPrice = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    AnnualPrice = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    TrialDayCount = table.Column<int>(type: "int", nullable: true),
                    WaitingDayAfterExpire = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AbpEditions", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AbpEditions_SIAML_Editions_Id",
                        column: x => x.Id,
                        principalTable: "SIAML_Editions",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "SIAML_Features",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TenantId = table.Column<int>(type: "int", nullable: true),
                    Name = table.Column<string>(type: "nvarchar(128)", maxLength: 128, nullable: false),
                    Value = table.Column<string>(type: "nvarchar(2000)", maxLength: 2000, nullable: false),
                    Discriminator = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    EditionId = table.Column<int>(type: "int", nullable: true),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SIAML_Features", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SIAML_Features_SIAML_Editions_EditionId",
                        column: x => x.EditionId,
                        principalTable: "SIAML_Editions",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "SIAML_SubscriptionPayments",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Gateway = table.Column<int>(type: "int", nullable: false),
                    Amount = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Status = table.Column<int>(type: "int", nullable: false),
                    EditionId = table.Column<int>(type: "int", nullable: false),
                    TenantId = table.Column<int>(type: "int", nullable: false),
                    DayCount = table.Column<int>(type: "int", nullable: false),
                    PaymentPeriodType = table.Column<int>(type: "int", nullable: true),
                    ExternalPaymentId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    InvoiceNo = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    IsRecurring = table.Column<bool>(type: "bit", nullable: false),
                    SuccessUrl = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ErrorUrl = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    EditionPaymentType = table.Column<int>(type: "int", nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    DeleterUserId = table.Column<long>(type: "bigint", nullable: true),
                    DeletionTime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SIAML_SubscriptionPayments", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SIAML_SubscriptionPayments_SIAML_Editions_EditionId",
                        column: x => x.EditionId,
                        principalTable: "SIAML_Editions",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "SIAML_EntityChanges",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ChangeTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ChangeType = table.Column<byte>(type: "tinyint", nullable: false),
                    EntityChangeSetId = table.Column<long>(type: "bigint", nullable: false),
                    EntityId = table.Column<string>(type: "nvarchar(48)", maxLength: 48, nullable: true),
                    EntityTypeFullName = table.Column<string>(type: "nvarchar(192)", maxLength: 192, nullable: true),
                    TenantId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SIAML_EntityChanges", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SIAML_EntityChanges_SIAML_EntityChangeSets_EntityChangeSetId",
                        column: x => x.EntityChangeSetId,
                        principalTable: "SIAML_EntityChangeSets",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "SIAML_Roles",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    DeleterUserId = table.Column<long>(type: "bigint", nullable: true),
                    DeletionTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    TenantId = table.Column<int>(type: "int", nullable: true),
                    Name = table.Column<string>(type: "nvarchar(32)", maxLength: 32, nullable: false),
                    DisplayName = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: false),
                    IsStatic = table.Column<bool>(type: "bit", nullable: false),
                    IsDefault = table.Column<bool>(type: "bit", nullable: false),
                    NormalizedName = table.Column<string>(type: "nvarchar(32)", maxLength: 32, nullable: false),
                    ConcurrencyStamp = table.Column<string>(type: "nvarchar(128)", maxLength: 128, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SIAML_Roles", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SIAML_Roles_SIAML_Users_CreatorUserId",
                        column: x => x.CreatorUserId,
                        principalTable: "SIAML_Users",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_SIAML_Roles_SIAML_Users_DeleterUserId",
                        column: x => x.DeleterUserId,
                        principalTable: "SIAML_Users",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_SIAML_Roles_SIAML_Users_LastModifierUserId",
                        column: x => x.LastModifierUserId,
                        principalTable: "SIAML_Users",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "SIAML_Settings",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TenantId = table.Column<int>(type: "int", nullable: true),
                    UserId = table.Column<long>(type: "bigint", nullable: true),
                    Name = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: false),
                    Value = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SIAML_Settings", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SIAML_Settings_SIAML_Users_UserId",
                        column: x => x.UserId,
                        principalTable: "SIAML_Users",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "SIAML_Tenants",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SubscriptionEndDateUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    IsInTrialPeriod = table.Column<bool>(type: "bit", nullable: false),
                    CustomCssId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    DarkLogoId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    DarkLogoFileType = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: true),
                    LightLogoId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    LightLogoFileType = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: true),
                    SubscriptionPaymentType = table.Column<int>(type: "int", nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    DeleterUserId = table.Column<long>(type: "bigint", nullable: true),
                    DeletionTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    TenancyName = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: false),
                    Name = table.Column<string>(type: "nvarchar(128)", maxLength: 128, nullable: false),
                    ConnectionString = table.Column<string>(type: "nvarchar(1024)", maxLength: 1024, nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    EditionId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SIAML_Tenants", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SIAML_Tenants_SIAML_Editions_EditionId",
                        column: x => x.EditionId,
                        principalTable: "SIAML_Editions",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_SIAML_Tenants_SIAML_Users_CreatorUserId",
                        column: x => x.CreatorUserId,
                        principalTable: "SIAML_Users",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_SIAML_Tenants_SIAML_Users_DeleterUserId",
                        column: x => x.DeleterUserId,
                        principalTable: "SIAML_Users",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_SIAML_Tenants_SIAML_Users_LastModifierUserId",
                        column: x => x.LastModifierUserId,
                        principalTable: "SIAML_Users",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "SIAML_UserClaims",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TenantId = table.Column<int>(type: "int", nullable: true),
                    UserId = table.Column<long>(type: "bigint", nullable: false),
                    ClaimType = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    ClaimValue = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SIAML_UserClaims", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SIAML_UserClaims_SIAML_Users_UserId",
                        column: x => x.UserId,
                        principalTable: "SIAML_Users",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "SIAML_UserLogins",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TenantId = table.Column<int>(type: "int", nullable: true),
                    UserId = table.Column<long>(type: "bigint", nullable: false),
                    LoginProvider = table.Column<string>(type: "nvarchar(128)", maxLength: 128, nullable: false),
                    ProviderKey = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SIAML_UserLogins", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SIAML_UserLogins_SIAML_Users_UserId",
                        column: x => x.UserId,
                        principalTable: "SIAML_Users",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "SIAML_UserOrganizationUnits",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TenantId = table.Column<int>(type: "int", nullable: true),
                    UserId = table.Column<long>(type: "bigint", nullable: false),
                    OrganizationUnitId = table.Column<long>(type: "bigint", nullable: false),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SIAML_UserOrganizationUnits", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SIAML_UserOrganizationUnits_SIAML_Users_UserId",
                        column: x => x.UserId,
                        principalTable: "SIAML_Users",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "SIAML_UserRoles",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TenantId = table.Column<int>(type: "int", nullable: true),
                    UserId = table.Column<long>(type: "bigint", nullable: false),
                    RoleId = table.Column<int>(type: "int", nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SIAML_UserRoles", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SIAML_UserRoles_SIAML_Users_UserId",
                        column: x => x.UserId,
                        principalTable: "SIAML_Users",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "SIAML_UserTokens",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TenantId = table.Column<int>(type: "int", nullable: true),
                    UserId = table.Column<long>(type: "bigint", nullable: false),
                    LoginProvider = table.Column<string>(type: "nvarchar(128)", maxLength: 128, nullable: true),
                    Name = table.Column<string>(type: "nvarchar(128)", maxLength: 128, nullable: true),
                    Value = table.Column<string>(type: "nvarchar(512)", maxLength: 512, nullable: true),
                    ExpireDate = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SIAML_UserTokens", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SIAML_UserTokens_SIAML_Users_UserId",
                        column: x => x.UserId,
                        principalTable: "SIAML_Users",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "SIAML_WebhookSendAttempts",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    WebhookEventId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    WebhookSubscriptionId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Response = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ResponseStatusCode = table.Column<int>(type: "int", nullable: true),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    TenantId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SIAML_WebhookSendAttempts", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SIAML_WebhookSendAttempts_SIAML_WebhookEvents_WebhookEventId",
                        column: x => x.WebhookEventId,
                        principalTable: "SIAML_WebhookEvents",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "SIAML_DynamicEntityPropertyValues",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Value = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    EntityId = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DynamicEntityPropertyId = table.Column<int>(type: "int", nullable: false),
                    TenantId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SIAML_DynamicEntityPropertyValues", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SIAML_DynamicEntityPropertyValues_SIAML_DynamicEntityProperties_DynamicEntityPropertyId",
                        column: x => x.DynamicEntityPropertyId,
                        principalTable: "SIAML_DynamicEntityProperties",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "SIAML_EntityPropertyChanges",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    EntityChangeId = table.Column<long>(type: "bigint", nullable: false),
                    NewValue = table.Column<string>(type: "nvarchar(512)", maxLength: 512, nullable: true),
                    OriginalValue = table.Column<string>(type: "nvarchar(512)", maxLength: 512, nullable: true),
                    PropertyName = table.Column<string>(type: "nvarchar(96)", maxLength: 96, nullable: true),
                    PropertyTypeFullName = table.Column<string>(type: "nvarchar(192)", maxLength: 192, nullable: true),
                    TenantId = table.Column<int>(type: "int", nullable: true),
                    NewValueHash = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    OriginalValueHash = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SIAML_EntityPropertyChanges", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SIAML_EntityPropertyChanges_SIAML_EntityChanges_EntityChangeId",
                        column: x => x.EntityChangeId,
                        principalTable: "SIAML_EntityChanges",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "SIAML_Permissions",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TenantId = table.Column<int>(type: "int", nullable: true),
                    Name = table.Column<string>(type: "nvarchar(128)", maxLength: 128, nullable: false),
                    IsGranted = table.Column<bool>(type: "bit", nullable: false),
                    Discriminator = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    RoleId = table.Column<int>(type: "int", nullable: true),
                    UserId = table.Column<long>(type: "bigint", nullable: true),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SIAML_Permissions", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SIAML_Permissions_SIAML_Roles_RoleId",
                        column: x => x.RoleId,
                        principalTable: "SIAML_Roles",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_SIAML_Permissions_SIAML_Users_UserId",
                        column: x => x.UserId,
                        principalTable: "SIAML_Users",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "SIAML_RoleClaims",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TenantId = table.Column<int>(type: "int", nullable: true),
                    RoleId = table.Column<int>(type: "int", nullable: false),
                    ClaimType = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    ClaimValue = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SIAML_RoleClaims", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SIAML_RoleClaims_SIAML_Roles_RoleId",
                        column: x => x.RoleId,
                        principalTable: "SIAML_Roles",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_AuditLogs_TenantId_ExecutionDuration",
                table: "SIAML_AuditLogs",
                columns: new[] { "TenantId", "ExecutionDuration" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_AuditLogs_TenantId_ExecutionTime",
                table: "SIAML_AuditLogs",
                columns: new[] { "TenantId", "ExecutionTime" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_AuditLogs_TenantId_UserId",
                table: "SIAML_AuditLogs",
                columns: new[] { "TenantId", "UserId" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_BackgroundJobs_IsAbandoned_NextTryTime",
                table: "SIAML_BackgroundJobs",
                columns: new[] { "IsAbandoned", "NextTryTime" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_BinaryObjects_TenantId",
                table: "SIAML_BinaryObjects",
                column: "TenantId");

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_ChatMessages_TargetTenantId_TargetUserId_ReadState",
                table: "SIAML_ChatMessages",
                columns: new[] { "TargetTenantId", "TargetUserId", "ReadState" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_ChatMessages_TargetTenantId_UserId_ReadState",
                table: "SIAML_ChatMessages",
                columns: new[] { "TargetTenantId", "UserId", "ReadState" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_ChatMessages_TenantId_TargetUserId_ReadState",
                table: "SIAML_ChatMessages",
                columns: new[] { "TenantId", "TargetUserId", "ReadState" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_ChatMessages_TenantId_UserId_ReadState",
                table: "SIAML_ChatMessages",
                columns: new[] { "TenantId", "UserId", "ReadState" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_DynamicEntityProperties_DynamicPropertyId",
                table: "SIAML_DynamicEntityProperties",
                column: "DynamicPropertyId");

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_DynamicEntityProperties_EntityFullName_DynamicPropertyId_TenantId",
                table: "SIAML_DynamicEntityProperties",
                columns: new[] { "EntityFullName", "DynamicPropertyId", "TenantId" },
                unique: true,
                filter: "[EntityFullName] IS NOT NULL AND [TenantId] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_DynamicEntityPropertyValues_DynamicEntityPropertyId",
                table: "SIAML_DynamicEntityPropertyValues",
                column: "DynamicEntityPropertyId");

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_DynamicProperties_PropertyName_TenantId",
                table: "SIAML_DynamicProperties",
                columns: new[] { "PropertyName", "TenantId" },
                unique: true,
                filter: "[PropertyName] IS NOT NULL AND [TenantId] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_DynamicPropertyValues_DynamicPropertyId",
                table: "SIAML_DynamicPropertyValues",
                column: "DynamicPropertyId");

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_EntityChanges_EntityChangeSetId",
                table: "SIAML_EntityChanges",
                column: "EntityChangeSetId");

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_EntityChanges_EntityTypeFullName_EntityId",
                table: "SIAML_EntityChanges",
                columns: new[] { "EntityTypeFullName", "EntityId" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_EntityChangeSets_TenantId_CreationTime",
                table: "SIAML_EntityChangeSets",
                columns: new[] { "TenantId", "CreationTime" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_EntityChangeSets_TenantId_Reason",
                table: "SIAML_EntityChangeSets",
                columns: new[] { "TenantId", "Reason" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_EntityChangeSets_TenantId_UserId",
                table: "SIAML_EntityChangeSets",
                columns: new[] { "TenantId", "UserId" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_EntityPropertyChanges_EntityChangeId",
                table: "SIAML_EntityPropertyChanges",
                column: "EntityChangeId");

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_Features_EditionId_Name",
                table: "SIAML_Features",
                columns: new[] { "EditionId", "Name" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_Features_TenantId_Name",
                table: "SIAML_Features",
                columns: new[] { "TenantId", "Name" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_Friendships_FriendTenantId_FriendUserId",
                table: "SIAML_Friendships",
                columns: new[] { "FriendTenantId", "FriendUserId" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_Friendships_FriendTenantId_UserId",
                table: "SIAML_Friendships",
                columns: new[] { "FriendTenantId", "UserId" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_Friendships_TenantId_FriendUserId",
                table: "SIAML_Friendships",
                columns: new[] { "TenantId", "FriendUserId" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_Friendships_TenantId_UserId",
                table: "SIAML_Friendships",
                columns: new[] { "TenantId", "UserId" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_Languages_TenantId_Name",
                table: "SIAML_Languages",
                columns: new[] { "TenantId", "Name" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_LanguageTexts_TenantId_Source_LanguageName_Key",
                table: "SIAML_LanguageTexts",
                columns: new[] { "TenantId", "Source", "LanguageName", "Key" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_NotificationSubscriptions_NotificationName_EntityTypeName_EntityId_UserId",
                table: "SIAML_NotificationSubscriptions",
                columns: new[] { "NotificationName", "EntityTypeName", "EntityId", "UserId" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_NotificationSubscriptions_TenantId_NotificationName_EntityTypeName_EntityId_UserId",
                table: "SIAML_NotificationSubscriptions",
                columns: new[] { "TenantId", "NotificationName", "EntityTypeName", "EntityId", "UserId" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_OrganizationUnitRoles_TenantId_OrganizationUnitId",
                table: "SIAML_OrganizationUnitRoles",
                columns: new[] { "TenantId", "OrganizationUnitId" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_OrganizationUnitRoles_TenantId_RoleId",
                table: "SIAML_OrganizationUnitRoles",
                columns: new[] { "TenantId", "RoleId" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_OrganizationUnits_ParentId",
                table: "SIAML_OrganizationUnits",
                column: "ParentId");

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_OrganizationUnits_TenantId_Code",
                table: "SIAML_OrganizationUnits",
                columns: new[] { "TenantId", "Code" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_Permissions_RoleId",
                table: "SIAML_Permissions",
                column: "RoleId");

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_Permissions_TenantId_Name",
                table: "SIAML_Permissions",
                columns: new[] { "TenantId", "Name" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_Permissions_UserId",
                table: "SIAML_Permissions",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_PersistedGrants_Expiration",
                table: "SIAML_PersistedGrants",
                column: "Expiration");

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_PersistedGrants_SubjectId_ClientId_Type",
                table: "SIAML_PersistedGrants",
                columns: new[] { "SubjectId", "ClientId", "Type" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_PersistedGrants_SubjectId_SessionId_Type",
                table: "SIAML_PersistedGrants",
                columns: new[] { "SubjectId", "SessionId", "Type" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_RoleClaims_RoleId",
                table: "SIAML_RoleClaims",
                column: "RoleId");

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_RoleClaims_TenantId_ClaimType",
                table: "SIAML_RoleClaims",
                columns: new[] { "TenantId", "ClaimType" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_Roles_CreatorUserId",
                table: "SIAML_Roles",
                column: "CreatorUserId");

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_Roles_DeleterUserId",
                table: "SIAML_Roles",
                column: "DeleterUserId");

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_Roles_LastModifierUserId",
                table: "SIAML_Roles",
                column: "LastModifierUserId");

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_Roles_TenantId_NormalizedName",
                table: "SIAML_Roles",
                columns: new[] { "TenantId", "NormalizedName" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_Settings_TenantId_Name_UserId",
                table: "SIAML_Settings",
                columns: new[] { "TenantId", "Name", "UserId" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_Settings_UserId",
                table: "SIAML_Settings",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_SubscriptionPayments_EditionId",
                table: "SIAML_SubscriptionPayments",
                column: "EditionId");

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_SubscriptionPayments_ExternalPaymentId_Gateway",
                table: "SIAML_SubscriptionPayments",
                columns: new[] { "ExternalPaymentId", "Gateway" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_SubscriptionPayments_Status_CreationTime",
                table: "SIAML_SubscriptionPayments",
                columns: new[] { "Status", "CreationTime" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_SubscriptionPaymentsExtensionData_SubscriptionPaymentId_Key_IsDeleted",
                table: "SIAML_SubscriptionPaymentsExtensionData",
                columns: new[] { "SubscriptionPaymentId", "Key", "IsDeleted" },
                unique: true,
                filter: "[IsDeleted] = 0");

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_TenantNotifications_TenantId",
                table: "SIAML_TenantNotifications",
                column: "TenantId");

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_Tenants_CreationTime",
                table: "SIAML_Tenants",
                column: "CreationTime");

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_Tenants_CreatorUserId",
                table: "SIAML_Tenants",
                column: "CreatorUserId");

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_Tenants_DeleterUserId",
                table: "SIAML_Tenants",
                column: "DeleterUserId");

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_Tenants_EditionId",
                table: "SIAML_Tenants",
                column: "EditionId");

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_Tenants_LastModifierUserId",
                table: "SIAML_Tenants",
                column: "LastModifierUserId");

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_Tenants_SubscriptionEndDateUtc",
                table: "SIAML_Tenants",
                column: "SubscriptionEndDateUtc");

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_Tenants_TenancyName",
                table: "SIAML_Tenants",
                column: "TenancyName");

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_UserAccounts_EmailAddress",
                table: "SIAML_UserAccounts",
                column: "EmailAddress");

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_UserAccounts_TenantId_EmailAddress",
                table: "SIAML_UserAccounts",
                columns: new[] { "TenantId", "EmailAddress" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_UserAccounts_TenantId_UserId",
                table: "SIAML_UserAccounts",
                columns: new[] { "TenantId", "UserId" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_UserAccounts_TenantId_UserName",
                table: "SIAML_UserAccounts",
                columns: new[] { "TenantId", "UserName" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_UserAccounts_UserName",
                table: "SIAML_UserAccounts",
                column: "UserName");

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_UserClaims_TenantId_ClaimType",
                table: "SIAML_UserClaims",
                columns: new[] { "TenantId", "ClaimType" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_UserClaims_UserId",
                table: "SIAML_UserClaims",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_UserDelegations_TenantId_SourceUserId",
                table: "SIAML_UserDelegations",
                columns: new[] { "TenantId", "SourceUserId" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_UserDelegations_TenantId_TargetUserId",
                table: "SIAML_UserDelegations",
                columns: new[] { "TenantId", "TargetUserId" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_UserLoginAttempts_TenancyName_UserNameOrEmailAddress_Result",
                table: "SIAML_UserLoginAttempts",
                columns: new[] { "TenancyName", "UserNameOrEmailAddress", "Result" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_UserLoginAttempts_UserId_TenantId",
                table: "SIAML_UserLoginAttempts",
                columns: new[] { "UserId", "TenantId" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_UserLogins_ProviderKey_TenantId",
                table: "SIAML_UserLogins",
                columns: new[] { "ProviderKey", "TenantId" },
                unique: true,
                filter: "[TenantId] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_UserLogins_TenantId_LoginProvider_ProviderKey",
                table: "SIAML_UserLogins",
                columns: new[] { "TenantId", "LoginProvider", "ProviderKey" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_UserLogins_TenantId_UserId",
                table: "SIAML_UserLogins",
                columns: new[] { "TenantId", "UserId" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_UserLogins_UserId",
                table: "SIAML_UserLogins",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_UserNotifications_UserId_State_CreationTime",
                table: "SIAML_UserNotifications",
                columns: new[] { "UserId", "State", "CreationTime" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_UserOrganizationUnits_TenantId_OrganizationUnitId",
                table: "SIAML_UserOrganizationUnits",
                columns: new[] { "TenantId", "OrganizationUnitId" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_UserOrganizationUnits_TenantId_UserId",
                table: "SIAML_UserOrganizationUnits",
                columns: new[] { "TenantId", "UserId" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_UserOrganizationUnits_UserId",
                table: "SIAML_UserOrganizationUnits",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_UserRoles_TenantId_RoleId",
                table: "SIAML_UserRoles",
                columns: new[] { "TenantId", "RoleId" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_UserRoles_TenantId_UserId",
                table: "SIAML_UserRoles",
                columns: new[] { "TenantId", "UserId" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_UserRoles_UserId",
                table: "SIAML_UserRoles",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_Users_CreatorUserId",
                table: "SIAML_Users",
                column: "CreatorUserId");

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_Users_DeleterUserId",
                table: "SIAML_Users",
                column: "DeleterUserId");

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_Users_LastModifierUserId",
                table: "SIAML_Users",
                column: "LastModifierUserId");

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_Users_TenantId_NormalizedEmailAddress",
                table: "SIAML_Users",
                columns: new[] { "TenantId", "NormalizedEmailAddress" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_Users_TenantId_NormalizedUserName",
                table: "SIAML_Users",
                columns: new[] { "TenantId", "NormalizedUserName" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_UserTokens_TenantId_UserId",
                table: "SIAML_UserTokens",
                columns: new[] { "TenantId", "UserId" });

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_UserTokens_UserId",
                table: "SIAML_UserTokens",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_SIAML_WebhookSendAttempts_WebhookEventId",
                table: "SIAML_WebhookSendAttempts",
                column: "WebhookEventId");

            migrationBuilder.CreateIndex(
                name: "IX_Tbl_SubscriptionWorkflows_TenantId",
                table: "Tbl_SubscriptionWorkflows",
                column: "TenantId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "AbpEditions");

            migrationBuilder.DropTable(
                name: "SIAML_AuditLogs");

            migrationBuilder.DropTable(
                name: "SIAML_BackgroundJobs");

            migrationBuilder.DropTable(
                name: "SIAML_BinaryObjects");

            migrationBuilder.DropTable(
                name: "SIAML_ChatMessages");

            migrationBuilder.DropTable(
                name: "SIAML_DynamicEntityPropertyValues");

            migrationBuilder.DropTable(
                name: "SIAML_DynamicPropertyValues");

            migrationBuilder.DropTable(
                name: "SIAML_EntityPropertyChanges");

            migrationBuilder.DropTable(
                name: "SIAML_Features");

            migrationBuilder.DropTable(
                name: "SIAML_Friendships");

            migrationBuilder.DropTable(
                name: "SIAML_Invoices");

            migrationBuilder.DropTable(
                name: "SIAML_Languages");

            migrationBuilder.DropTable(
                name: "SIAML_LanguageTexts");

            migrationBuilder.DropTable(
                name: "SIAML_Notifications");

            migrationBuilder.DropTable(
                name: "SIAML_NotificationSubscriptions");

            migrationBuilder.DropTable(
                name: "SIAML_OrganizationUnitRoles");

            migrationBuilder.DropTable(
                name: "SIAML_OrganizationUnits");

            migrationBuilder.DropTable(
                name: "SIAML_Permissions");

            migrationBuilder.DropTable(
                name: "SIAML_PersistedGrants");

            migrationBuilder.DropTable(
                name: "SIAML_RecentPasswords");

            migrationBuilder.DropTable(
                name: "SIAML_RoleClaims");

            migrationBuilder.DropTable(
                name: "SIAML_Settings");

            migrationBuilder.DropTable(
                name: "SIAML_SubscriptionPayments");

            migrationBuilder.DropTable(
                name: "SIAML_SubscriptionPaymentsExtensionData");

            migrationBuilder.DropTable(
                name: "SIAML_TenantNotifications");

            migrationBuilder.DropTable(
                name: "SIAML_Tenants");

            migrationBuilder.DropTable(
                name: "SIAML_UserAccounts");

            migrationBuilder.DropTable(
                name: "SIAML_UserClaims");

            migrationBuilder.DropTable(
                name: "SIAML_UserDelegations");

            migrationBuilder.DropTable(
                name: "SIAML_UserLoginAttempts");

            migrationBuilder.DropTable(
                name: "SIAML_UserLogins");

            migrationBuilder.DropTable(
                name: "SIAML_UserNotifications");

            migrationBuilder.DropTable(
                name: "SIAML_UserOrganizationUnits");

            migrationBuilder.DropTable(
                name: "SIAML_UserRoles");

            migrationBuilder.DropTable(
                name: "SIAML_UserTokens");

            migrationBuilder.DropTable(
                name: "SIAML_WebhookSendAttempts");

            migrationBuilder.DropTable(
                name: "SIAML_WebhookSubscriptions");

            migrationBuilder.DropTable(
                name: "Tbl_SubscriptionWorkflows");

            migrationBuilder.DropTable(
                name: "Tbl_WorkflowManagements");

            migrationBuilder.DropTable(
                name: "SIAML_DynamicEntityProperties");

            migrationBuilder.DropTable(
                name: "SIAML_EntityChanges");

            migrationBuilder.DropTable(
                name: "SIAML_Roles");

            migrationBuilder.DropTable(
                name: "SIAML_Editions");

            migrationBuilder.DropTable(
                name: "SIAML_WebhookEvents");

            migrationBuilder.DropTable(
                name: "SIAML_DynamicProperties");

            migrationBuilder.DropTable(
                name: "SIAML_EntityChangeSets");

            migrationBuilder.DropTable(
                name: "SIAML_Users");
        }
    }
}
