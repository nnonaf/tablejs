﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SIAML.Middleware.Migrations
{
    /// <inheritdoc />
    public partial class MofifiedOnboardingEntityBrd2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "BankAccountNameMismatchComment",
                table: "Tbl_OnboardingSubscriptionDirectors",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Bvn",
                table: "Tbl_OnboardingSubscriptionDirectors",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "BvnDob",
                table: "Tbl_OnboardingSubscriptionDirectors",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "BvnFirstName",
                table: "Tbl_OnboardingSubscriptionDirectors",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "BvnLastName",
                table: "Tbl_OnboardingSubscriptionDirectors",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "BvnMobilePhone",
                table: "Tbl_OnboardingSubscriptionDirectors",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "BvnNameMismatchComment",
                table: "Tbl_OnboardingSubscriptionDirectors",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "BvnOtherNames",
                table: "Tbl_OnboardingSubscriptionDirectors",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "BvnStatus",
                table: "Tbl_OnboardingSubscriptionDirectors",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "GoogleSearchUpload",
                table: "Tbl_OnboardingSubscriptionDirectors",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "SafeWatchUpload",
                table: "Tbl_OnboardingSubscriptionDirectors",
                type: "uniqueidentifier",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "BankAccountNameMismatchComment",
                table: "Tbl_OnboardingSubscriptionDirectors");

            migrationBuilder.DropColumn(
                name: "Bvn",
                table: "Tbl_OnboardingSubscriptionDirectors");

            migrationBuilder.DropColumn(
                name: "BvnDob",
                table: "Tbl_OnboardingSubscriptionDirectors");

            migrationBuilder.DropColumn(
                name: "BvnFirstName",
                table: "Tbl_OnboardingSubscriptionDirectors");

            migrationBuilder.DropColumn(
                name: "BvnLastName",
                table: "Tbl_OnboardingSubscriptionDirectors");

            migrationBuilder.DropColumn(
                name: "BvnMobilePhone",
                table: "Tbl_OnboardingSubscriptionDirectors");

            migrationBuilder.DropColumn(
                name: "BvnNameMismatchComment",
                table: "Tbl_OnboardingSubscriptionDirectors");

            migrationBuilder.DropColumn(
                name: "BvnOtherNames",
                table: "Tbl_OnboardingSubscriptionDirectors");

            migrationBuilder.DropColumn(
                name: "BvnStatus",
                table: "Tbl_OnboardingSubscriptionDirectors");

            migrationBuilder.DropColumn(
                name: "GoogleSearchUpload",
                table: "Tbl_OnboardingSubscriptionDirectors");

            migrationBuilder.DropColumn(
                name: "SafeWatchUpload",
                table: "Tbl_OnboardingSubscriptionDirectors");
        }
    }
}
