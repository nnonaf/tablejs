﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SIAML.Middleware.Migrations
{
    /// <inheritdoc />
    public partial class AddedOnboardingSubscriptionEntities : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Client_Tbl_Countries_Country_Code",
                table: "Client");

            migrationBuilder.DropForeignKey(
                name: "FK_Client_Tbl_Countries_Country_Code_Official",
                table: "Client");

            migrationBuilder.DropForeignKey(
                name: "FK_Client_Tbl_Countries_Nok_Country_Code",
                table: "Client");

            migrationBuilder.DropForeignKey(
                name: "FK_Client_Tbl_Countries_State_Of_Origin",
                table: "Client");

            migrationBuilder.DropForeignKey(
                name: "FK_Client_Tbl_SubscriptionTypes_ClientType",
                table: "Client");

            migrationBuilder.DropIndex(
                name: "IX_Client_Country_Code",
                table: "Client");

            migrationBuilder.DropIndex(
                name: "IX_Client_Country_Code_Official",
                table: "Client");

            migrationBuilder.DropIndex(
                name: "IX_Client_Nok_Country_Code",
                table: "Client");

            migrationBuilder.RenameColumn(
                name: "NotifySMS",
                table: "Client",
                newName: "NotifySms");

            migrationBuilder.RenameColumn(
                name: "CreatedBy",
                table: "Client",
                newName: "Created_By");

            migrationBuilder.RenameColumn(
                name: "ClientType",
                table: "Client",
                newName: "ManageSubscriptionTypeId");

            migrationBuilder.RenameIndex(
                name: "IX_Client_ClientType",
                table: "Client",
                newName: "IX_Client_ManageSubscriptionTypeId");

            migrationBuilder.AlterColumn<string>(
                name: "CurrencyMnemonic",
                table: "ManageCurrencies",
                type: "nvarchar(3)",
                maxLength: 3,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(5)",
                oldMaxLength: 5);

            migrationBuilder.AlterColumn<int>(
                name: "StockBroker",
                table: "Client",
                type: "int",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<long>(
                name: "SalesOfficer",
                table: "Client",
                type: "bigint",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "RiskSubCategory",
                table: "Client",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "RiskCategory",
                table: "Client",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "ResidentialState",
                table: "Client",
                type: "int",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "ResidentialCountry",
                table: "Client",
                type: "int",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "ResidentialCity",
                table: "Client",
                type: "int",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "Religion",
                table: "Client",
                type: "int",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "RelationshipId",
                table: "Client",
                type: "int",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "PaymentMode",
                table: "Client",
                type: "int",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "PEP",
                table: "Client",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(string),
                oldType: "nvarchar(200)",
                oldMaxLength: 200,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "OtherNationality",
                table: "Client",
                type: "int",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "OnlineRedemption",
                table: "Client",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "OnboardingPlatform",
                table: "Client",
                type: "int",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<bool>(
                name: "NotifySms",
                table: "Client",
                type: "bit",
                nullable: false,
                defaultValue: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<bool>(
                name: "NotifyPostal",
                table: "Client",
                type: "bit",
                nullable: false,
                defaultValue: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<bool>(
                name: "NotifyEmail",
                table: "Client",
                type: "bit",
                nullable: false,
                defaultValue: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Nok_Country_Code",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "NokState",
                table: "Client",
                type: "int",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "NokRelationship",
                table: "Client",
                type: "int",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "NokMaritalStatus",
                table: "Client",
                type: "int",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "NokCountry",
                table: "Client",
                type: "int",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "NokCity",
                table: "Client",
                type: "nvarchar(250)",
                maxLength: 250,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "MarketingChannelId",
                table: "Client",
                type: "int",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "MailingCountry",
                table: "Client",
                type: "int",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "KYCStatus",
                table: "Client",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "JobType",
                table: "Client",
                type: "int",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "IdType",
                table: "Client",
                type: "int",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "Gender",
                table: "Client",
                type: "int",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "FundId",
                table: "Client",
                type: "int",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "EmploymentStatus",
                table: "Client",
                type: "int",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "EmailIdemnity",
                table: "Client",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Country_Code_Official",
                table: "Client",
                type: "nvarchar(150)",
                maxLength: 150,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Country_Code",
                table: "Client",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "CorporateState",
                table: "Client",
                type: "int",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "CorporateCountry",
                table: "Client",
                type: "int",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "CorporateBusinessSector",
                table: "Client",
                type: "int",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "ChildTitle",
                table: "Client",
                type: "int",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(200)",
                oldMaxLength: 200,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "ChildGender",
                table: "Client",
                type: "int",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(200)",
                oldMaxLength: 200,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "ChildCountryOfBirth",
                table: "Client",
                type: "int",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "CallOverStatus",
                table: "Client",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "Bank",
                table: "Client",
                type: "int",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "AllDocumentsUpload",
                table: "Client",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "CountryOfBirth",
                table: "Client",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "EvidencePaymentUpload",
                table: "Client",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "MarketOtherConsent",
                table: "Client",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<Guid>(
                name: "PassportPhotographUpload",
                table: "Client",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "ProofOfAddressUpload",
                table: "Client",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "ProofOfIdentityUpload",
                table: "Client",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "PurchaseOrderUpload",
                table: "Client",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "ResearchConsent",
                table: "Client",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.CreateTable(
                name: "Tbl_Town",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TownName = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: false),
                    StateId = table.Column<int>(type: "int", nullable: true),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    DeleterUserId = table.Column<long>(type: "bigint", nullable: true),
                    DeletionTime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tbl_Town", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Tbl_Town_Tbl_States_StateId",
                        column: x => x.StateId,
                        principalTable: "Tbl_States",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "ClientWorkPad",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TenantId = table.Column<int>(type: "int", nullable: true),
                    MarketingConsent = table.Column<bool>(type: "bit", nullable: false),
                    DataPrivacy = table.Column<bool>(type: "bit", nullable: false),
                    IdIssueDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    FirstName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    OtherNames = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    FullName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    MaidenName = table.Column<string>(name: "Maiden_Name", type: "nvarchar(500)", maxLength: 500, nullable: true),
                    MothersMaidenName = table.Column<string>(name: "Mothers_Maiden_Name", type: "nvarchar(500)", maxLength: 500, nullable: true),
                    EmployerId = table.Column<string>(name: "Employer_Id", type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Designation = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    DateOfBirth = table.Column<DateTime>(name: "Date_Of_Birth", type: "datetime2", nullable: true),
                    Email = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    MobilePhone = table.Column<string>(name: "Mobile_Phone", type: "nvarchar(500)", maxLength: 500, nullable: true),
                    OfficialPhone = table.Column<string>(name: "Official_Phone", type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NokLastName = table.Column<string>(name: "Nok_LastName", type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NokFirstName = table.Column<string>(name: "Nok_FirstName", type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NokOtherNames = table.Column<string>(name: "Nok_OtherNames", type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NokEmail = table.Column<string>(name: "Nok_Email", type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NokMobilePhone = table.Column<string>(name: "Nok_Mobile_Phone", type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NokDateOfBirth = table.Column<DateTime>(name: "Nok_Date_Of_Birth", type: "datetime2", nullable: true),
                    NokAddress = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NokAddress2 = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    NotifySms = table.Column<bool>(type: "bit", nullable: false),
                    NotifyEmail = table.Column<bool>(type: "bit", nullable: false),
                    NotifyPostal = table.Column<bool>(type: "bit", nullable: false),
                    BankAccountName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    BankAccountNumber = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    BankAccountStatus = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Bvn = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    BvnLastName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    BvnFirstName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    BvnOtherNames = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    BvnMobilePhone = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    BvnDob = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    BvnStatus = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CSCSAccountNumber = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CHN = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    PFA = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    RsaPin = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Status = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    KYCStatusPassport = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    KYCStatusDates = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    KYCStatusIdMeans = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    KYCStatusAddressProof = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    KYCStatus = table.Column<int>(type: "int", nullable: false),
                    RecordSourceId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    RecordLocationId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    AgentId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    PromoId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ResidentialAddress = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ResidentialAddress2 = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    MailingAddress = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    MailingAddress2 = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    MailingCity = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    MailingState = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Passport = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Signature = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    IdNumber = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    IdExpiryDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ProofOfAddress = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: true),
                    ProofOfAddressType = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    WebStatus = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    WebPassCode = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    SubProfile = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    LinkId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    AdditionalInformation = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    SchoolId = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    SchoolClass = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    SchoolSession = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    SchoolSessionStart = table.Column<DateTime>(type: "datetime2", nullable: true),
                    StagingId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    InvestorId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    RegistrationDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    CreatedBy = table.Column<string>(name: "Created_By", type: "nvarchar(500)", maxLength: 500, nullable: true),
                    DateCreated = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ConfirmedBy = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    DateConfirmed = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ApprovedBy = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    DateApproved = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastUpdatedBy = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    DateLastUpdated = table.Column<DateTime>(type: "datetime2", nullable: true),
                    WorkFlowType = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    TransRef = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    OrderId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    RecordId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ClientId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Amount = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    Tag = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Source = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    BeneficiaryName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    BeneficiaryAccount = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ValueDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ApprovalStatus = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Approver = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    AgentCode = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    OfferPrice = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    SubscriberType = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    OnlineRedemption = table.Column<int>(type: "int", nullable: false),
                    Units = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    TransId = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ReceivedBy = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    MarketingSource = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    DividendPayment = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    EmailIdemnity = table.Column<int>(type: "int", nullable: false),
                    AdditionalFlag = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    PEP = table.Column<int>(type: "int", nullable: false),
                    CorporateNameOfInstitution = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateRCRegistrationNumber = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporatePlaceOfIncorporation = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    CorporateDateOfIncorporation = table.Column<DateTime>(type: "datetime2", nullable: true),
                    CorporateBusinessType = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    PhoneNumber = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    CorporateLegalEntityType = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateWebsite = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateFaxNumber = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    CorporateEmailAddress = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateCity = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateBusinessAddress = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateStreetName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateAnnualTurnover = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    CorporateLocality = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateNameOfContactPerson = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateContactEmailAddress = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorporateDesignation = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Narration = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ReturnCode = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    UpdatedBy = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Comment = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ChildSurname = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ChildFirstName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ChildMiddleName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ChildDateOfBirth = table.Column<DateTime>(type: "datetime2", nullable: true),
                    IncomeRangePerAnnum = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Tin = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    PlaceOfIssue = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    LevelOfEducation = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    EmployerAddress = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    EmployerTelephone = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    EmployerFax = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    EmployerSegment = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    EmployerWebsite = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    EmployerName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    RiskCategory = table.Column<int>(type: "int", nullable: false),
                    RiskSubCategory = table.Column<int>(type: "int", nullable: false),
                    CallOverStatus = table.Column<int>(type: "int", nullable: false),
                    NokCity = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: true),
                    CountryCode = table.Column<string>(name: "Country_Code", type: "nvarchar(100)", maxLength: 100, nullable: true),
                    CountryCodeOfficial = table.Column<string>(name: "Country_Code_Official", type: "nvarchar(150)", maxLength: 150, nullable: true),
                    NokCountryCode = table.Column<string>(name: "Nok_Country_Code", type: "nvarchar(100)", maxLength: 100, nullable: true),
                    ResearchConsent = table.Column<bool>(type: "bit", nullable: false),
                    MarketOtherConsent = table.Column<bool>(type: "bit", nullable: false),
                    ManageSubscriptionTypeId = table.Column<int>(type: "int", nullable: false),
                    Title = table.Column<int>(type: "int", nullable: true),
                    MaritalStatus = table.Column<int>(name: "Marital_Status", type: "int", nullable: true),
                    Nationality = table.Column<int>(type: "int", nullable: true),
                    StateOfOrigin = table.Column<int>(name: "State_Of_Origin", type: "int", nullable: true),
                    NokTitle = table.Column<int>(name: "Nok_Title", type: "int", nullable: true),
                    NokGender = table.Column<int>(name: "Nok_Gender", type: "int", nullable: true),
                    NokCountry = table.Column<int>(type: "int", nullable: true),
                    NokState = table.Column<int>(type: "int", nullable: true),
                    NokRelationship = table.Column<int>(type: "int", nullable: true),
                    ResidentialState = table.Column<int>(type: "int", nullable: true),
                    MarketingChannelId = table.Column<int>(type: "int", nullable: true),
                    Gender = table.Column<int>(type: "int", nullable: true),
                    Religion = table.Column<int>(type: "int", nullable: true),
                    Bank = table.Column<int>(type: "int", nullable: true),
                    ResidentialCountry = table.Column<int>(type: "int", nullable: true),
                    IdType = table.Column<int>(type: "int", nullable: true),
                    MailingCountry = table.Column<int>(type: "int", nullable: true),
                    PaymentMode = table.Column<int>(type: "int", nullable: true),
                    EmploymentStatus = table.Column<int>(type: "int", nullable: true),
                    NokMaritalStatus = table.Column<int>(type: "int", nullable: true),
                    JobType = table.Column<int>(type: "int", nullable: true),
                    StockBroker = table.Column<int>(type: "int", nullable: true),
                    RelationshipId = table.Column<int>(type: "int", nullable: true),
                    FundId = table.Column<int>(type: "int", nullable: true),
                    CorporateBusinessSector = table.Column<int>(type: "int", nullable: true),
                    CorporateCountry = table.Column<int>(type: "int", nullable: true),
                    CorporateState = table.Column<int>(type: "int", nullable: true),
                    ChildTitle = table.Column<int>(type: "int", nullable: true),
                    ChildGender = table.Column<int>(type: "int", nullable: true),
                    ChildCountryOfBirth = table.Column<int>(type: "int", nullable: true),
                    OtherNationality = table.Column<int>(type: "int", nullable: true),
                    OnboardingPlatform = table.Column<int>(type: "int", nullable: true),
                    SalesOfficer = table.Column<long>(type: "bigint", nullable: true),
                    ResidentialCity = table.Column<int>(type: "int", nullable: true),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    DeleterUserId = table.Column<long>(type: "bigint", nullable: true),
                    DeletionTime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ClientWorkPad", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ClientWorkPad_SIAML_Users_SalesOfficer",
                        column: x => x.SalesOfficer,
                        principalTable: "SIAML_Users",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientWorkPad_Tbl_Banks_Bank",
                        column: x => x.Bank,
                        principalTable: "Tbl_Banks",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientWorkPad_Tbl_Countries_ChildCountryOfBirth",
                        column: x => x.ChildCountryOfBirth,
                        principalTable: "Tbl_Countries",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientWorkPad_Tbl_Countries_CorporateCountry",
                        column: x => x.CorporateCountry,
                        principalTable: "Tbl_Countries",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientWorkPad_Tbl_Countries_MailingCountry",
                        column: x => x.MailingCountry,
                        principalTable: "Tbl_Countries",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientWorkPad_Tbl_Countries_Nationality",
                        column: x => x.Nationality,
                        principalTable: "Tbl_Countries",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientWorkPad_Tbl_Countries_NokCountry",
                        column: x => x.NokCountry,
                        principalTable: "Tbl_Countries",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientWorkPad_Tbl_Countries_OtherNationality",
                        column: x => x.OtherNationality,
                        principalTable: "Tbl_Countries",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientWorkPad_Tbl_Countries_ResidentialCountry",
                        column: x => x.ResidentialCountry,
                        principalTable: "Tbl_Countries",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientWorkPad_Tbl_EmploymentStatus_EmploymentStatus",
                        column: x => x.EmploymentStatus,
                        principalTable: "Tbl_EmploymentStatus",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientWorkPad_Tbl_FundDetails_FundId",
                        column: x => x.FundId,
                        principalTable: "Tbl_FundDetails",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientWorkPad_Tbl_Genders_ChildGender",
                        column: x => x.ChildGender,
                        principalTable: "Tbl_Genders",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientWorkPad_Tbl_Genders_Gender",
                        column: x => x.Gender,
                        principalTable: "Tbl_Genders",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientWorkPad_Tbl_Genders_Nok_Gender",
                        column: x => x.NokGender,
                        principalTable: "Tbl_Genders",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientWorkPad_Tbl_IdTypes_IdType",
                        column: x => x.IdType,
                        principalTable: "Tbl_IdTypes",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientWorkPad_Tbl_JobTypes_JobType",
                        column: x => x.JobType,
                        principalTable: "Tbl_JobTypes",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientWorkPad_Tbl_MaritalStatus_Marital_Status",
                        column: x => x.MaritalStatus,
                        principalTable: "Tbl_MaritalStatus",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientWorkPad_Tbl_MaritalStatus_NokMaritalStatus",
                        column: x => x.NokMaritalStatus,
                        principalTable: "Tbl_MaritalStatus",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientWorkPad_Tbl_MarketingChannels_MarketingChannelId",
                        column: x => x.MarketingChannelId,
                        principalTable: "Tbl_MarketingChannels",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientWorkPad_Tbl_OnboardingPlatforms_OnboardingPlatform",
                        column: x => x.OnboardingPlatform,
                        principalTable: "Tbl_OnboardingPlatforms",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientWorkPad_Tbl_PaymentModes_PaymentMode",
                        column: x => x.PaymentMode,
                        principalTable: "Tbl_PaymentModes",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientWorkPad_Tbl_Relationships_NokRelationship",
                        column: x => x.NokRelationship,
                        principalTable: "Tbl_Relationships",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientWorkPad_Tbl_Relationships_RelationshipId",
                        column: x => x.RelationshipId,
                        principalTable: "Tbl_Relationships",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientWorkPad_Tbl_Religion_Religion",
                        column: x => x.Religion,
                        principalTable: "Tbl_Religion",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientWorkPad_Tbl_Sector_CorporateBusinessSector",
                        column: x => x.CorporateBusinessSector,
                        principalTable: "Tbl_Sector",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientWorkPad_Tbl_States_CorporateState",
                        column: x => x.CorporateState,
                        principalTable: "Tbl_States",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientWorkPad_Tbl_States_NokState",
                        column: x => x.NokState,
                        principalTable: "Tbl_States",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientWorkPad_Tbl_States_ResidentialState",
                        column: x => x.ResidentialState,
                        principalTable: "Tbl_States",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientWorkPad_Tbl_States_State_Of_Origin",
                        column: x => x.StateOfOrigin,
                        principalTable: "Tbl_States",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientWorkPad_Tbl_StockBrokers_StockBroker",
                        column: x => x.StockBroker,
                        principalTable: "Tbl_StockBrokers",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientWorkPad_Tbl_SubscriptionTypes_ManageSubscriptionTypeId",
                        column: x => x.ManageSubscriptionTypeId,
                        principalTable: "Tbl_SubscriptionTypes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ClientWorkPad_Tbl_Titles_ChildTitle",
                        column: x => x.ChildTitle,
                        principalTable: "Tbl_Titles",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientWorkPad_Tbl_Titles_Nok_Title",
                        column: x => x.NokTitle,
                        principalTable: "Tbl_Titles",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientWorkPad_Tbl_Titles_Title",
                        column: x => x.Title,
                        principalTable: "Tbl_Titles",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClientWorkPad_Tbl_Town_ResidentialCity",
                        column: x => x.ResidentialCity,
                        principalTable: "Tbl_Town",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateIndex(
                name: "IX_Client_Bank",
                table: "Client",
                column: "Bank");

            migrationBuilder.CreateIndex(
                name: "IX_Client_ChildCountryOfBirth",
                table: "Client",
                column: "ChildCountryOfBirth");

            migrationBuilder.CreateIndex(
                name: "IX_Client_ChildGender",
                table: "Client",
                column: "ChildGender");

            migrationBuilder.CreateIndex(
                name: "IX_Client_ChildTitle",
                table: "Client",
                column: "ChildTitle");

            migrationBuilder.CreateIndex(
                name: "IX_Client_CorporateBusinessSector",
                table: "Client",
                column: "CorporateBusinessSector");

            migrationBuilder.CreateIndex(
                name: "IX_Client_CorporateCountry",
                table: "Client",
                column: "CorporateCountry");

            migrationBuilder.CreateIndex(
                name: "IX_Client_CorporateState",
                table: "Client",
                column: "CorporateState");

            migrationBuilder.CreateIndex(
                name: "IX_Client_CountryOfBirth",
                table: "Client",
                column: "CountryOfBirth");

            migrationBuilder.CreateIndex(
                name: "IX_Client_EmploymentStatus",
                table: "Client",
                column: "EmploymentStatus");

            migrationBuilder.CreateIndex(
                name: "IX_Client_FundId",
                table: "Client",
                column: "FundId");

            migrationBuilder.CreateIndex(
                name: "IX_Client_Gender",
                table: "Client",
                column: "Gender");

            migrationBuilder.CreateIndex(
                name: "IX_Client_IdType",
                table: "Client",
                column: "IdType");

            migrationBuilder.CreateIndex(
                name: "IX_Client_JobType",
                table: "Client",
                column: "JobType");

            migrationBuilder.CreateIndex(
                name: "IX_Client_MailingCountry",
                table: "Client",
                column: "MailingCountry");

            migrationBuilder.CreateIndex(
                name: "IX_Client_MarketingChannelId",
                table: "Client",
                column: "MarketingChannelId");

            migrationBuilder.CreateIndex(
                name: "IX_Client_NokCountry",
                table: "Client",
                column: "NokCountry");

            migrationBuilder.CreateIndex(
                name: "IX_Client_NokMaritalStatus",
                table: "Client",
                column: "NokMaritalStatus");

            migrationBuilder.CreateIndex(
                name: "IX_Client_NokRelationship",
                table: "Client",
                column: "NokRelationship");

            migrationBuilder.CreateIndex(
                name: "IX_Client_NokState",
                table: "Client",
                column: "NokState");

            migrationBuilder.CreateIndex(
                name: "IX_Client_OnboardingPlatform",
                table: "Client",
                column: "OnboardingPlatform");

            migrationBuilder.CreateIndex(
                name: "IX_Client_OtherNationality",
                table: "Client",
                column: "OtherNationality");

            migrationBuilder.CreateIndex(
                name: "IX_Client_PaymentMode",
                table: "Client",
                column: "PaymentMode");

            migrationBuilder.CreateIndex(
                name: "IX_Client_RelationshipId",
                table: "Client",
                column: "RelationshipId");

            migrationBuilder.CreateIndex(
                name: "IX_Client_Religion",
                table: "Client",
                column: "Religion");

            migrationBuilder.CreateIndex(
                name: "IX_Client_ResidentialCity",
                table: "Client",
                column: "ResidentialCity");

            migrationBuilder.CreateIndex(
                name: "IX_Client_ResidentialCountry",
                table: "Client",
                column: "ResidentialCountry");

            migrationBuilder.CreateIndex(
                name: "IX_Client_ResidentialState",
                table: "Client",
                column: "ResidentialState");

            migrationBuilder.CreateIndex(
                name: "IX_Client_SalesOfficer",
                table: "Client",
                column: "SalesOfficer");

            migrationBuilder.CreateIndex(
                name: "IX_Client_StockBroker",
                table: "Client",
                column: "StockBroker");

            migrationBuilder.CreateIndex(
                name: "IX_ClientWorkPad_Bank",
                table: "ClientWorkPad",
                column: "Bank");

            migrationBuilder.CreateIndex(
                name: "IX_ClientWorkPad_ChildCountryOfBirth",
                table: "ClientWorkPad",
                column: "ChildCountryOfBirth");

            migrationBuilder.CreateIndex(
                name: "IX_ClientWorkPad_ChildGender",
                table: "ClientWorkPad",
                column: "ChildGender");

            migrationBuilder.CreateIndex(
                name: "IX_ClientWorkPad_ChildTitle",
                table: "ClientWorkPad",
                column: "ChildTitle");

            migrationBuilder.CreateIndex(
                name: "IX_ClientWorkPad_CorporateBusinessSector",
                table: "ClientWorkPad",
                column: "CorporateBusinessSector");

            migrationBuilder.CreateIndex(
                name: "IX_ClientWorkPad_CorporateCountry",
                table: "ClientWorkPad",
                column: "CorporateCountry");

            migrationBuilder.CreateIndex(
                name: "IX_ClientWorkPad_CorporateState",
                table: "ClientWorkPad",
                column: "CorporateState");

            migrationBuilder.CreateIndex(
                name: "IX_ClientWorkPad_EmploymentStatus",
                table: "ClientWorkPad",
                column: "EmploymentStatus");

            migrationBuilder.CreateIndex(
                name: "IX_ClientWorkPad_FundId",
                table: "ClientWorkPad",
                column: "FundId");

            migrationBuilder.CreateIndex(
                name: "IX_ClientWorkPad_Gender",
                table: "ClientWorkPad",
                column: "Gender");

            migrationBuilder.CreateIndex(
                name: "IX_ClientWorkPad_IdType",
                table: "ClientWorkPad",
                column: "IdType");

            migrationBuilder.CreateIndex(
                name: "IX_ClientWorkPad_JobType",
                table: "ClientWorkPad",
                column: "JobType");

            migrationBuilder.CreateIndex(
                name: "IX_ClientWorkPad_MailingCountry",
                table: "ClientWorkPad",
                column: "MailingCountry");

            migrationBuilder.CreateIndex(
                name: "IX_ClientWorkPad_ManageSubscriptionTypeId",
                table: "ClientWorkPad",
                column: "ManageSubscriptionTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_ClientWorkPad_Marital_Status",
                table: "ClientWorkPad",
                column: "Marital_Status");

            migrationBuilder.CreateIndex(
                name: "IX_ClientWorkPad_MarketingChannelId",
                table: "ClientWorkPad",
                column: "MarketingChannelId");

            migrationBuilder.CreateIndex(
                name: "IX_ClientWorkPad_Nationality",
                table: "ClientWorkPad",
                column: "Nationality");

            migrationBuilder.CreateIndex(
                name: "IX_ClientWorkPad_Nok_Gender",
                table: "ClientWorkPad",
                column: "Nok_Gender");

            migrationBuilder.CreateIndex(
                name: "IX_ClientWorkPad_Nok_Title",
                table: "ClientWorkPad",
                column: "Nok_Title");

            migrationBuilder.CreateIndex(
                name: "IX_ClientWorkPad_NokCountry",
                table: "ClientWorkPad",
                column: "NokCountry");

            migrationBuilder.CreateIndex(
                name: "IX_ClientWorkPad_NokMaritalStatus",
                table: "ClientWorkPad",
                column: "NokMaritalStatus");

            migrationBuilder.CreateIndex(
                name: "IX_ClientWorkPad_NokRelationship",
                table: "ClientWorkPad",
                column: "NokRelationship");

            migrationBuilder.CreateIndex(
                name: "IX_ClientWorkPad_NokState",
                table: "ClientWorkPad",
                column: "NokState");

            migrationBuilder.CreateIndex(
                name: "IX_ClientWorkPad_OnboardingPlatform",
                table: "ClientWorkPad",
                column: "OnboardingPlatform");

            migrationBuilder.CreateIndex(
                name: "IX_ClientWorkPad_OtherNationality",
                table: "ClientWorkPad",
                column: "OtherNationality");

            migrationBuilder.CreateIndex(
                name: "IX_ClientWorkPad_PaymentMode",
                table: "ClientWorkPad",
                column: "PaymentMode");

            migrationBuilder.CreateIndex(
                name: "IX_ClientWorkPad_RelationshipId",
                table: "ClientWorkPad",
                column: "RelationshipId");

            migrationBuilder.CreateIndex(
                name: "IX_ClientWorkPad_Religion",
                table: "ClientWorkPad",
                column: "Religion");

            migrationBuilder.CreateIndex(
                name: "IX_ClientWorkPad_ResidentialCity",
                table: "ClientWorkPad",
                column: "ResidentialCity");

            migrationBuilder.CreateIndex(
                name: "IX_ClientWorkPad_ResidentialCountry",
                table: "ClientWorkPad",
                column: "ResidentialCountry");

            migrationBuilder.CreateIndex(
                name: "IX_ClientWorkPad_ResidentialState",
                table: "ClientWorkPad",
                column: "ResidentialState");

            migrationBuilder.CreateIndex(
                name: "IX_ClientWorkPad_SalesOfficer",
                table: "ClientWorkPad",
                column: "SalesOfficer");

            migrationBuilder.CreateIndex(
                name: "IX_ClientWorkPad_State_Of_Origin",
                table: "ClientWorkPad",
                column: "State_Of_Origin");

            migrationBuilder.CreateIndex(
                name: "IX_ClientWorkPad_StockBroker",
                table: "ClientWorkPad",
                column: "StockBroker");

            migrationBuilder.CreateIndex(
                name: "IX_ClientWorkPad_TenantId",
                table: "ClientWorkPad",
                column: "TenantId");

            migrationBuilder.CreateIndex(
                name: "IX_ClientWorkPad_Title",
                table: "ClientWorkPad",
                column: "Title");

            migrationBuilder.CreateIndex(
                name: "IX_Tbl_Town_StateId",
                table: "Tbl_Town",
                column: "StateId");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_SIAML_Users_SalesOfficer",
                table: "Client",
                column: "SalesOfficer",
                principalTable: "SIAML_Users",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Tbl_Banks_Bank",
                table: "Client",
                column: "Bank",
                principalTable: "Tbl_Banks",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Tbl_Countries_ChildCountryOfBirth",
                table: "Client",
                column: "ChildCountryOfBirth",
                principalTable: "Tbl_Countries",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Tbl_Countries_CorporateCountry",
                table: "Client",
                column: "CorporateCountry",
                principalTable: "Tbl_Countries",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Tbl_Countries_CountryOfBirth",
                table: "Client",
                column: "CountryOfBirth",
                principalTable: "Tbl_Countries",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Tbl_Countries_MailingCountry",
                table: "Client",
                column: "MailingCountry",
                principalTable: "Tbl_Countries",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Tbl_Countries_NokCountry",
                table: "Client",
                column: "NokCountry",
                principalTable: "Tbl_Countries",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Tbl_Countries_OtherNationality",
                table: "Client",
                column: "OtherNationality",
                principalTable: "Tbl_Countries",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Tbl_Countries_ResidentialCountry",
                table: "Client",
                column: "ResidentialCountry",
                principalTable: "Tbl_Countries",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Tbl_EmploymentStatus_EmploymentStatus",
                table: "Client",
                column: "EmploymentStatus",
                principalTable: "Tbl_EmploymentStatus",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Tbl_FundDetails_FundId",
                table: "Client",
                column: "FundId",
                principalTable: "Tbl_FundDetails",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Tbl_Genders_ChildGender",
                table: "Client",
                column: "ChildGender",
                principalTable: "Tbl_Genders",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Tbl_Genders_Gender",
                table: "Client",
                column: "Gender",
                principalTable: "Tbl_Genders",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Tbl_IdTypes_IdType",
                table: "Client",
                column: "IdType",
                principalTable: "Tbl_IdTypes",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Tbl_JobTypes_JobType",
                table: "Client",
                column: "JobType",
                principalTable: "Tbl_JobTypes",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Tbl_MaritalStatus_NokMaritalStatus",
                table: "Client",
                column: "NokMaritalStatus",
                principalTable: "Tbl_MaritalStatus",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Tbl_MarketingChannels_MarketingChannelId",
                table: "Client",
                column: "MarketingChannelId",
                principalTable: "Tbl_MarketingChannels",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Tbl_OnboardingPlatforms_OnboardingPlatform",
                table: "Client",
                column: "OnboardingPlatform",
                principalTable: "Tbl_OnboardingPlatforms",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Tbl_PaymentModes_PaymentMode",
                table: "Client",
                column: "PaymentMode",
                principalTable: "Tbl_PaymentModes",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Tbl_Relationships_NokRelationship",
                table: "Client",
                column: "NokRelationship",
                principalTable: "Tbl_Relationships",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Tbl_Relationships_RelationshipId",
                table: "Client",
                column: "RelationshipId",
                principalTable: "Tbl_Relationships",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Tbl_Religion_Religion",
                table: "Client",
                column: "Religion",
                principalTable: "Tbl_Religion",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Tbl_Sector_CorporateBusinessSector",
                table: "Client",
                column: "CorporateBusinessSector",
                principalTable: "Tbl_Sector",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Tbl_States_CorporateState",
                table: "Client",
                column: "CorporateState",
                principalTable: "Tbl_States",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Tbl_States_NokState",
                table: "Client",
                column: "NokState",
                principalTable: "Tbl_States",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Tbl_States_ResidentialState",
                table: "Client",
                column: "ResidentialState",
                principalTable: "Tbl_States",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Tbl_States_State_Of_Origin",
                table: "Client",
                column: "State_Of_Origin",
                principalTable: "Tbl_States",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Tbl_StockBrokers_StockBroker",
                table: "Client",
                column: "StockBroker",
                principalTable: "Tbl_StockBrokers",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Tbl_SubscriptionTypes_ManageSubscriptionTypeId",
                table: "Client",
                column: "ManageSubscriptionTypeId",
                principalTable: "Tbl_SubscriptionTypes",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Tbl_Titles_ChildTitle",
                table: "Client",
                column: "ChildTitle",
                principalTable: "Tbl_Titles",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Tbl_Town_ResidentialCity",
                table: "Client",
                column: "ResidentialCity",
                principalTable: "Tbl_Town",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Client_SIAML_Users_SalesOfficer",
                table: "Client");

            migrationBuilder.DropForeignKey(
                name: "FK_Client_Tbl_Banks_Bank",
                table: "Client");

            migrationBuilder.DropForeignKey(
                name: "FK_Client_Tbl_Countries_ChildCountryOfBirth",
                table: "Client");

            migrationBuilder.DropForeignKey(
                name: "FK_Client_Tbl_Countries_CorporateCountry",
                table: "Client");

            migrationBuilder.DropForeignKey(
                name: "FK_Client_Tbl_Countries_CountryOfBirth",
                table: "Client");

            migrationBuilder.DropForeignKey(
                name: "FK_Client_Tbl_Countries_MailingCountry",
                table: "Client");

            migrationBuilder.DropForeignKey(
                name: "FK_Client_Tbl_Countries_NokCountry",
                table: "Client");

            migrationBuilder.DropForeignKey(
                name: "FK_Client_Tbl_Countries_OtherNationality",
                table: "Client");

            migrationBuilder.DropForeignKey(
                name: "FK_Client_Tbl_Countries_ResidentialCountry",
                table: "Client");

            migrationBuilder.DropForeignKey(
                name: "FK_Client_Tbl_EmploymentStatus_EmploymentStatus",
                table: "Client");

            migrationBuilder.DropForeignKey(
                name: "FK_Client_Tbl_FundDetails_FundId",
                table: "Client");

            migrationBuilder.DropForeignKey(
                name: "FK_Client_Tbl_Genders_ChildGender",
                table: "Client");

            migrationBuilder.DropForeignKey(
                name: "FK_Client_Tbl_Genders_Gender",
                table: "Client");

            migrationBuilder.DropForeignKey(
                name: "FK_Client_Tbl_IdTypes_IdType",
                table: "Client");

            migrationBuilder.DropForeignKey(
                name: "FK_Client_Tbl_JobTypes_JobType",
                table: "Client");

            migrationBuilder.DropForeignKey(
                name: "FK_Client_Tbl_MaritalStatus_NokMaritalStatus",
                table: "Client");

            migrationBuilder.DropForeignKey(
                name: "FK_Client_Tbl_MarketingChannels_MarketingChannelId",
                table: "Client");

            migrationBuilder.DropForeignKey(
                name: "FK_Client_Tbl_OnboardingPlatforms_OnboardingPlatform",
                table: "Client");

            migrationBuilder.DropForeignKey(
                name: "FK_Client_Tbl_PaymentModes_PaymentMode",
                table: "Client");

            migrationBuilder.DropForeignKey(
                name: "FK_Client_Tbl_Relationships_NokRelationship",
                table: "Client");

            migrationBuilder.DropForeignKey(
                name: "FK_Client_Tbl_Relationships_RelationshipId",
                table: "Client");

            migrationBuilder.DropForeignKey(
                name: "FK_Client_Tbl_Religion_Religion",
                table: "Client");

            migrationBuilder.DropForeignKey(
                name: "FK_Client_Tbl_Sector_CorporateBusinessSector",
                table: "Client");

            migrationBuilder.DropForeignKey(
                name: "FK_Client_Tbl_States_CorporateState",
                table: "Client");

            migrationBuilder.DropForeignKey(
                name: "FK_Client_Tbl_States_NokState",
                table: "Client");

            migrationBuilder.DropForeignKey(
                name: "FK_Client_Tbl_States_ResidentialState",
                table: "Client");

            migrationBuilder.DropForeignKey(
                name: "FK_Client_Tbl_States_State_Of_Origin",
                table: "Client");

            migrationBuilder.DropForeignKey(
                name: "FK_Client_Tbl_StockBrokers_StockBroker",
                table: "Client");

            migrationBuilder.DropForeignKey(
                name: "FK_Client_Tbl_SubscriptionTypes_ManageSubscriptionTypeId",
                table: "Client");

            migrationBuilder.DropForeignKey(
                name: "FK_Client_Tbl_Titles_ChildTitle",
                table: "Client");

            migrationBuilder.DropForeignKey(
                name: "FK_Client_Tbl_Town_ResidentialCity",
                table: "Client");

            migrationBuilder.DropTable(
                name: "ClientWorkPad");

            migrationBuilder.DropTable(
                name: "Tbl_Town");

            migrationBuilder.DropIndex(
                name: "IX_Client_Bank",
                table: "Client");

            migrationBuilder.DropIndex(
                name: "IX_Client_ChildCountryOfBirth",
                table: "Client");

            migrationBuilder.DropIndex(
                name: "IX_Client_ChildGender",
                table: "Client");

            migrationBuilder.DropIndex(
                name: "IX_Client_ChildTitle",
                table: "Client");

            migrationBuilder.DropIndex(
                name: "IX_Client_CorporateBusinessSector",
                table: "Client");

            migrationBuilder.DropIndex(
                name: "IX_Client_CorporateCountry",
                table: "Client");

            migrationBuilder.DropIndex(
                name: "IX_Client_CorporateState",
                table: "Client");

            migrationBuilder.DropIndex(
                name: "IX_Client_CountryOfBirth",
                table: "Client");

            migrationBuilder.DropIndex(
                name: "IX_Client_EmploymentStatus",
                table: "Client");

            migrationBuilder.DropIndex(
                name: "IX_Client_FundId",
                table: "Client");

            migrationBuilder.DropIndex(
                name: "IX_Client_Gender",
                table: "Client");

            migrationBuilder.DropIndex(
                name: "IX_Client_IdType",
                table: "Client");

            migrationBuilder.DropIndex(
                name: "IX_Client_JobType",
                table: "Client");

            migrationBuilder.DropIndex(
                name: "IX_Client_MailingCountry",
                table: "Client");

            migrationBuilder.DropIndex(
                name: "IX_Client_MarketingChannelId",
                table: "Client");

            migrationBuilder.DropIndex(
                name: "IX_Client_NokCountry",
                table: "Client");

            migrationBuilder.DropIndex(
                name: "IX_Client_NokMaritalStatus",
                table: "Client");

            migrationBuilder.DropIndex(
                name: "IX_Client_NokRelationship",
                table: "Client");

            migrationBuilder.DropIndex(
                name: "IX_Client_NokState",
                table: "Client");

            migrationBuilder.DropIndex(
                name: "IX_Client_OnboardingPlatform",
                table: "Client");

            migrationBuilder.DropIndex(
                name: "IX_Client_OtherNationality",
                table: "Client");

            migrationBuilder.DropIndex(
                name: "IX_Client_PaymentMode",
                table: "Client");

            migrationBuilder.DropIndex(
                name: "IX_Client_RelationshipId",
                table: "Client");

            migrationBuilder.DropIndex(
                name: "IX_Client_Religion",
                table: "Client");

            migrationBuilder.DropIndex(
                name: "IX_Client_ResidentialCity",
                table: "Client");

            migrationBuilder.DropIndex(
                name: "IX_Client_ResidentialCountry",
                table: "Client");

            migrationBuilder.DropIndex(
                name: "IX_Client_ResidentialState",
                table: "Client");

            migrationBuilder.DropIndex(
                name: "IX_Client_SalesOfficer",
                table: "Client");

            migrationBuilder.DropIndex(
                name: "IX_Client_StockBroker",
                table: "Client");

            migrationBuilder.DropColumn(
                name: "AllDocumentsUpload",
                table: "Client");

            migrationBuilder.DropColumn(
                name: "CountryOfBirth",
                table: "Client");

            migrationBuilder.DropColumn(
                name: "EvidencePaymentUpload",
                table: "Client");

            migrationBuilder.DropColumn(
                name: "MarketOtherConsent",
                table: "Client");

            migrationBuilder.DropColumn(
                name: "PassportPhotographUpload",
                table: "Client");

            migrationBuilder.DropColumn(
                name: "ProofOfAddressUpload",
                table: "Client");

            migrationBuilder.DropColumn(
                name: "ProofOfIdentityUpload",
                table: "Client");

            migrationBuilder.DropColumn(
                name: "PurchaseOrderUpload",
                table: "Client");

            migrationBuilder.DropColumn(
                name: "ResearchConsent",
                table: "Client");

            migrationBuilder.RenameColumn(
                name: "NotifySms",
                table: "Client",
                newName: "NotifySMS");

            migrationBuilder.RenameColumn(
                name: "ManageSubscriptionTypeId",
                table: "Client",
                newName: "ClientType");

            migrationBuilder.RenameColumn(
                name: "Created_By",
                table: "Client",
                newName: "CreatedBy");

            migrationBuilder.RenameIndex(
                name: "IX_Client_ManageSubscriptionTypeId",
                table: "Client",
                newName: "IX_Client_ClientType");

            migrationBuilder.AlterColumn<string>(
                name: "CurrencyMnemonic",
                table: "ManageCurrencies",
                type: "nvarchar(5)",
                maxLength: 5,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(3)",
                oldMaxLength: 3);

            migrationBuilder.AlterColumn<string>(
                name: "StockBroker",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "SalesOfficer",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(long),
                oldType: "bigint",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "RiskSubCategory",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AlterColumn<string>(
                name: "RiskCategory",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AlterColumn<string>(
                name: "ResidentialState",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "ResidentialCountry",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "ResidentialCity",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Religion",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "RelationshipId",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "PaymentMode",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "PEP",
                table: "Client",
                type: "nvarchar(200)",
                maxLength: 200,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AlterColumn<string>(
                name: "OtherNationality",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "OnlineRedemption",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AlterColumn<string>(
                name: "OnboardingPlatform",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "NotifySMS",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(bool),
                oldType: "bit");

            migrationBuilder.AlterColumn<string>(
                name: "NotifyPostal",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(bool),
                oldType: "bit");

            migrationBuilder.AlterColumn<string>(
                name: "NotifyEmail",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(bool),
                oldType: "bit");

            migrationBuilder.AlterColumn<int>(
                name: "Nok_Country_Code",
                table: "Client",
                type: "int",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "NokState",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "NokRelationship",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "NokMaritalStatus",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "NokCountry",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "NokCity",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(250)",
                oldMaxLength: 250,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "MarketingChannelId",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "MailingCountry",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "KYCStatus",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AlterColumn<string>(
                name: "JobType",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "IdType",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Gender",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "FundId",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "EmploymentStatus",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "EmailIdemnity",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AlterColumn<int>(
                name: "Country_Code_Official",
                table: "Client",
                type: "int",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(150)",
                oldMaxLength: 150,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "Country_Code",
                table: "Client",
                type: "int",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "CorporateState",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "CorporateCountry",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "CorporateBusinessSector",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "ChildTitle",
                table: "Client",
                type: "nvarchar(200)",
                maxLength: 200,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "ChildGender",
                table: "Client",
                type: "nvarchar(200)",
                maxLength: 200,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "ChildCountryOfBirth",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "CallOverStatus",
                table: "Client",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AlterColumn<string>(
                name: "Bank",
                table: "Client",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Client_Country_Code",
                table: "Client",
                column: "Country_Code");

            migrationBuilder.CreateIndex(
                name: "IX_Client_Country_Code_Official",
                table: "Client",
                column: "Country_Code_Official");

            migrationBuilder.CreateIndex(
                name: "IX_Client_Nok_Country_Code",
                table: "Client",
                column: "Nok_Country_Code");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Tbl_Countries_Country_Code",
                table: "Client",
                column: "Country_Code",
                principalTable: "Tbl_Countries",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Tbl_Countries_Country_Code_Official",
                table: "Client",
                column: "Country_Code_Official",
                principalTable: "Tbl_Countries",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Tbl_Countries_Nok_Country_Code",
                table: "Client",
                column: "Nok_Country_Code",
                principalTable: "Tbl_Countries",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Tbl_Countries_State_Of_Origin",
                table: "Client",
                column: "State_Of_Origin",
                principalTable: "Tbl_Countries",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Tbl_SubscriptionTypes_ClientType",
                table: "Client",
                column: "ClientType",
                principalTable: "Tbl_SubscriptionTypes",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
