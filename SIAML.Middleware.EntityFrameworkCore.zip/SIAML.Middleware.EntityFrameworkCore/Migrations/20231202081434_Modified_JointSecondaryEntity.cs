﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SIAML.Middleware.Migrations
{
    /// <inheritdoc />
    public partial class ModifiedJointSecondaryEntity : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointStaging_Tbl_Banks_Bank",
                table: "ClientJointStaging");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointStaging_Tbl_Countries_ChildCountryOfBirth",
                table: "ClientJointStaging");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointStaging_Tbl_Countries_CorporateCountry",
                table: "ClientJointStaging");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointStaging_Tbl_Countries_CountryOfBirth",
                table: "ClientJointStaging");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointStaging_Tbl_Countries_MailingCountry",
                table: "ClientJointStaging");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointStaging_Tbl_Countries_Nationality",
                table: "ClientJointStaging");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointStaging_Tbl_Countries_NokCountry",
                table: "ClientJointStaging");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointStaging_Tbl_Countries_OtherNationality",
                table: "ClientJointStaging");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointStaging_Tbl_Countries_ResidentialCountry",
                table: "ClientJointStaging");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointStaging_Tbl_DividendPaymentTypes_DividendPaymentTypeId",
                table: "ClientJointStaging");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointStaging_Tbl_EmploymentStatus_EmploymentStatus",
                table: "ClientJointStaging");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointStaging_Tbl_FundDetails_FundId",
                table: "ClientJointStaging");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointStaging_Tbl_Genders_ChildGender",
                table: "ClientJointStaging");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointStaging_Tbl_Genders_Gender",
                table: "ClientJointStaging");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointStaging_Tbl_Genders_Nok_Gender",
                table: "ClientJointStaging");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointStaging_Tbl_IdTypes_IdType",
                table: "ClientJointStaging");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointStaging_Tbl_JobTypes_JobType",
                table: "ClientJointStaging");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointStaging_Tbl_MaritalStatus_Marital_Status",
                table: "ClientJointStaging");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointStaging_Tbl_MaritalStatus_NokMaritalStatus",
                table: "ClientJointStaging");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointStaging_Tbl_MarketingChannels_MarketingChannelId",
                table: "ClientJointStaging");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointStaging_Tbl_OnboardingPlatforms_OnboardingPlatform",
                table: "ClientJointStaging");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointStaging_Tbl_PaymentModes_PaymentMode",
                table: "ClientJointStaging");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointStaging_Tbl_Relationships_NokRelationship",
                table: "ClientJointStaging");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointStaging_Tbl_Relationships_RelationshipId",
                table: "ClientJointStaging");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointStaging_Tbl_Religion_Religion",
                table: "ClientJointStaging");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointStaging_Tbl_Sector_CorporateBusinessSector",
                table: "ClientJointStaging");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointStaging_Tbl_States_CorporateState",
                table: "ClientJointStaging");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointStaging_Tbl_States_NokState",
                table: "ClientJointStaging");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointStaging_Tbl_States_ResidentialState",
                table: "ClientJointStaging");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointStaging_Tbl_States_State_Of_Origin",
                table: "ClientJointStaging");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointStaging_Tbl_StockBrokers_StockBroker",
                table: "ClientJointStaging");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointStaging_Tbl_SubscriptionTypes_ManageSubscriptionTypeId",
                table: "ClientJointStaging");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointStaging_Tbl_Titles_ChildTitle",
                table: "ClientJointStaging");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointStaging_Tbl_Titles_Nok_Title",
                table: "ClientJointStaging");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointStaging_Tbl_Titles_Title",
                table: "ClientJointStaging");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointStaging_Tbl_Town_ResidentialCity",
                table: "ClientJointStaging");

            migrationBuilder.DropPrimaryKey(
                name: "PK_ClientJointStaging",
                table: "ClientJointStaging");

            migrationBuilder.RenameTable(
                name: "ClientJointStaging",
                newName: "ClientJointSecondary");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointStaging_Title",
                table: "ClientJointSecondary",
                newName: "IX_ClientJointSecondary_Title");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointStaging_StockBroker",
                table: "ClientJointSecondary",
                newName: "IX_ClientJointSecondary_StockBroker");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointStaging_State_Of_Origin",
                table: "ClientJointSecondary",
                newName: "IX_ClientJointSecondary_State_Of_Origin");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointStaging_ResidentialState",
                table: "ClientJointSecondary",
                newName: "IX_ClientJointSecondary_ResidentialState");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointStaging_ResidentialCountry",
                table: "ClientJointSecondary",
                newName: "IX_ClientJointSecondary_ResidentialCountry");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointStaging_ResidentialCity",
                table: "ClientJointSecondary",
                newName: "IX_ClientJointSecondary_ResidentialCity");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointStaging_Religion",
                table: "ClientJointSecondary",
                newName: "IX_ClientJointSecondary_Religion");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointStaging_RelationshipId",
                table: "ClientJointSecondary",
                newName: "IX_ClientJointSecondary_RelationshipId");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointStaging_PaymentMode",
                table: "ClientJointSecondary",
                newName: "IX_ClientJointSecondary_PaymentMode");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointStaging_OtherNationality",
                table: "ClientJointSecondary",
                newName: "IX_ClientJointSecondary_OtherNationality");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointStaging_OnboardingPlatform",
                table: "ClientJointSecondary",
                newName: "IX_ClientJointSecondary_OnboardingPlatform");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointStaging_NokState",
                table: "ClientJointSecondary",
                newName: "IX_ClientJointSecondary_NokState");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointStaging_NokRelationship",
                table: "ClientJointSecondary",
                newName: "IX_ClientJointSecondary_NokRelationship");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointStaging_NokMaritalStatus",
                table: "ClientJointSecondary",
                newName: "IX_ClientJointSecondary_NokMaritalStatus");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointStaging_NokCountry",
                table: "ClientJointSecondary",
                newName: "IX_ClientJointSecondary_NokCountry");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointStaging_Nok_Title",
                table: "ClientJointSecondary",
                newName: "IX_ClientJointSecondary_Nok_Title");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointStaging_Nok_Gender",
                table: "ClientJointSecondary",
                newName: "IX_ClientJointSecondary_Nok_Gender");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointStaging_Nationality",
                table: "ClientJointSecondary",
                newName: "IX_ClientJointSecondary_Nationality");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointStaging_MarketingChannelId",
                table: "ClientJointSecondary",
                newName: "IX_ClientJointSecondary_MarketingChannelId");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointStaging_Marital_Status",
                table: "ClientJointSecondary",
                newName: "IX_ClientJointSecondary_Marital_Status");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointStaging_ManageSubscriptionTypeId",
                table: "ClientJointSecondary",
                newName: "IX_ClientJointSecondary_ManageSubscriptionTypeId");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointStaging_MailingCountry",
                table: "ClientJointSecondary",
                newName: "IX_ClientJointSecondary_MailingCountry");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointStaging_JobType",
                table: "ClientJointSecondary",
                newName: "IX_ClientJointSecondary_JobType");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointStaging_IdType",
                table: "ClientJointSecondary",
                newName: "IX_ClientJointSecondary_IdType");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointStaging_Gender",
                table: "ClientJointSecondary",
                newName: "IX_ClientJointSecondary_Gender");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointStaging_FundId",
                table: "ClientJointSecondary",
                newName: "IX_ClientJointSecondary_FundId");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointStaging_EmploymentStatus",
                table: "ClientJointSecondary",
                newName: "IX_ClientJointSecondary_EmploymentStatus");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointStaging_DividendPaymentTypeId",
                table: "ClientJointSecondary",
                newName: "IX_ClientJointSecondary_DividendPaymentTypeId");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointStaging_CountryOfBirth",
                table: "ClientJointSecondary",
                newName: "IX_ClientJointSecondary_CountryOfBirth");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointStaging_CorporateState",
                table: "ClientJointSecondary",
                newName: "IX_ClientJointSecondary_CorporateState");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointStaging_CorporateCountry",
                table: "ClientJointSecondary",
                newName: "IX_ClientJointSecondary_CorporateCountry");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointStaging_CorporateBusinessSector",
                table: "ClientJointSecondary",
                newName: "IX_ClientJointSecondary_CorporateBusinessSector");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointStaging_ChildTitle",
                table: "ClientJointSecondary",
                newName: "IX_ClientJointSecondary_ChildTitle");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointStaging_ChildGender",
                table: "ClientJointSecondary",
                newName: "IX_ClientJointSecondary_ChildGender");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointStaging_ChildCountryOfBirth",
                table: "ClientJointSecondary",
                newName: "IX_ClientJointSecondary_ChildCountryOfBirth");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointStaging_Bank",
                table: "ClientJointSecondary",
                newName: "IX_ClientJointSecondary_Bank");

            migrationBuilder.AlterColumn<int>(
                name: "CorporateLegalEntityType",
                table: "ClientJointSecondary",
                type: "int",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "ArticleOfAssociationUpload",
                table: "ClientJointSecondary",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "BankAccountNameMismatchComment",
                table: "ClientJointSecondary",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "BvnNameMismatchComment",
                table: "ClientJointSecondary",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "CertificateOfIncorporationUpload",
                table: "ClientJointSecondary",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "CorporateSubLegalEntityType",
                table: "ClientJointSecondary",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "FormCAC2Upload",
                table: "ClientJointSecondary",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "FormCAC7Upload",
                table: "ClientJointSecondary",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "LegalSearchReportUpload",
                table: "ClientJointSecondary",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "MarketGroupConsent",
                table: "ClientJointSecondary",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddPrimaryKey(
                name: "PK_ClientJointSecondary",
                table: "ClientJointSecondary",
                column: "Id");

            migrationBuilder.CreateIndex(
                name: "IX_ClientJointSecondary_CorporateLegalEntityType",
                table: "ClientJointSecondary",
                column: "CorporateLegalEntityType");

            migrationBuilder.CreateIndex(
                name: "IX_ClientJointSecondary_CorporateSubLegalEntityType",
                table: "ClientJointSecondary",
                column: "CorporateSubLegalEntityType");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointSecondary_Tbl_Banks_Bank",
                table: "ClientJointSecondary",
                column: "Bank",
                principalTable: "Tbl_Banks",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointSecondary_Tbl_Countries_ChildCountryOfBirth",
                table: "ClientJointSecondary",
                column: "ChildCountryOfBirth",
                principalTable: "Tbl_Countries",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointSecondary_Tbl_Countries_CorporateCountry",
                table: "ClientJointSecondary",
                column: "CorporateCountry",
                principalTable: "Tbl_Countries",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointSecondary_Tbl_Countries_CountryOfBirth",
                table: "ClientJointSecondary",
                column: "CountryOfBirth",
                principalTable: "Tbl_Countries",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointSecondary_Tbl_Countries_MailingCountry",
                table: "ClientJointSecondary",
                column: "MailingCountry",
                principalTable: "Tbl_Countries",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointSecondary_Tbl_Countries_Nationality",
                table: "ClientJointSecondary",
                column: "Nationality",
                principalTable: "Tbl_Countries",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointSecondary_Tbl_Countries_NokCountry",
                table: "ClientJointSecondary",
                column: "NokCountry",
                principalTable: "Tbl_Countries",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointSecondary_Tbl_Countries_OtherNationality",
                table: "ClientJointSecondary",
                column: "OtherNationality",
                principalTable: "Tbl_Countries",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointSecondary_Tbl_Countries_ResidentialCountry",
                table: "ClientJointSecondary",
                column: "ResidentialCountry",
                principalTable: "Tbl_Countries",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointSecondary_Tbl_DividendPaymentTypes_DividendPaymentTypeId",
                table: "ClientJointSecondary",
                column: "DividendPaymentTypeId",
                principalTable: "Tbl_DividendPaymentTypes",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointSecondary_Tbl_EmploymentStatus_EmploymentStatus",
                table: "ClientJointSecondary",
                column: "EmploymentStatus",
                principalTable: "Tbl_EmploymentStatus",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointSecondary_Tbl_FundDetails_FundId",
                table: "ClientJointSecondary",
                column: "FundId",
                principalTable: "Tbl_FundDetails",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointSecondary_Tbl_Genders_ChildGender",
                table: "ClientJointSecondary",
                column: "ChildGender",
                principalTable: "Tbl_Genders",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointSecondary_Tbl_Genders_Gender",
                table: "ClientJointSecondary",
                column: "Gender",
                principalTable: "Tbl_Genders",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointSecondary_Tbl_Genders_Nok_Gender",
                table: "ClientJointSecondary",
                column: "Nok_Gender",
                principalTable: "Tbl_Genders",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointSecondary_Tbl_IdTypes_IdType",
                table: "ClientJointSecondary",
                column: "IdType",
                principalTable: "Tbl_IdTypes",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointSecondary_Tbl_JobTypes_JobType",
                table: "ClientJointSecondary",
                column: "JobType",
                principalTable: "Tbl_JobTypes",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointSecondary_Tbl_LegalEntities_CorporateLegalEntityType",
                table: "ClientJointSecondary",
                column: "CorporateLegalEntityType",
                principalTable: "Tbl_LegalEntities",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointSecondary_Tbl_MaritalStatus_Marital_Status",
                table: "ClientJointSecondary",
                column: "Marital_Status",
                principalTable: "Tbl_MaritalStatus",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointSecondary_Tbl_MaritalStatus_NokMaritalStatus",
                table: "ClientJointSecondary",
                column: "NokMaritalStatus",
                principalTable: "Tbl_MaritalStatus",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointSecondary_Tbl_MarketingChannels_MarketingChannelId",
                table: "ClientJointSecondary",
                column: "MarketingChannelId",
                principalTable: "Tbl_MarketingChannels",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointSecondary_Tbl_OnboardingPlatforms_OnboardingPlatform",
                table: "ClientJointSecondary",
                column: "OnboardingPlatform",
                principalTable: "Tbl_OnboardingPlatforms",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointSecondary_Tbl_PaymentModes_PaymentMode",
                table: "ClientJointSecondary",
                column: "PaymentMode",
                principalTable: "Tbl_PaymentModes",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointSecondary_Tbl_Relationships_NokRelationship",
                table: "ClientJointSecondary",
                column: "NokRelationship",
                principalTable: "Tbl_Relationships",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointSecondary_Tbl_Relationships_RelationshipId",
                table: "ClientJointSecondary",
                column: "RelationshipId",
                principalTable: "Tbl_Relationships",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointSecondary_Tbl_Religion_Religion",
                table: "ClientJointSecondary",
                column: "Religion",
                principalTable: "Tbl_Religion",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointSecondary_Tbl_Sector_CorporateBusinessSector",
                table: "ClientJointSecondary",
                column: "CorporateBusinessSector",
                principalTable: "Tbl_Sector",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointSecondary_Tbl_States_CorporateState",
                table: "ClientJointSecondary",
                column: "CorporateState",
                principalTable: "Tbl_States",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointSecondary_Tbl_States_NokState",
                table: "ClientJointSecondary",
                column: "NokState",
                principalTable: "Tbl_States",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointSecondary_Tbl_States_ResidentialState",
                table: "ClientJointSecondary",
                column: "ResidentialState",
                principalTable: "Tbl_States",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointSecondary_Tbl_States_State_Of_Origin",
                table: "ClientJointSecondary",
                column: "State_Of_Origin",
                principalTable: "Tbl_States",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointSecondary_Tbl_StockBrokers_StockBroker",
                table: "ClientJointSecondary",
                column: "StockBroker",
                principalTable: "Tbl_StockBrokers",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointSecondary_Tbl_SubLegalEntities_CorporateSubLegalEntityType",
                table: "ClientJointSecondary",
                column: "CorporateSubLegalEntityType",
                principalTable: "Tbl_SubLegalEntities",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointSecondary_Tbl_SubscriptionTypes_ManageSubscriptionTypeId",
                table: "ClientJointSecondary",
                column: "ManageSubscriptionTypeId",
                principalTable: "Tbl_SubscriptionTypes",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointSecondary_Tbl_Titles_ChildTitle",
                table: "ClientJointSecondary",
                column: "ChildTitle",
                principalTable: "Tbl_Titles",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointSecondary_Tbl_Titles_Nok_Title",
                table: "ClientJointSecondary",
                column: "Nok_Title",
                principalTable: "Tbl_Titles",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointSecondary_Tbl_Titles_Title",
                table: "ClientJointSecondary",
                column: "Title",
                principalTable: "Tbl_Titles",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointSecondary_Tbl_Town_ResidentialCity",
                table: "ClientJointSecondary",
                column: "ResidentialCity",
                principalTable: "Tbl_Town",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointSecondary_Tbl_Banks_Bank",
                table: "ClientJointSecondary");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointSecondary_Tbl_Countries_ChildCountryOfBirth",
                table: "ClientJointSecondary");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointSecondary_Tbl_Countries_CorporateCountry",
                table: "ClientJointSecondary");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointSecondary_Tbl_Countries_CountryOfBirth",
                table: "ClientJointSecondary");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointSecondary_Tbl_Countries_MailingCountry",
                table: "ClientJointSecondary");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointSecondary_Tbl_Countries_Nationality",
                table: "ClientJointSecondary");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointSecondary_Tbl_Countries_NokCountry",
                table: "ClientJointSecondary");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointSecondary_Tbl_Countries_OtherNationality",
                table: "ClientJointSecondary");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointSecondary_Tbl_Countries_ResidentialCountry",
                table: "ClientJointSecondary");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointSecondary_Tbl_DividendPaymentTypes_DividendPaymentTypeId",
                table: "ClientJointSecondary");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointSecondary_Tbl_EmploymentStatus_EmploymentStatus",
                table: "ClientJointSecondary");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointSecondary_Tbl_FundDetails_FundId",
                table: "ClientJointSecondary");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointSecondary_Tbl_Genders_ChildGender",
                table: "ClientJointSecondary");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointSecondary_Tbl_Genders_Gender",
                table: "ClientJointSecondary");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointSecondary_Tbl_Genders_Nok_Gender",
                table: "ClientJointSecondary");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointSecondary_Tbl_IdTypes_IdType",
                table: "ClientJointSecondary");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointSecondary_Tbl_JobTypes_JobType",
                table: "ClientJointSecondary");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointSecondary_Tbl_LegalEntities_CorporateLegalEntityType",
                table: "ClientJointSecondary");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointSecondary_Tbl_MaritalStatus_Marital_Status",
                table: "ClientJointSecondary");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointSecondary_Tbl_MaritalStatus_NokMaritalStatus",
                table: "ClientJointSecondary");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointSecondary_Tbl_MarketingChannels_MarketingChannelId",
                table: "ClientJointSecondary");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointSecondary_Tbl_OnboardingPlatforms_OnboardingPlatform",
                table: "ClientJointSecondary");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointSecondary_Tbl_PaymentModes_PaymentMode",
                table: "ClientJointSecondary");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointSecondary_Tbl_Relationships_NokRelationship",
                table: "ClientJointSecondary");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointSecondary_Tbl_Relationships_RelationshipId",
                table: "ClientJointSecondary");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointSecondary_Tbl_Religion_Religion",
                table: "ClientJointSecondary");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointSecondary_Tbl_Sector_CorporateBusinessSector",
                table: "ClientJointSecondary");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointSecondary_Tbl_States_CorporateState",
                table: "ClientJointSecondary");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointSecondary_Tbl_States_NokState",
                table: "ClientJointSecondary");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointSecondary_Tbl_States_ResidentialState",
                table: "ClientJointSecondary");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointSecondary_Tbl_States_State_Of_Origin",
                table: "ClientJointSecondary");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointSecondary_Tbl_StockBrokers_StockBroker",
                table: "ClientJointSecondary");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointSecondary_Tbl_SubLegalEntities_CorporateSubLegalEntityType",
                table: "ClientJointSecondary");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointSecondary_Tbl_SubscriptionTypes_ManageSubscriptionTypeId",
                table: "ClientJointSecondary");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointSecondary_Tbl_Titles_ChildTitle",
                table: "ClientJointSecondary");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointSecondary_Tbl_Titles_Nok_Title",
                table: "ClientJointSecondary");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointSecondary_Tbl_Titles_Title",
                table: "ClientJointSecondary");

            migrationBuilder.DropForeignKey(
                name: "FK_ClientJointSecondary_Tbl_Town_ResidentialCity",
                table: "ClientJointSecondary");

            migrationBuilder.DropPrimaryKey(
                name: "PK_ClientJointSecondary",
                table: "ClientJointSecondary");

            migrationBuilder.DropIndex(
                name: "IX_ClientJointSecondary_CorporateLegalEntityType",
                table: "ClientJointSecondary");

            migrationBuilder.DropIndex(
                name: "IX_ClientJointSecondary_CorporateSubLegalEntityType",
                table: "ClientJointSecondary");

            migrationBuilder.DropColumn(
                name: "ArticleOfAssociationUpload",
                table: "ClientJointSecondary");

            migrationBuilder.DropColumn(
                name: "BankAccountNameMismatchComment",
                table: "ClientJointSecondary");

            migrationBuilder.DropColumn(
                name: "BvnNameMismatchComment",
                table: "ClientJointSecondary");

            migrationBuilder.DropColumn(
                name: "CertificateOfIncorporationUpload",
                table: "ClientJointSecondary");

            migrationBuilder.DropColumn(
                name: "CorporateSubLegalEntityType",
                table: "ClientJointSecondary");

            migrationBuilder.DropColumn(
                name: "FormCAC2Upload",
                table: "ClientJointSecondary");

            migrationBuilder.DropColumn(
                name: "FormCAC7Upload",
                table: "ClientJointSecondary");

            migrationBuilder.DropColumn(
                name: "LegalSearchReportUpload",
                table: "ClientJointSecondary");

            migrationBuilder.DropColumn(
                name: "MarketGroupConsent",
                table: "ClientJointSecondary");

            migrationBuilder.RenameTable(
                name: "ClientJointSecondary",
                newName: "ClientJointStaging");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointSecondary_Title",
                table: "ClientJointStaging",
                newName: "IX_ClientJointStaging_Title");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointSecondary_StockBroker",
                table: "ClientJointStaging",
                newName: "IX_ClientJointStaging_StockBroker");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointSecondary_State_Of_Origin",
                table: "ClientJointStaging",
                newName: "IX_ClientJointStaging_State_Of_Origin");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointSecondary_ResidentialState",
                table: "ClientJointStaging",
                newName: "IX_ClientJointStaging_ResidentialState");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointSecondary_ResidentialCountry",
                table: "ClientJointStaging",
                newName: "IX_ClientJointStaging_ResidentialCountry");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointSecondary_ResidentialCity",
                table: "ClientJointStaging",
                newName: "IX_ClientJointStaging_ResidentialCity");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointSecondary_Religion",
                table: "ClientJointStaging",
                newName: "IX_ClientJointStaging_Religion");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointSecondary_RelationshipId",
                table: "ClientJointStaging",
                newName: "IX_ClientJointStaging_RelationshipId");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointSecondary_PaymentMode",
                table: "ClientJointStaging",
                newName: "IX_ClientJointStaging_PaymentMode");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointSecondary_OtherNationality",
                table: "ClientJointStaging",
                newName: "IX_ClientJointStaging_OtherNationality");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointSecondary_OnboardingPlatform",
                table: "ClientJointStaging",
                newName: "IX_ClientJointStaging_OnboardingPlatform");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointSecondary_NokState",
                table: "ClientJointStaging",
                newName: "IX_ClientJointStaging_NokState");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointSecondary_NokRelationship",
                table: "ClientJointStaging",
                newName: "IX_ClientJointStaging_NokRelationship");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointSecondary_NokMaritalStatus",
                table: "ClientJointStaging",
                newName: "IX_ClientJointStaging_NokMaritalStatus");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointSecondary_NokCountry",
                table: "ClientJointStaging",
                newName: "IX_ClientJointStaging_NokCountry");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointSecondary_Nok_Title",
                table: "ClientJointStaging",
                newName: "IX_ClientJointStaging_Nok_Title");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointSecondary_Nok_Gender",
                table: "ClientJointStaging",
                newName: "IX_ClientJointStaging_Nok_Gender");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointSecondary_Nationality",
                table: "ClientJointStaging",
                newName: "IX_ClientJointStaging_Nationality");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointSecondary_MarketingChannelId",
                table: "ClientJointStaging",
                newName: "IX_ClientJointStaging_MarketingChannelId");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointSecondary_Marital_Status",
                table: "ClientJointStaging",
                newName: "IX_ClientJointStaging_Marital_Status");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointSecondary_ManageSubscriptionTypeId",
                table: "ClientJointStaging",
                newName: "IX_ClientJointStaging_ManageSubscriptionTypeId");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointSecondary_MailingCountry",
                table: "ClientJointStaging",
                newName: "IX_ClientJointStaging_MailingCountry");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointSecondary_JobType",
                table: "ClientJointStaging",
                newName: "IX_ClientJointStaging_JobType");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointSecondary_IdType",
                table: "ClientJointStaging",
                newName: "IX_ClientJointStaging_IdType");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointSecondary_Gender",
                table: "ClientJointStaging",
                newName: "IX_ClientJointStaging_Gender");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointSecondary_FundId",
                table: "ClientJointStaging",
                newName: "IX_ClientJointStaging_FundId");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointSecondary_EmploymentStatus",
                table: "ClientJointStaging",
                newName: "IX_ClientJointStaging_EmploymentStatus");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointSecondary_DividendPaymentTypeId",
                table: "ClientJointStaging",
                newName: "IX_ClientJointStaging_DividendPaymentTypeId");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointSecondary_CountryOfBirth",
                table: "ClientJointStaging",
                newName: "IX_ClientJointStaging_CountryOfBirth");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointSecondary_CorporateState",
                table: "ClientJointStaging",
                newName: "IX_ClientJointStaging_CorporateState");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointSecondary_CorporateCountry",
                table: "ClientJointStaging",
                newName: "IX_ClientJointStaging_CorporateCountry");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointSecondary_CorporateBusinessSector",
                table: "ClientJointStaging",
                newName: "IX_ClientJointStaging_CorporateBusinessSector");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointSecondary_ChildTitle",
                table: "ClientJointStaging",
                newName: "IX_ClientJointStaging_ChildTitle");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointSecondary_ChildGender",
                table: "ClientJointStaging",
                newName: "IX_ClientJointStaging_ChildGender");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointSecondary_ChildCountryOfBirth",
                table: "ClientJointStaging",
                newName: "IX_ClientJointStaging_ChildCountryOfBirth");

            migrationBuilder.RenameIndex(
                name: "IX_ClientJointSecondary_Bank",
                table: "ClientJointStaging",
                newName: "IX_ClientJointStaging_Bank");

            migrationBuilder.AlterColumn<string>(
                name: "CorporateLegalEntityType",
                table: "ClientJointStaging",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AddPrimaryKey(
                name: "PK_ClientJointStaging",
                table: "ClientJointStaging",
                column: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointStaging_Tbl_Banks_Bank",
                table: "ClientJointStaging",
                column: "Bank",
                principalTable: "Tbl_Banks",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointStaging_Tbl_Countries_ChildCountryOfBirth",
                table: "ClientJointStaging",
                column: "ChildCountryOfBirth",
                principalTable: "Tbl_Countries",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointStaging_Tbl_Countries_CorporateCountry",
                table: "ClientJointStaging",
                column: "CorporateCountry",
                principalTable: "Tbl_Countries",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointStaging_Tbl_Countries_CountryOfBirth",
                table: "ClientJointStaging",
                column: "CountryOfBirth",
                principalTable: "Tbl_Countries",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointStaging_Tbl_Countries_MailingCountry",
                table: "ClientJointStaging",
                column: "MailingCountry",
                principalTable: "Tbl_Countries",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointStaging_Tbl_Countries_Nationality",
                table: "ClientJointStaging",
                column: "Nationality",
                principalTable: "Tbl_Countries",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointStaging_Tbl_Countries_NokCountry",
                table: "ClientJointStaging",
                column: "NokCountry",
                principalTable: "Tbl_Countries",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointStaging_Tbl_Countries_OtherNationality",
                table: "ClientJointStaging",
                column: "OtherNationality",
                principalTable: "Tbl_Countries",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointStaging_Tbl_Countries_ResidentialCountry",
                table: "ClientJointStaging",
                column: "ResidentialCountry",
                principalTable: "Tbl_Countries",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointStaging_Tbl_DividendPaymentTypes_DividendPaymentTypeId",
                table: "ClientJointStaging",
                column: "DividendPaymentTypeId",
                principalTable: "Tbl_DividendPaymentTypes",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointStaging_Tbl_EmploymentStatus_EmploymentStatus",
                table: "ClientJointStaging",
                column: "EmploymentStatus",
                principalTable: "Tbl_EmploymentStatus",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointStaging_Tbl_FundDetails_FundId",
                table: "ClientJointStaging",
                column: "FundId",
                principalTable: "Tbl_FundDetails",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointStaging_Tbl_Genders_ChildGender",
                table: "ClientJointStaging",
                column: "ChildGender",
                principalTable: "Tbl_Genders",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointStaging_Tbl_Genders_Gender",
                table: "ClientJointStaging",
                column: "Gender",
                principalTable: "Tbl_Genders",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointStaging_Tbl_Genders_Nok_Gender",
                table: "ClientJointStaging",
                column: "Nok_Gender",
                principalTable: "Tbl_Genders",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointStaging_Tbl_IdTypes_IdType",
                table: "ClientJointStaging",
                column: "IdType",
                principalTable: "Tbl_IdTypes",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointStaging_Tbl_JobTypes_JobType",
                table: "ClientJointStaging",
                column: "JobType",
                principalTable: "Tbl_JobTypes",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointStaging_Tbl_MaritalStatus_Marital_Status",
                table: "ClientJointStaging",
                column: "Marital_Status",
                principalTable: "Tbl_MaritalStatus",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointStaging_Tbl_MaritalStatus_NokMaritalStatus",
                table: "ClientJointStaging",
                column: "NokMaritalStatus",
                principalTable: "Tbl_MaritalStatus",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointStaging_Tbl_MarketingChannels_MarketingChannelId",
                table: "ClientJointStaging",
                column: "MarketingChannelId",
                principalTable: "Tbl_MarketingChannels",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointStaging_Tbl_OnboardingPlatforms_OnboardingPlatform",
                table: "ClientJointStaging",
                column: "OnboardingPlatform",
                principalTable: "Tbl_OnboardingPlatforms",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointStaging_Tbl_PaymentModes_PaymentMode",
                table: "ClientJointStaging",
                column: "PaymentMode",
                principalTable: "Tbl_PaymentModes",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointStaging_Tbl_Relationships_NokRelationship",
                table: "ClientJointStaging",
                column: "NokRelationship",
                principalTable: "Tbl_Relationships",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointStaging_Tbl_Relationships_RelationshipId",
                table: "ClientJointStaging",
                column: "RelationshipId",
                principalTable: "Tbl_Relationships",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointStaging_Tbl_Religion_Religion",
                table: "ClientJointStaging",
                column: "Religion",
                principalTable: "Tbl_Religion",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointStaging_Tbl_Sector_CorporateBusinessSector",
                table: "ClientJointStaging",
                column: "CorporateBusinessSector",
                principalTable: "Tbl_Sector",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointStaging_Tbl_States_CorporateState",
                table: "ClientJointStaging",
                column: "CorporateState",
                principalTable: "Tbl_States",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointStaging_Tbl_States_NokState",
                table: "ClientJointStaging",
                column: "NokState",
                principalTable: "Tbl_States",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointStaging_Tbl_States_ResidentialState",
                table: "ClientJointStaging",
                column: "ResidentialState",
                principalTable: "Tbl_States",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointStaging_Tbl_States_State_Of_Origin",
                table: "ClientJointStaging",
                column: "State_Of_Origin",
                principalTable: "Tbl_States",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointStaging_Tbl_StockBrokers_StockBroker",
                table: "ClientJointStaging",
                column: "StockBroker",
                principalTable: "Tbl_StockBrokers",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointStaging_Tbl_SubscriptionTypes_ManageSubscriptionTypeId",
                table: "ClientJointStaging",
                column: "ManageSubscriptionTypeId",
                principalTable: "Tbl_SubscriptionTypes",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointStaging_Tbl_Titles_ChildTitle",
                table: "ClientJointStaging",
                column: "ChildTitle",
                principalTable: "Tbl_Titles",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointStaging_Tbl_Titles_Nok_Title",
                table: "ClientJointStaging",
                column: "Nok_Title",
                principalTable: "Tbl_Titles",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointStaging_Tbl_Titles_Title",
                table: "ClientJointStaging",
                column: "Title",
                principalTable: "Tbl_Titles",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ClientJointStaging_Tbl_Town_ResidentialCity",
                table: "ClientJointStaging",
                column: "ResidentialCity",
                principalTable: "Tbl_Town",
                principalColumn: "Id");
        }
    }
}
