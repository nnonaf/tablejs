﻿using SIAML.Middleware.BuyNewFeature;
using SIAML.Middleware.OnboardingNonDiscretional;
using SIAML.Middleware.BusinessConfiguration;
using SIAML.Middleware.LegalEntity;
using SIAML.Middleware.DividendPayment;
using SIAML.Middleware.ApprovalWorkflow;
using SIAML.Middleware.SubscriptionWorkflowPad;
using SIAML.Middleware.Town;
using SIAML.Middleware.SubscriptionWorkflow;
using SIAML.Middleware.Sector;
using SIAML.Middleware.Education;
using SIAML.Middleware.EmploymentStatus;
using SIAML.Middleware.OnboardingPlatform;
using SIAML.Middleware.PaymentMode;
using SIAML.Middleware.FundDetails;
using SIAML.Middleware.Currency;
using SIAML.Middleware.JobType;
using SIAML.Middleware.IdType;
using SIAML.Middleware.MarketingChannel;
using SIAML.Middleware.StockBroker;
using SIAML.Middleware.Relationship;
using SIAML.Middleware.Bank;
using SIAML.Middleware.State;
using SIAML.Middleware.Country;
using SIAML.Middleware.Religion;
using SIAML.Middleware.Gender;
using SIAML.Middleware.MaritalStatus;
using SIAML.Middleware.Title;
using SIAML.Middleware.Subscription;
using SIAML.Middleware.WealthBox;
using Abp.IdentityServer4vNext;
using Abp.Zero.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using SIAML.Middleware.Authorization.Delegation;
using SIAML.Middleware.Authorization.Roles;
using SIAML.Middleware.Authorization.Users;
using SIAML.Middleware.Chat;
using SIAML.Middleware.Editions;
using SIAML.Middleware.Friendships;
using SIAML.Middleware.MultiTenancy;
using SIAML.Middleware.MultiTenancy.Accounting;
using SIAML.Middleware.MultiTenancy.Payments;
using SIAML.Middleware.Storage;
using Abp.Application.Editions;

namespace SIAML.Middleware.EntityFrameworkCore
{
    public class MiddlewareDbContext : AbpZeroDbContext<Tenant, Role, User, MiddlewareDbContext>, IAbpPersistedGrantDbContext
    {
        public virtual DbSet<ClientAdditionalAccount> ClientAdditionalAccounts { get; set; }

        public virtual DbSet<NonDiscretionalPortfolio> NonDiscretionalPortfolios { get; set; }

        public virtual DbSet<OnboardingSubscriptionDirector> OnboardingSubscriptionDirectors { get; set; }

        public virtual DbSet<OnboardingSubscriptionSignatory> OnboardingSubscriptionSignatories { get; set; }

        public virtual DbSet<ManageBusinessConfiguration> ManageBusinessConfigurations { get; set; }

        public virtual DbSet<ManageSubLegalEntity> ManageSubLegalEntities { get; set; }

        public virtual DbSet<ManageLegalEntity> ManageLegalEntities { get; set; }

        public virtual DbSet<ManageDividendPaymentType> ManageDividendPaymentTypes { get; set; }

        public virtual DbSet<ApprovalJournal> ApprovalJournals { get; set; }

        public virtual DbSet<OnboardingSubscriptionCustomerFund> OnboardingSubscriptionCustomerFunds { get; set; }

        //public virtual DbSet<OnboardingSubscriptionWorkPad> OnboardingSubscriptionWorkPads { get; set; }

        public virtual DbSet<ManageTown> ManageTowns { get; set; }

        public virtual DbSet<OnboardingSubscription> OnboardingSubscriptions { get; set; }

        public virtual DbSet<OnboardingSubscriptionJoint> OnboardingSubscriptionsJoint { get; set; }

        public virtual DbSet<ManageSector> ManageSectors { get; set; }

        public virtual DbSet<ManageEducation> ManageEducations { get; set; }

        public virtual DbSet<ManageEmploymentStatus> ManageEmploymentStatuses { get; set; }

        public virtual DbSet<ManageOnboardingPlatform> ManageOnboardingPlatforms { get; set; }

        public virtual DbSet<ManagePaymentMode> ManagePaymentModes { get; set; }

        public virtual DbSet<ManageFundDetail> ManageFundDetails { get; set; }

        public virtual DbSet<ManageCurrency> ManageCurrencies { get; set; }

        public virtual DbSet<ManageJobType> ManageJobTypes { get; set; }

        public virtual DbSet<ManageIdType> ManageIdTypes { get; set; }

        public virtual DbSet<ManageMarketingChannel> ManageMarketingChannels { get; set; }

        public virtual DbSet<ManageStockBroker> ManageStockBrokers { get; set; }

        public virtual DbSet<ManageRelationship> ManageRelationships { get; set; }

        public virtual DbSet<ManageBank> ManageBanks { get; set; }

        public virtual DbSet<ManageState> ManageStates { get; set; }

        public virtual DbSet<ManageCountry> ManageCountries { get; set; }

        public virtual DbSet<ManageReligion> ManageReligions { get; set; }

        public virtual DbSet<ManageGender> ManageGenders { get; set; }

        public virtual DbSet<ManageMaritalStatus> ManageMaritalStatuses { get; set; }

        public virtual DbSet<ManageTitle> ManageTitles { get; set; }

        public virtual DbSet<ManageSubscriptionType> ManageSubscriptionTypes { get; set; }

        public virtual DbSet<WorkflowManagement> WorkflowManagements { get; set; }

        /* Define an IDbSet for each entity of the application */

        public virtual DbSet<BinaryObject> BinaryObjects { get; set; }

        public virtual DbSet<Friendship> Friendships { get; set; }

        public virtual DbSet<ChatMessage> ChatMessages { get; set; }

        public virtual DbSet<SubscribableEdition> SubscribableEditions { get; set; }

        public virtual DbSet<SubscriptionPayment> SubscriptionPayments { get; set; }

        public virtual DbSet<Invoice> Invoices { get; set; }

        public virtual DbSet<PersistedGrantEntity> PersistedGrants { get; set; }

        public virtual DbSet<SubscriptionPaymentExtensionData> SubscriptionPaymentExtensionDatas { get; set; }

        public virtual DbSet<UserDelegation> UserDelegations { get; set; }

        public virtual DbSet<RecentPassword> RecentPasswords { get; set; }

        public MiddlewareDbContext(DbContextOptions<MiddlewareDbContext> options)
            : base(options)
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            //This section was modified to change default ABP prefix on tables

            modelBuilder.ChangeAbpTablePrefix<Tenant, Role, User>("SIAML_"); //Removes table prefixes. You can specify another prefix.
            //

            modelBuilder.Entity<OnboardingSubscriptionWorkPad>(o =>
            {
                o.HasIndex(e => new { e.TenantId });
            });
            modelBuilder.Entity<OnboardingSubscription>(o =>
                       {
                           o.HasIndex(e => new { e.TenantId });
                       });
            modelBuilder.Entity<PersistedGrantEntity>().ToTable("SIAML_PersistedGrants");

            modelBuilder.ConfigurePersistedGrantEntity("SIAML_");

            modelBuilder.Entity<BinaryObject>().ToTable("SIAML_BinaryObjects");
            modelBuilder.Entity<ChatMessage>().ToTable("SIAML_ChatMessages");
            modelBuilder.Entity<Friendship>().ToTable("SIAML_Friendships");
            modelBuilder.Entity<Invoice>().ToTable("SIAML_Invoices");
            modelBuilder.Entity<SubscriptionPayment>().ToTable("SIAML_SubscriptionPayments");
            modelBuilder.Entity<UserDelegation>().ToTable("SIAML_UserDelegations");
            modelBuilder.Entity<RecentPassword>().ToTable("SIAML_RecentPasswords");
            modelBuilder.Entity<SubscriptionPaymentExtensionData>().ToTable("SIAML_SubscriptionPaymentsExtensionData");
            modelBuilder.Entity<Edition>().ToTable("SIAML_Editions");

            modelBuilder.Entity<BinaryObject>(b =>
                       {
                           b.HasIndex(e => new { e.TenantId });
                       });

            modelBuilder.Entity<ChatMessage>(b =>
            {
                b.HasIndex(e => new { e.TenantId, e.UserId, e.ReadState });
                b.HasIndex(e => new { e.TenantId, e.TargetUserId, e.ReadState });
                b.HasIndex(e => new { e.TargetTenantId, e.TargetUserId, e.ReadState });
                b.HasIndex(e => new { e.TargetTenantId, e.UserId, e.ReadState });
            });

            modelBuilder.Entity<Friendship>(b =>
            {
                b.HasIndex(e => new { e.TenantId, e.UserId });
                b.HasIndex(e => new { e.TenantId, e.FriendUserId });
                b.HasIndex(e => new { e.FriendTenantId, e.UserId });
                b.HasIndex(e => new { e.FriendTenantId, e.FriendUserId });
            });

            modelBuilder.Entity<Tenant>(b =>
            {
                b.HasIndex(e => new { e.SubscriptionEndDateUtc });
                b.HasIndex(e => new { e.CreationTime });
            });

            modelBuilder.Entity<SubscriptionPayment>(b =>
            {
                b.HasIndex(e => new { e.Status, e.CreationTime });
                b.HasIndex(e => new { PaymentId = e.ExternalPaymentId, e.Gateway });
            });

            modelBuilder.Entity<SubscriptionPaymentExtensionData>(b =>
            {
                b.HasQueryFilter(m => !m.IsDeleted)
                    .HasIndex(e => new { e.SubscriptionPaymentId, e.Key, e.IsDeleted })
                    .IsUnique()
                    .HasFilter("[IsDeleted] = 0");
            });

            modelBuilder.Entity<UserDelegation>(b =>
            {
                b.HasIndex(e => new { e.TenantId, e.SourceUserId });
                b.HasIndex(e => new { e.TenantId, e.TargetUserId });
            });

            //modelBuilder.ConfigurePersistedGrantEntity();
        }
    }
}