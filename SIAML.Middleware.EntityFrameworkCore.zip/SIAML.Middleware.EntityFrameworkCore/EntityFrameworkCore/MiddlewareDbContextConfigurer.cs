using System.Data.Common;
using Microsoft.EntityFrameworkCore;

namespace SIAML.Middleware.EntityFrameworkCore
{
    public static class MiddlewareDbContextConfigurer
    {
        public static void Configure(DbContextOptionsBuilder<MiddlewareDbContext> builder, string connectionString)
        {
            builder.UseSqlServer(connectionString);
        }

        public static void Configure(DbContextOptionsBuilder<MiddlewareDbContext> builder, DbConnection connection)
        {
            builder.UseSqlServer(connection);
        }
    }
}