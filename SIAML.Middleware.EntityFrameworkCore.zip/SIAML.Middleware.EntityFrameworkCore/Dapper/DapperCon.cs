﻿using Abp.Dependency;
using Abp.UI;
using Dapper;
using Microsoft.Data.SqlClient;
using SIAML.Middleware.Configuration;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Abp.Modules;
using SIAML.Middleware.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace SIAML.Middleware.Dapper
{
    public class DapperCon : MiddlewareEntityFrameworkCoreModule,IDapperCon
    {
        private readonly IConfiguration _config;
        private readonly string Connectionstring;



        public DapperCon(IAppConfigurationAccessor appConfigurationAccessor)
        {
            _config = appConfigurationAccessor.Configuration;

            Connectionstring = _config[$"Default2"];

        }
        public void Dispose()
        {

        }

        public int Execute(string sp, DynamicParameters parms, CommandType commandType = CommandType.StoredProcedure)
        {
            throw new NotImplementedException();
        }

        public T Get<T>(string sp, DynamicParameters parms, CommandType commandType = CommandType.Text)
        {


            using IDbConnection db = new SqlConnection(Connectionstring);
            return db.Query<T>(sp, parms, commandType: commandType, commandTimeout: 120000).FirstOrDefault();
        }

        public List<T> GetAll<T>(string sp, DynamicParameters parms, CommandType commandType = CommandType.StoredProcedure)
        {
            using IDbConnection db = new SqlConnection(Connectionstring);
            return db.Query<T>(sp, parms, commandType: commandType, commandTimeout: 120000).ToList();
        }

        public List<T> GetAllSQL<T>(string sp, DynamicParameters parms, CommandType commandType = CommandType.Text)
        {
            using IDbConnection db = new SqlConnection(Connectionstring);
            return db.Query<T>(sp, parms, commandType: commandType, commandTimeout: 120000).ToList();
        }

        public DbConnection GetDbconnection()
        {
            return new SqlConnection(Connectionstring);
        }

        public T Insert<T>(string sp, DynamicParameters parms, CommandType commandType = CommandType.StoredProcedure)
        {
            T result;
            using IDbConnection db = new SqlConnection(Connectionstring);
            try
            {
                if (db.State == ConnectionState.Closed)
                    db.Open();

                using var tran = db.BeginTransaction();
                try
                {
                    result = db.Query<T>(sp, parms, commandType: commandType, transaction: tran).FirstOrDefault();
                    tran.Commit();
                }
                catch (Exception ex)
                {
                    tran.Rollback();
                    Logger.Info("Dapper Insert Exception: Begin Transaction " + ex.ToString());

                    throw new UserFriendlyException(ex.ToString());
                    //throw ex;
                }
            }
            catch (Exception e)
            {
                //throw new UserFriendlyException(ex.ToString());

                Logger.Info("Dapper Insert Exception: Connection " + e.ToString());

                throw new UserFriendlyException(e.ToString());

                // throw ex;
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }

            return result;
        }

        public T Update<T>(string sp, DynamicParameters parms, CommandType commandType = CommandType.StoredProcedure)
        {
            T result;
            using IDbConnection db = new SqlConnection(Connectionstring);
            try
            {
                if (db.State == ConnectionState.Closed)
                    db.Open();

                using var tran = db.BeginTransaction();
                try
                {
                    result = db.Query<T>(sp, parms, commandType: commandType, transaction: tran).FirstOrDefault();
                    tran.Commit();
                }
                catch (Exception ex)
                {
                    tran.Rollback();

                    tran.Rollback();
                    Logger.Info("Dapper Update Exception: Begin Transaction " + ex.ToString());

                    throw new UserFriendlyException(ex.ToString());
                    //throw ex;
                }
            }
            catch (Exception e)
            {
                // throw ex;

                Logger.Info("Dapper Update Exception: Connection " + e.ToString());

                throw new UserFriendlyException(e.ToString());
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }

            return result;
        }

    }
}
