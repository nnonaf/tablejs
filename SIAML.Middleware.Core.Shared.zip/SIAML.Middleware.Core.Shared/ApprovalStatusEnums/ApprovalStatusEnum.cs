﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SIAML.Middleware.ApprovalStatusEnums
{
    public enum ApprovalStatusEnum
    {
        None = -1,
        PendingApproval1 = 0,
        Approved = 1,
        Rejected = 2,
        ReturnForCorrection = 3,
        ApprovedWithUpdate = 4,
        PendingApproval2 = 5,
        CalloverPassed = 6,
        CalloverFailed = 7
    }
}
