﻿namespace SIAML.Middleware.OnboardingPlatform
{
    public class ManageOnboardingPlatformConsts
    {

        public const int MinOnboardingPlatformLength = 1;
        public const int MaxOnboardingPlatformLength = 150;

    }
}