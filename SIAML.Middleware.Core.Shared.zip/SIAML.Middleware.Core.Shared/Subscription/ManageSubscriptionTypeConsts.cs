﻿namespace SIAML.Middleware.Subscription
{
    public class ManageSubscriptionTypeConsts
    {

        public const int MinSubscriptionTypeLength = 1;
        public const int MaxSubscriptionTypeLength = 250;

    }
}