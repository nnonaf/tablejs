﻿namespace SIAML.Middleware.DividendPayment
{
    public class ManageDividendPaymentTypeConsts
    {

        public const int MinDividendPaymentTypeLength = 1;
        public const int MaxDividendPaymentTypeLength = 100;

    }
}