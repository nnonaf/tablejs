﻿namespace SIAML.Middleware.Country
{
    public class ManageCountryConsts
    {

        public const int MinCountryNameLength = 1;
        public const int MaxCountryNameLength = 250;

        public const int MinCountryCodeLength = 1;
        public const int MaxCountryCodeLength = 100;
        public const string CountryCodeRegex = @"^[a-zA-Z0-9]*$";

        public const int MinISOAlpha2CodeLength = 2;
        public const int MaxISOAlpha2CodeLength = 2;
        public const string ISOAlpha2CodeRegex = @"^[A-Z]{2}$";

        public const int MinISOAlpha3CodeLength = 3;
        public const int MaxISOAlpha3CodeLength = 3;

    }
}