﻿namespace SIAML.Middleware.Education
{
    public class ManageEducationConsts
    {

        public const int MinEducationNameLength = 1;
        public const int MaxEducationNameLength = 250;

    }
}