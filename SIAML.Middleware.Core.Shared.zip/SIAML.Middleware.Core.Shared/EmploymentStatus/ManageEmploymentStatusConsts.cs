﻿namespace SIAML.Middleware.EmploymentStatus
{
    public class ManageEmploymentStatusConsts
    {

        public const int MinEmploymentStatusLength = 1;
        public const int MaxEmploymentStatusLength = 150;

    }
}