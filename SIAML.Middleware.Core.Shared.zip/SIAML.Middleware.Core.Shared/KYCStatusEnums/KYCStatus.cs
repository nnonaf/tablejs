﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SIAML.Middleware.KYCStatusEnums
{
    public enum KYCStatus
    {
        NotStarted = 0,
        InComplete = 3,
        Completed = 1
       // Failed = 3
    }
}
