﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SIAML.Middleware.AccountStatusEnum
{
    public enum AccountStatusEnum
    {
       // None = 0,
        Active = 1,
        Dormant = 2,
        Closed = 3,
        Blocked = 4,
        Inactive = 5,
        Frozen = 6

    }
}
