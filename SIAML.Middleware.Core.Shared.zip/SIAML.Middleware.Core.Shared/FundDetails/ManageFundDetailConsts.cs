﻿namespace SIAML.Middleware.FundDetails
{
    public class ManageFundDetailConsts
    {

        public const int MinFundIdLength = 1;
        public const int MaxFundIdLength = 150;

        public const int MinFundNameLength = 1;
        public const int MaxFundNameLength = 250;

        public const int MinAssetAllocationLength = 1;
        public const int MaxAssetAllocationLength = 500;

        public const int MinRestrictedInvestmentLength = 0;
        public const int MaxRestrictedInvestmentLength = 500;

        public const int MinGuaranteeLength = 0;
        public const int MaxGuaranteeLength = 350;

        public const int MinInvestmentHorizonLength = 1;
        public const int MaxInvestmentHorizonLength = 350;

        public const int MinInvestmentObjectiveLength = 1;
        public const int MaxInvestmentObjectiveLength = 350;

        public const int MinRiskLength = 1;
        public const int MaxRiskLength = 200;

        public const int MinRedemptionLength = 1;
        public const int MaxRedemptionLength = 250;

        public const int MinHandlingChargesLength = 1;
        public const int MaxHandlingChargesLength = 250;

    }
}