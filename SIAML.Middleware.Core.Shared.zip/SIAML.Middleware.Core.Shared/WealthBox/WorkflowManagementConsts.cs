﻿namespace SIAML.Middleware.WealthBox
{
    public class WorkflowManagementConsts
    {

    }
}