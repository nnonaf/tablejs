﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SIAML.Middleware.CallOverStatusEnums
{
    public enum CallOverStatusEnum
    {
        PendingCallover = 0,
        CalloverPassed = 1,
        CalloverFailed = 2
    }
}
