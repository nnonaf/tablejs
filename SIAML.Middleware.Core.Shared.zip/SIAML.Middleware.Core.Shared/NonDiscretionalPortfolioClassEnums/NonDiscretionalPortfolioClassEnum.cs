﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SIAML.Middleware.NonDiscretionalPortfolioClassEnums
{
    public enum NonDiscretionalPortfolioClassEnum
    {
        DailyNAVPortfolio = 1,
        ClosingNAVPortfolio = 2,
        UnitizedMutualFund = 3,
        InterestBasedMutualFund = 4,
        NonInterestBasedMutualFund = 5,
        ARIP = 6

    }
}
