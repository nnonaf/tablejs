﻿namespace SIAML.Middleware.MaritalStatus
{
    public class ManageMaritalStatusConsts
    {

        public const int MinMaritalStatusLength = 1;
        public const int MaxMaritalStatusLength = 250;

    }
}