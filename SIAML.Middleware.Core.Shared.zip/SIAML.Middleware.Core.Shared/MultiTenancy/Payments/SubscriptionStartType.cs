namespace SIAML.Middleware.MultiTenancy.Payments
{
    public enum SubscriptionStartType
    {
        Free = 1,
        Trial = 2,
        Paid = 3
    }
}
