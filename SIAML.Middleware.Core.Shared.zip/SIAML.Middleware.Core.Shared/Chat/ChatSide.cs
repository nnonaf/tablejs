namespace SIAML.Middleware.Chat
{
    public enum ChatSide
    {
        Sender = 1,

        Receiver = 2
    }
}