﻿namespace SIAML.Middleware.SubscriptionWorkflowPad
{
    public class OnboardingSubscriptionWorkPadConsts
    {

        public const int MinLastNameLength = 0;
        public const int MaxLastNameLength = 500;

        public const int MinFirstNameLength = 0;
        public const int MaxFirstNameLength = 500;

        public const int MinOtherNamesLength = 0;
        public const int MaxOtherNamesLength = 500;

        public const int MinFullNameLength = 0;
        public const int MaxFullNameLength = 500;

        public const int MinMaiden_NameLength = 0;
        public const int MaxMaiden_NameLength = 500;

        public const int MinMothers_Maiden_NameLength = 0;
        public const int MaxMothers_Maiden_NameLength = 500;

        public const int MinEmployer_IdLength = 0;
        public const int MaxEmployer_IdLength = 500;

        public const int MinDesignationLength = 0;
        public const int MaxDesignationLength = 500;

        public const int MinEmailLength = 0;
        public const int MaxEmailLength = 500;
        public const string EmailRegex = @"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$";

        public const int MinMobile_PhoneLength = 0;
        public const int MaxMobile_PhoneLength = 500;

        public const int MinOfficial_PhoneLength = 0;
        public const int MaxOfficial_PhoneLength = 500;

        public const int MinNok_LastNameLength = 0;
        public const int MaxNok_LastNameLength = 500;

        public const int MinNok_FirstNameLength = 0;
        public const int MaxNok_FirstNameLength = 500;

        public const int MinNok_OtherNamesLength = 0;
        public const int MaxNok_OtherNamesLength = 500;

        public const int MinNok_EmailLength = 0;
        public const int MaxNok_EmailLength = 500;
        public const string Nok_EmailRegex = @"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$";

        public const int MinNok_Mobile_PhoneLength = 0;
        public const int MaxNok_Mobile_PhoneLength = 500;

        public const int MinNokAddressLength = 0;
        public const int MaxNokAddressLength = 500;

        public const int MinNokAddress2Length = 0;
        public const int MaxNokAddress2Length = 500;

        public const int MinBankAccountNameLength = 0;
        public const int MaxBankAccountNameLength = 500;

        public const int MinBankAccountNumberLength = 0;
        public const int MaxBankAccountNumberLength = 500;

        public const int MinBankAccountStatusLength = 0;
        public const int MaxBankAccountStatusLength = 500;

        public const int MinBvnLength = 0;
        public const int MaxBvnLength = 500;

        public const int MinBvnLastNameLength = 0;
        public const int MaxBvnLastNameLength = 500;

        public const int MinBvnFirstNameLength = 0;
        public const int MaxBvnFirstNameLength = 500;

        public const int MinBvnOtherNamesLength = 0;
        public const int MaxBvnOtherNamesLength = 500;

        public const int MinBvnMobilePhoneLength = 0;
        public const int MaxBvnMobilePhoneLength = 500;

        public const int MinBvnDobLength = 0;
        public const int MaxBvnDobLength = 500;

        public const int MinBvnStatusLength = 0;
        public const int MaxBvnStatusLength = 500;

        public const int MinCSCSAccountNumberLength = 0;
        public const int MaxCSCSAccountNumberLength = 500;

        public const int MinCHNLength = 0;
        public const int MaxCHNLength = 500;

        public const int MinPFALength = 0;
        public const int MaxPFALength = 500;

        public const int MinRsaPinLength = 0;
        public const int MaxRsaPinLength = 500;

        public const int MinStatusLength = 0;
        public const int MaxStatusLength = 500;

        public const int MinKYCStatusPassportLength = 0;
        public const int MaxKYCStatusPassportLength = 500;

        public const int MinKYCStatusDatesLength = 0;
        public const int MaxKYCStatusDatesLength = 500;

        public const int MinKYCStatusIdMeansLength = 0;
        public const int MaxKYCStatusIdMeansLength = 500;

        public const int MinKYCStatusAddressProofLength = 0;
        public const int MaxKYCStatusAddressProofLength = 500;

        public const int MinRecordSourceIdLength = 0;
        public const int MaxRecordSourceIdLength = 500;

        public const int MinRecordLocationIdLength = 0;
        public const int MaxRecordLocationIdLength = 500;

        public const int MinAgentIdLength = 0;
        public const int MaxAgentIdLength = 500;

        public const int MinPromoIdLength = 0;
        public const int MaxPromoIdLength = 500;

        public const int MinResidentialAddressLength = 0;
        public const int MaxResidentialAddressLength = 500;

        public const int MinResidentialAddress2Length = 0;
        public const int MaxResidentialAddress2Length = 500;

        public const int MinMailingAddressLength = 0;
        public const int MaxMailingAddressLength = 500;

        public const int MinMailingAddress2Length = 0;
        public const int MaxMailingAddress2Length = 500;

        public const int MinMailingCityLength = 0;
        public const int MaxMailingCityLength = 500;

        public const int MinMailingStateLength = 0;
        public const int MaxMailingStateLength = 500;

        public const int MinPassportLength = 0;
        public const int MaxPassportLength = 500;

        public const int MinSignatureLength = 0;
        public const int MaxSignatureLength = 500;

        public const int MinIdNumberLength = 0;
        public const int MaxIdNumberLength = 500;

        public const int MinProofOfAddressLength = 0;
        public const int MaxProofOfAddressLength = 1000;

        public const int MinProofOfAddressTypeLength = 0;
        public const int MaxProofOfAddressTypeLength = 500;

        public const int MinWebStatusLength = 0;
        public const int MaxWebStatusLength = 500;

        public const int MinWebPassCodeLength = 0;
        public const int MaxWebPassCodeLength = 500;

        public const int MinSubProfileLength = 0;
        public const int MaxSubProfileLength = 500;

        public const int MinLinkIdLength = 0;
        public const int MaxLinkIdLength = 500;

        public const int MinAdditionalInformationLength = 0;
        public const int MaxAdditionalInformationLength = 500;

        public const int MinSchoolIdLength = 0;
        public const int MaxSchoolIdLength = 200;

        public const int MinSchoolClassLength = 0;
        public const int MaxSchoolClassLength = 200;

        public const int MinSchoolSessionLength = 0;
        public const int MaxSchoolSessionLength = 200;

        public const int MinStagingIdLength = 0;
        public const int MaxStagingIdLength = 500;

        public const int MinInvestorIdLength = 0;
        public const int MaxInvestorIdLength = 500;

        public const int MinCreated_ByLength = 0;
        public const int MaxCreated_ByLength = 500;

        public const int MinConfirmedByLength = 0;
        public const int MaxConfirmedByLength = 500;

        public const int MinApprovedByLength = 0;
        public const int MaxApprovedByLength = 500;

        public const int MinLastUpdatedByLength = 0;
        public const int MaxLastUpdatedByLength = 500;

        public const int MinWorkFlowTypeLength = 0;
        public const int MaxWorkFlowTypeLength = 500;

        public const int MinTransRefLength = 0;
        public const int MaxTransRefLength = 500;

        public const int MinOrderIdLength = 0;
        public const int MaxOrderIdLength = 500;

        public const int MinRecordIdLength = 0;
        public const int MaxRecordIdLength = 500;

        public const int MinClientIdLength = 0;
        public const int MaxClientIdLength = 500;

        public const int MinTagLength = 0;
        public const int MaxTagLength = 500;

        public const int MinSourceLength = 0;
        public const int MaxSourceLength = 500;

        public const int MinBeneficiaryNameLength = 0;
        public const int MaxBeneficiaryNameLength = 500;

        public const int MinBeneficiaryAccountLength = 0;
        public const int MaxBeneficiaryAccountLength = 500;

        public const int MinApprovalStatusLength = 0;
        public const int MaxApprovalStatusLength = 500;

        public const int MinApproverLength = 0;
        public const int MaxApproverLength = 500;

        public const int MinAgentCodeLength = 0;
        public const int MaxAgentCodeLength = 500;

        public const int MinSubscriberTypeLength = 0;
        public const int MaxSubscriberTypeLength = 500;

        public const int MinTransIdLength = 0;
        public const int MaxTransIdLength = 500;

        public const int MinReceivedByLength = 0;
        public const int MaxReceivedByLength = 500;

        public const int MinMarketingSourceLength = 0;
        public const int MaxMarketingSourceLength = 500;

        public const int MinDividendPaymentLength = 0;
        public const int MaxDividendPaymentLength = 500;

        public const int MinAdditionalFlagLength = 0;
        public const int MaxAdditionalFlagLength = 500;

        public const int MinCorporateNameOfInstitutionLength = 0;
        public const int MaxCorporateNameOfInstitutionLength = 500;

        public const int MinCorporateRCRegistrationNumberLength = 0;
        public const int MaxCorporateRCRegistrationNumberLength = 500;

        public const int MinCorporatePlaceOfIncorporationLength = 0;
        public const int MaxCorporatePlaceOfIncorporationLength = 200;

        public const int MinCorporateBusinessTypeLength = 0;
        public const int MaxCorporateBusinessTypeLength = 500;

        public const int MinPhoneNumberLength = 0;
        public const int MaxPhoneNumberLength = 200;

        public const int MinCorporateWebsiteLength = 0;
        public const int MaxCorporateWebsiteLength = 500;

        public const int MinCorporateFaxNumberLength = 0;
        public const int MaxCorporateFaxNumberLength = 200;

        public const int MinCorporateEmailAddressLength = 0;
        public const int MaxCorporateEmailAddressLength = 500;

        public const int MinCorporateCityLength = 0;
        public const int MaxCorporateCityLength = 500;

        public const int MinCorporateBusinessAddressLength = 0;
        public const int MaxCorporateBusinessAddressLength = 500;

        public const int MinCorporateStreetNameLength = 0;
        public const int MaxCorporateStreetNameLength = 500;

        public const int MinCorporateLocalityLength = 0;
        public const int MaxCorporateLocalityLength = 500;

        public const int MinCorporateNameOfContactPersonLength = 0;
        public const int MaxCorporateNameOfContactPersonLength = 500;

        public const int MinCorporateContactEmailAddressLength = 0;
        public const int MaxCorporateContactEmailAddressLength = 500;

        public const int MinCorporateDesignationLength = 0;
        public const int MaxCorporateDesignationLength = 500;

        public const int MinNarrationLength = 0;
        public const int MaxNarrationLength = 500;

        public const int MinReturnCodeLength = 0;
        public const int MaxReturnCodeLength = 500;

        public const int MinUpdatedByLength = 0;
        public const int MaxUpdatedByLength = 500;

        public const int MinCommentLength = 0;
        public const int MaxCommentLength = 500;

        public const int MinChildSurnameLength = 0;
        public const int MaxChildSurnameLength = 500;

        public const int MinChildFirstNameLength = 0;
        public const int MaxChildFirstNameLength = 500;

        public const int MinChildMiddleNameLength = 0;
        public const int MaxChildMiddleNameLength = 500;

        public const int MinIncomeRangePerAnnumLength = 0;
        public const int MaxIncomeRangePerAnnumLength = 500;

        public const int MinTinLength = 0;
        public const int MaxTinLength = 200;

        public const int MinPlaceOfIssueLength = 0;
        public const int MaxPlaceOfIssueLength = 500;

        public const int MinLevelOfEducationLength = 0;
        public const int MaxLevelOfEducationLength = 500;

        public const int MinEmployerAddressLength = 0;
        public const int MaxEmployerAddressLength = 500;

        public const int MinEmployerTelephoneLength = 0;
        public const int MaxEmployerTelephoneLength = 500;

        public const int MinEmployerFaxLength = 0;
        public const int MaxEmployerFaxLength = 500;

        public const int MinEmployerSegmentLength = 0;
        public const int MaxEmployerSegmentLength = 500;

        public const int MinEmployerWebsiteLength = 0;
        public const int MaxEmployerWebsiteLength = 500;

        public const int MinEmployerNameLength = 0;
        public const int MaxEmployerNameLength = 500;

        public const int MinNokCityLength = 0;
        public const int MaxNokCityLength = 250;

        public const int MinCountry_CodeLength = 0;
        public const int MaxCountry_CodeLength = 100;

        public const int MinCountry_Code_OfficialLength = 0;
        public const int MaxCountry_Code_OfficialLength = 150;

        public const int MinNok_Country_CodeLength = 0;
        public const int MaxNok_Country_CodeLength = 100;

    }
}