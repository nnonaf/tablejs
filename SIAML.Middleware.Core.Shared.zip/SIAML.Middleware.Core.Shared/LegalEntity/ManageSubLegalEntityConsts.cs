﻿namespace SIAML.Middleware.LegalEntity
{
    public class ManageSubLegalEntityConsts
    {

        public const int MinSubLegalEntityTypeLength = 1;
        public const int MaxSubLegalEntityTypeLength = 150;

    }
}