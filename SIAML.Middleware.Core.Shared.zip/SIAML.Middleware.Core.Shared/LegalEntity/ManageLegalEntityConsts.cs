﻿namespace SIAML.Middleware.LegalEntity
{
    public class ManageLegalEntityConsts
    {

        public const int MinLegalEntityTypeLength = 1;
        public const int MaxLegalEntityTypeLength = 30;

    }
}