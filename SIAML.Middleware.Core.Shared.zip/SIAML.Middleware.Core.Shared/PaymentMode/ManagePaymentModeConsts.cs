﻿namespace SIAML.Middleware.PaymentMode
{
    public class ManagePaymentModeConsts
    {

        public const int MinPaymentModeLength = 1;
        public const int MaxPaymentModeLength = 150;

    }
}