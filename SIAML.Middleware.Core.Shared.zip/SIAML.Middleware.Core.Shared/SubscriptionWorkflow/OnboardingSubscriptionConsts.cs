﻿namespace SIAML.Middleware.SubscriptionWorkflow
{
    public class OnboardingSubscriptionConsts
    {

        public const int MinLastNameLength = 0;
        public const int MaxLastNameLength = 100;

        public const int MinFirstNameLength = 0;
        public const int MaxFirstNameLength = 100;

        public const int MinOtherNamesLength = 0;
        public const int MaxOtherNamesLength = 100;

        public const int MinFullNameLength = 0;
        public const int MaxFullNameLength = 150;

        public const int MinMaiden_NameLength = 0;
        public const int MaxMaiden_NameLength = 100;

        public const int MinMothers_Maiden_NameLength = 0;
        public const int MaxMothers_Maiden_NameLength = 100;

        public const int MinEmployer_IdLength = 0;
        public const int MaxEmployer_IdLength = 50;

        public const int MinDesignationLength = 0;
        public const int MaxDesignationLength = 50;

        public const int MinEmailLength = 0;
        public const int MaxEmailLength = 100;
        public const string EmailRegex = @"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$";

        public const int MinMobile_PhoneLength = 0;
        public const int MaxMobile_PhoneLength = 18;

        public const int MinMobile_LocalPhoneLength = 0;
        public const int MaxMobile_LocalPhoneLength = 11;

        public const int MinOfficial_PhoneLength = 0;
        public const int MaxOfficial_PhoneLength = 50;

        public const int MinNok_LastNameLength = 0;
        public const int MaxNok_LastNameLength = 100;

        public const int MinNok_FirstNameLength = 0;
        public const int MaxNok_FirstNameLength = 100;

        public const int MinNok_OtherNamesLength = 0;
        public const int MaxNok_OtherNamesLength = 100;

        public const int MinNok_EmailLength = 0;
        public const int MaxNok_EmailLength = 100;
        public const string Nok_EmailRegex = @"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$";

        public const int MinNok_Mobile_PhoneLength = 0;
        public const int MaxNok_Mobile_PhoneLength = 18;

        public const int MinNok_Mobile_LocalPhoneLength = 0;
        public const int MaxNok_Mobile_LocalPhoneLength = 11;

        public const int MinNokAddressLength = 0;
        public const int MaxNokAddressLength = 150;

        public const int MinNokAddress2Length = 0;
        public const int MaxNokAddress2Length = 100;

        public const int MinBankAccountNameLength = 0;
        public const int MaxBankAccountNameLength = 100;

        public const int MinBankAccountNumberLength = 10;
        public const int MaxBankAccountNumberLength = 10;

        public const int MinBankAccountStatusLength = 0;
        public const int MaxBankAccountStatusLength = 50;

        public const int MinBvnLength = 11;
        public const int MaxBvnLength = 15;

        public const int MinBvnLastNameLength = 0;
        public const int MaxBvnLastNameLength = 50;

        public const int MinBvnFirstNameLength = 0;
        public const int MaxBvnFirstNameLength = 50;

        public const int MinBvnOtherNamesLength = 0;
        public const int MaxBvnOtherNamesLength = 50;

        public const int MinBvnMobilePhoneLength = 0;
        public const int MaxBvnMobilePhoneLength = 50;

        public const int MinBvnDobLength = 0;
        public const int MaxBvnDobLength = 50;

        public const int MinBvnStatusLength = 0;
        public const int MaxBvnStatusLength = 50;

        public const int MinCSCSAccountNumberLength = 0;
        public const int MaxCSCSAccountNumberLength = 100;

        public const int MinCHNLength = 0;
        public const int MaxCHNLength = 150;

        public const int MinPFALength = 0;
        public const int MaxPFALength = 100;

        public const int MinRsaPinLength = 0;
        public const int MaxRsaPinLength = 100;

        public const int MinStatusLength = 0;
        public const int MaxStatusLength = 50;

        public const int MinKYCStatusPassportLength = 0;
        public const int MaxKYCStatusPassportLength = 50;

        public const int MinKYCStatusDatesLength = 0;
        public const int MaxKYCStatusDatesLength = 50;

        public const int MinKYCStatusIdMeansLength = 0;
        public const int MaxKYCStatusIdMeansLength = 50;

        public const int MinKYCStatusAddressProofLength = 0;
        public const int MaxKYCStatusAddressProofLength = 100;

        public const int MinRecordSourceIdLength = 0;
        public const int MaxRecordSourceIdLength = 100;

        public const int MinRecordLocationIdLength = 0;
        public const int MaxRecordLocationIdLength = 100;

        public const int MinAgentIdLength = 0;
        public const int MaxAgentIdLength = 100;

        public const int MinPromoIdLength = 0;
        public const int MaxPromoIdLength = 50;

        public const int MinResidentialAddressLength = 0;
        public const int MaxResidentialAddressLength = 150;

        public const int MinResidentialAddress2Length = 0;
        public const int MaxResidentialAddress2Length = 100;

        public const int MinMailingAddressLength = 0;
        public const int MaxMailingAddressLength = 100;

        public const int MinMailingAddress2Length = 0;
        public const int MaxMailingAddress2Length = 150;

        public const int MinMailingCityLength = 0;
        public const int MaxMailingCityLength = 100;

        public const int MinMailingStateLength = 0;
        public const int MaxMailingStateLength = 100;

        public const int MinPassportLength = 0;
        public const int MaxPassportLength = 500;

        public const int MinSignatureLength = 0;
        public const int MaxSignatureLength = 500;

        public const int MinIdNumberLength = 0;
        public const int MaxIdNumberLength = 100;

        public const int MinOccupationLength = 0;
        public const int MaxOccupationLength = 100;

        public const int MinProofOfAddressLength = 0;
        public const int MaxProofOfAddressLength = 1000;

        public const int MinProofOfAddressTypeLength = 0;
        public const int MaxProofOfAddressTypeLength = 50;

        public const int MinWebStatusLength = 0;
        public const int MaxWebStatusLength = 50;

        public const int MinWebPassCodeLength = 0;
        public const int MaxWebPassCodeLength = 50;

        public const int MinSubProfileLength = 0;
        public const int MaxSubProfileLength = 50;

        public const int MinLinkIdLength = 0;
        public const int MaxLinkIdLength = 500;

        public const int MinAdditionalInformationLength = 0;
        public const int MaxAdditionalInformationLength = 50;

        public const int MinSchoolIdLength = 0;
        public const int MaxSchoolIdLength = 50;

        public const int MinSchoolClassLength = 0;
        public const int MaxSchoolClassLength = 50;

        public const int MinSchoolSessionLength = 0;
        public const int MaxSchoolSessionLength = 50;

        public const int MinStagingIdLength = 0;
        public const int MaxStagingIdLength = 50;

        public const int MinInvestorIdLength = 0;
        public const int MaxInvestorIdLength = 500;

        public const int MinCreated_ByLength = 0;
        public const int MaxCreated_ByLength = 100;

        public const int MinConfirmedByLength = 0;
        public const int MaxConfirmedByLength = 100;

        public const int MinApprovedByLength = 0;
        public const int MaxApprovedByLength = 100;

        public const int MinLastUpdatedByLength = 0;
        public const int MaxLastUpdatedByLength = 100;

        public const int MinWorkFlowTypeLength = 0;
        public const int MaxWorkFlowTypeLength = 50;

        public const int MinTransRefLength = 0;
        public const int MaxTransRefLength = 100;

        public const int MinOrderIdLength = 0;
        public const int MaxOrderIdLength = 100;

        public const int MinRecordIdLength = 0;
        public const int MaxRecordIdLength = 100;

        public const int MinClientIdLength = 0;
        public const int MaxClientIdLength = 50;

        public const int MinTagLength = 0;
        public const int MaxTagLength = 50;

        public const int MinSourceLength = 0;
        public const int MaxSourceLength = 50;

        public const int MinBeneficiaryNameLength = 0;
        public const int MaxBeneficiaryNameLength = 100;

        public const int MinBeneficiaryAccountLength = 0;
        public const int MaxBeneficiaryAccountLength = 100;

        public const int MinApprovalStatusLength = 0;
        public const int MaxApprovalStatusLength = 50;

        public const int MinApproverLength = 0;
        public const int MaxApproverLength = 50;

        public const int MinAgentCodeLength = 0;
        public const int MaxAgentCodeLength = 50;

        public const int MinSubscriberTypeLength = 0;
        public const int MaxSubscriberTypeLength = 50;

        public const int MinTransIdLength = 0;
        public const int MaxTransIdLength = 50;

        public const int MinReceivedByLength = 0;
        public const int MaxReceivedByLength = 50;

        public const int MinMarketingSourceLength = 0;
        public const int MaxMarketingSourceLength = 500;

        public const int MinDividendPaymentLength = 0;
        public const int MaxDividendPaymentLength = 100;

        public const int MinAdditionalFlagLength = 0;
        public const int MaxAdditionalFlagLength = 50;

        public const int MinCorporateNameOfInstitutionLength = 0;
        public const int MaxCorporateNameOfInstitutionLength = 100;

        public const int MinCorporateRCRegistrationNumberLength = 0;
        public const int MaxCorporateRCRegistrationNumberLength = 100;

        public const int MinCorporatePlaceOfIncorporationLength = 0;
        public const int MaxCorporatePlaceOfIncorporationLength = 100;

        public const int MinCorporateBusinessTypeLength = 0;
        public const int MaxCorporateBusinessTypeLength = 50;

        public const int MinPhoneNumberLength = 0;
        public const int MaxPhoneNumberLength = 50;

        public const int MinCorporateLegalEntityTypeLength = 0;
        public const int MaxCorporateLegalEntityTypeLength = 50;

        public const int MinCorporateWebsiteLength = 0;
        public const int MaxCorporateWebsiteLength = 100;

        public const int MinCorporateFaxNumberLength = 0;
        public const int MaxCorporateFaxNumberLength = 50;

        public const int MinCorporateEmailAddressLength = 0;
        public const int MaxCorporateEmailAddressLength = 100;

        public const int MinCorporateCityLength = 0;
        public const int MaxCorporateCityLength = 100;

        public const int MinCorporateBusinessAddressLength = 0;
        public const int MaxCorporateBusinessAddressLength = 150;

        public const int MinCorporateStreetNameLength = 0;
        public const int MaxCorporateStreetNameLength = 150;

        public const int MinCorporateLocalityLength = 0;
        public const int MaxCorporateLocalityLength = 150;

        public const int MinCorporateNameOfContactPersonLength = 0;
        public const int MaxCorporateNameOfContactPersonLength = 100;

        public const int MinCorporateContactEmailAddressLength = 0;
        public const int MaxCorporateContactEmailAddressLength = 100;

        public const int MinCorporateDesignationLength = 0;
        public const int MaxCorporateDesignationLength = 50;

        public const int MinNarrationLength = 0;
        public const int MaxNarrationLength = 100;

        public const int MinReturnCodeLength = 0;
        public const int MaxReturnCodeLength = 50;

        public const int MinUpdatedByLength = 0;
        public const int MaxUpdatedByLength = 50;

        public const int MinCommentLength = 0;
        public const int MaxCommentLength = 150;

        public const int MinChildSurnameLength = 0;
        public const int MaxChildSurnameLength = 100;

        public const int MinChildFirstNameLength = 0;
        public const int MaxChildFirstNameLength = 100;

        public const int MinChildMiddleNameLength = 0;
        public const int MaxChildMiddleNameLength = 100;

        public const int MinIncomeRangePerAnnumLength = 0;
        public const int MaxIncomeRangePerAnnumLength = 100;

        public const int MinTinLength = 0;
        public const int MaxTinLength = 50;

        public const int MinPlaceOfIssueLength = 0;
        public const int MaxPlaceOfIssueLength = 100;

        public const int MinLevelOfEducationLength = 0;
        public const int MaxLevelOfEducationLength = 50;

        public const int MinEmployerAddressLength = 0;
        public const int MaxEmployerAddressLength = 150;

        public const int MinEmployerTelephoneLength = 0;
        public const int MaxEmployerTelephoneLength = 50;

        public const int MinEmployerFaxLength = 0;
        public const int MaxEmployerFaxLength = 50;

        public const int MinEmployerSegmentLength = 0;
        public const int MaxEmployerSegmentLength = 50;

        public const int MinEmployerWebsiteLength = 0;
        public const int MaxEmployerWebsiteLength = 100;

        public const int MinEmployerNameLength = 0;
        public const int MaxEmployerNameLength = 100;

        public const int MinNokCityLength = 0;
        public const int MaxNokCityLength = 50;

        public const int MinCountry_CodeLength = 0;
        public const int MaxCountry_CodeLength = 50;

        public const int MinCountry_Code_OfficialLength = 0;
        public const int MaxCountry_Code_OfficialLength = 50;

        public const int MinNok_Country_CodeLength = 0;
        public const int MaxNok_Country_CodeLength = 50;

    }
}