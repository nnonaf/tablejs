﻿namespace SIAML.Middleware.SubscriptionWorkflow
{
    public class OnboardingSubscriptionSignatoryConsts
    {

        public const int MinSurnameLength = 1;
        public const int MaxSurnameLength = 50;

        public const int MinFirstNameLength = 1;
        public const int MaxFirstNameLength = 50;

        public const int MinOtherNameLength = 0;
        public const int MaxOtherNameLength = 50;

        public const int MinAddressLength = 0;
        public const int MaxAddressLength = 150;

        public const int MinEmailLength = 0;
        public const int MaxEmailLength = 70;

        public const int MinPhoneNumberLength = 1;
        public const int MaxPhoneNumberLength = 18;

        public const int MinLocalPhoneNumberLength = 1;
        public const int MaxLocalPhoneNumberLength = 11;

        public const int MinIdNumberLength = 1;
        public const int MaxIdNumberLength = 100;

    }
}