﻿namespace SIAML.Middleware.SubscriptionWorkflow
{
    public class OnboardingSubscriptionCustomerFundConsts
    {

    }
}