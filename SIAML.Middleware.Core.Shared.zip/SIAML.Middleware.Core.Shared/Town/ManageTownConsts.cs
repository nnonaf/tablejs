﻿namespace SIAML.Middleware.Town
{
    public class ManageTownConsts
    {

        public const int MinTownNameLength = 1;
        public const int MaxTownNameLength = 150;

    }
}