namespace SIAML.Middleware.WebHooks
{
    public class AppWebHookNames
    {
        public const string TestWebhook = "App.TestWebhook";
    }
}
