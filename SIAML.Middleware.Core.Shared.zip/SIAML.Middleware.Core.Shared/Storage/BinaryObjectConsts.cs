namespace SIAML.Middleware.Storage
{
    public class BinaryObjectConsts
    {
        public const int BytesMaxSize = 10240;
    }
}
