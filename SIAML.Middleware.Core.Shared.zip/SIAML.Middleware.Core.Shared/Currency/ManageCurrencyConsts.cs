﻿namespace SIAML.Middleware.Currency
{
    public class ManageCurrencyConsts
    {

        public const int MinCurrrencyNameLength = 1;
        public const int MaxCurrrencyNameLength = 150;

        public const int MinCurrencyMnemonicLength = 3;
        public const int MaxCurrencyMnemonicLength = 3;

    }
}