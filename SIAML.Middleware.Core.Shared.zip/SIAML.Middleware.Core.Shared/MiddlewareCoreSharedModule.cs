using Abp.Modules;
using Abp.Reflection.Extensions;

namespace SIAML.Middleware
{
    public class MiddlewareCoreSharedModule : AbpModule
    {
        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(MiddlewareCoreSharedModule).GetAssembly());
        }
    }
}