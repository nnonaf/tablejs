﻿namespace SIAML.Middleware.Title
{
    public class ManageTitleConsts
    {

        public const int MinTitleLength = 1;
        public const int MaxTitleLength = 250;

    }
}