﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SIAML.Middleware.EmployerSegmentEnums
{
    public enum EmployerSegmentEnum
    {
        SelectSegment = 0,
        Private = 1,
        Public = 2
    }
}
