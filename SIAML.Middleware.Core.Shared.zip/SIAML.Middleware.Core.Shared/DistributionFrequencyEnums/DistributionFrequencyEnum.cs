﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SIAML.Middleware.DistributionFrequencyEnums
{
    public enum DistributionFrequencyEnum
    {
        None = 0,
        Daily = 1,
        Weekly = 2,
        Monthly = 3,
        Quarterly = 4,
        SemiAnnually = 5,
        Annually = 6
    }
}
