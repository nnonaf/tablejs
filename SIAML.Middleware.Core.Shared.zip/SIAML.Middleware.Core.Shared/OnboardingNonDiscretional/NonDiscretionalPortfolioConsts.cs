﻿namespace SIAML.Middleware.OnboardingNonDiscretional
{
    public class NonDiscretionalPortfolioConsts
    {

        public const int MinPortfolioNameLength = 1;
        public const int MaxPortfolioNameLength = 250;

        public const int MinFundCodeLength = 0;
        public const int MaxFundCodeLength = 100;

    }
}