﻿namespace SIAML.Middleware.IdType
{
    public class ManageIdTypeConsts
    {

        public const int MinIdTypeNameLength = 1;
        public const int MaxIdTypeNameLength = 350;

    }
}