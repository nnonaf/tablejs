﻿namespace SIAML.Middleware.Gender
{
    public class ManageGenderConsts
    {

        public const int MinGenderLength = 1;
        public const int MaxGenderLength = 250;

    }
}