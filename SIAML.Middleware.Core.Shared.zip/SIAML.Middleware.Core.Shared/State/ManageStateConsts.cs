﻿namespace SIAML.Middleware.State
{
    public class ManageStateConsts
    {

        public const int MinStateNameLength = 1;
        public const int MaxStateNameLength = 200;

        public const int MinISOCodeLength = 2;
        public const int MaxISOCodeLength = 2;
        public const string ISOCodeRegex = @"^[A-Z]{2}$";


    }
}