﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SIAML.Middleware.PublicSectorEnums
{
    public enum PublicSectorGradeEnum
    {
        SelectSectorGrade = 0,
        Grade_1_To_14 = 1,
        Grade_15_To_17 = 2,
    }
}
