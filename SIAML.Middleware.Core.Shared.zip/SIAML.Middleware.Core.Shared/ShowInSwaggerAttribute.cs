﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SIAML.Middleware
{
    [AttributeUsage(AttributeTargets.Method | AttributeTargets.Class)]
    public class ShowInSwaggerAttribute : Attribute
    {
    }
}
