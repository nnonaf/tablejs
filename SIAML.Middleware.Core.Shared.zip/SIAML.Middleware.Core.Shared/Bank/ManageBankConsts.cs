﻿namespace SIAML.Middleware.Bank
{
    public class ManageBankConsts
    {

        public const int MinBankCodeLength = 1;
        public const int MaxBankCodeLength = 100;

        public const int MinBankNameLength = 1;
        public const int MaxBankNameLength = 150;

    }
}