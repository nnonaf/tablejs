﻿namespace SIAML.Middleware.Religion
{
    public class ManageReligionConsts
    {

        public const int MinReligionLength = 1;
        public const int MaxReligionLength = 250;

    }
}