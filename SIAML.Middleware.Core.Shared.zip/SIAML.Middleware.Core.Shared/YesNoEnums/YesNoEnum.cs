﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SIAML.Middleware.YesNoEnums
{
    public enum YesNoEnum
    {
        SelectAnOption = 0,
        Yes = 1,
        No = 2

    }
}
