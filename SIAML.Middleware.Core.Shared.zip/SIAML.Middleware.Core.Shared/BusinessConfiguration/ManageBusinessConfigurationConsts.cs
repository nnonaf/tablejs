﻿namespace SIAML.Middleware.BusinessConfiguration
{
    public class ManageBusinessConfigurationConsts
    {

    }
}