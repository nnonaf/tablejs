﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SIAML.Middleware.NAVApp
{
    public class BVNConsts
    {
        public const int MinBVNLength = 1;
        public const int MaxBVNLength = 15;

    }
}
