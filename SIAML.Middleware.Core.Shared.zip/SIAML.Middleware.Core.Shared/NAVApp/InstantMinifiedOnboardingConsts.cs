﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SIAML.Middleware.NAVApp
{
    public class InstantMinifiedOnboardingConsts
    {
        public const int MinFirstNameLength = 1;
        public const int MaxFirstNameLength = 50;

        public const int MinMiddleNameLength = 0;
        public const int MaxMiddleNameLength = 50;

        public const int MinLastNameLength = 1;
        public const int MaxLastNameLength = 50;

        public const int MinEmailLength = 1;
        public const int MaxEmailLength = 50;

        public const int MinPhoneLength = 1;
        public const int MaxPhoneLength = 20;

        public const int MinGenderLength = 1;
        public const int MaxGenderLength = 20;

        public const int MinAddressLength = 1;
        public const int MaxAddressLength = 100;

        public const int MinBankNameLength = 1;
        public const int MaxBankNameLength = 25;

        public const int MinBankAccountNameLength = 1;
        public const int MaxBankAccountNameLength = 50;

        public const int MinBankAccountNumberLength = 1;
        public const int MaxBankAccountNumberLength = 20;

        public const int MinBvnLength = 1;
        public const int MaxBvnLength = 11;

        public const int MinBvnPhoneLength = 1;
        public const int MaxBvnPhoneLength = 15;

        public const int MinSourceChannelLength = 1;
        public const int MaxSourceChannelLength = 30;
    }
}
