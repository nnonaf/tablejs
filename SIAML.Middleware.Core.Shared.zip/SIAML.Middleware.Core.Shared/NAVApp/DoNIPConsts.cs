﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SIAML.Middleware.NAVApp
{
    public class DoNIPConsts
    {
        public const int MinAccountNumberLength = 1;
        public const int MaxAccountNumberLength = 11;

        public const int MinDestinationBankCodeLength = 1;
        public const int MaxDestinationBankCodeLength = 10;
    }
}
