namespace SIAML.Middleware.Authentication
{
    public class JsonClaimMapDto
    {
        public string Claim { get; set; }

        public string Key { get; set; }
    }
}