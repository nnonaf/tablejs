﻿namespace SIAML.Middleware.Relationship
{
    public class ManageRelationshipConsts
    {

        public const int MinRelationshipNameLength = 1;
        public const int MaxRelationshipNameLength = 250;

    }
}