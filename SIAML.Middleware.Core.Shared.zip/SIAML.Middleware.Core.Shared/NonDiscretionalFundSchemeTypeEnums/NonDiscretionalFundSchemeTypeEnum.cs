﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SIAML.Middleware.NonDiscretionalFundSchemeTypeEnums
{
    public enum NonDiscretionalFundSchemeTypeEnum
    {
        Unitized = 1,
        Mutual = 2,
        Eurobond = 3,
        Standalone = 4,
        FixedIncome = 5

    }
}
