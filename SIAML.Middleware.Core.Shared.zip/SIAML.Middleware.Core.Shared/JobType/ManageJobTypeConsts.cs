﻿namespace SIAML.Middleware.JobType
{
    public class ManageJobTypeConsts
    {

        public const int MinJobTypeNameLength = 1;
        public const int MaxJobTypeNameLength = 250;

    }
}