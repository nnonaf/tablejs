﻿namespace SIAML.Middleware.ApprovalWorkflow
{
    public class ApprovalJournalConsts
    {

        public const int MinApprovalTypeLength = 1;
        public const int MaxApprovalTypeLength = 100;

        public const int MinWorkflowIdLength = 1;
        public const int MaxWorkflowIdLength = 250;

        public const int MinApprovalStatusLength = 1;
        public const int MaxApprovalStatusLength = 100;

        public const int MinApprovalCommentLength = 0;
        public const int MaxApprovalCommentLength = 200;

        public const int MinCreatedByLength = 1;
        public const int MaxCreatedByLength = 100;

    }
}