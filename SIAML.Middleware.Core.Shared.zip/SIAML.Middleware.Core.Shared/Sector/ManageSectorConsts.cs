﻿namespace SIAML.Middleware.Sector
{
    public class ManageSectorConsts
    {

        public const int MinSectorNameLength = 1;
        public const int MaxSectorNameLength = 150;

    }
}