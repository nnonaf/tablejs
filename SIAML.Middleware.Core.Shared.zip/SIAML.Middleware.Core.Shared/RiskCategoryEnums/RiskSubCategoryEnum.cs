﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SIAML.Middleware.RiskCategoryEnums
{
    public enum RiskSubCategoryEnum
    {
        SelectAnOption = 0,     
        CustomerResideAbroad = 1,
        PoliticalExposedPerson = 2,
        AccountRequireSCUML = 3,
        UltraHighNetWorth = 4,
        StandAloneClient = 5,
        CustomerResideInHighRiskCountry = 7,
        Others = 8,
    }
}
