﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SIAML.Middleware.RiskCategoryEnums
{
    public enum RiskCategoryEnum
    {
        LowRisk = 1,
        HighRisk = 2
    }
}
