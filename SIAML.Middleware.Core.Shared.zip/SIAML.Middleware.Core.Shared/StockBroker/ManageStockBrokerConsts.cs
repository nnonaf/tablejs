﻿namespace SIAML.Middleware.StockBroker
{
    public class ManageStockBrokerConsts
    {

        public const int MinStockBrokerNameLength = 1;
        public const int MaxStockBrokerNameLength = 300;

    }
}