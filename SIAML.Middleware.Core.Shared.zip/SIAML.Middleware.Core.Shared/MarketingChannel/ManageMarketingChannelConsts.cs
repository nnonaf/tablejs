﻿namespace SIAML.Middleware.MarketingChannel
{
    public class ManageMarketingChannelConsts
    {

        public const int MinMarketingChannelLength = 1;
        public const int MaxMarketingChannelLength = 250;

    }
}