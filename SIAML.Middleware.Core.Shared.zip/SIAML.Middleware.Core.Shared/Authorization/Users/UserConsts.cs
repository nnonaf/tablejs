namespace SIAML.Middleware.Authorization.Users
{
    public class UserConsts
    {
        public const int MaxPhoneNumberLength = 24;
    }
}
