using Abp.AutoMapper;
using Abp.Modules;
using Abp.Reflection.Extensions;

namespace SIAML.Middleware.Startup
{
    [DependsOn(typeof(MiddlewareCoreModule))]
    public class MiddlewareGraphQLModule : AbpModule
    {
        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(MiddlewareGraphQLModule).GetAssembly());
        }

        public override void PreInitialize()
        {
            base.PreInitialize();

            //Adding custom AutoMapper configuration
            Configuration.Modules.AbpAutoMapper().Configurators.Add(CustomDtoMapper.CreateMappings);
        }
    }
}