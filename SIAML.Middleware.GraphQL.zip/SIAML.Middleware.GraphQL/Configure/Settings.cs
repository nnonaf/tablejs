namespace SIAML.Middleware.Configure
{
    public class Settings
    {
        public static string NoPermissionErrorMessage = "[ERR001] You don't have permission to access this resource! You need to be granted access the permission {0}.";

    }
}